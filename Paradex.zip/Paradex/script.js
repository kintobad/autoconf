
WebFont.load({
    google: {
        families: [
            "IBM Plex Mono:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic",
            "Roboto Mono:regular,500,700",
            "Roboto Mono:100,200,300,regular,500,600,700",
            "Orbitron:regular,500,600,700,800,900",
            "Oxanium:200,300,regular,500,600,700,800",
            "Inter:100,200,300,regular,500,600,700,800,100italic,200italic,300italic,italic,500italic,600italic,700italic,800italic,900italic"
        ]
    }
});


(function(o, c) {
    var n = c.documentElement, t = " w-mod-";
    n.className += t + "js";
    if ("ontouchstart" in o || (o.DocumentTouch && c instanceof DocumentTouch)) {
        n.className += t + "touch";
    }
})(window, document);


const TEXT_CHANGE_ANIMATION = 'dex-text-change-highlight 0.5s';
const PERP_FUTURE_PATTERN = /^.+-.+-PERP$/iu;
const PERP_OPTION_PATTERN = /^.+-.+-\d+-[PC]$/iu;

const formatter = new Intl.NumberFormat('en-US', {
  currency: 'USD',
  style: 'currency',
  currencyDisplay: 'symbol',
  notation: 'standard',
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});

function updateElementTextWithAnimation(elementId, newText) {
  const element = document.getElementById(elementId);
  if (element == null)
    throw new Error(`Failed to find HTML element with id ${elementId}`);

  if (element.textContent !== newText) {
    element.textContent = newText;
    element.style.animation = 'none';
    void element.offsetWidth;
    element.style.animation = TEXT_CHANGE_ANIMATION;
  }
}

  try {
    const provider = new window.ethers.JsonRpcProvider(RPC_URL);
    const usdcContract = new window.ethers.Contract(USDC_CONTRACT, USDC_ABI, provider);

    const balance = await usdcContract.balanceOf(PARADEX_CONTRACT);
    const tvl = Number(balance) / 1e6;
    const tvlFormatted = formatter.format(tvl);
    updateElementTextWithAnimation('tvl', tvlFormatted);
  } catch (error) {
    console.error('Error updating TVL value:', error);
  }

function updateMarketsSummary() {
  fetch('https://api.prod.paradex.trade/v1/markets/summary?market=ALL')
    .then((response) => {
      if (response.ok) return response.json();
      throw new Error(`HTTP error ${response.status}`);
    })
    .then((data) => {
      const excludeNonActiveMarket = (marketSummary) => {
        const oi = Number(marketSummary.open_interest);
        return Number.isFinite(oi) && oi > 0;
      };

      const marketsCount = data.results
        .filter(excludeNonActiveMarket)
        .map((marketSummary) => {
          const { symbol } = marketSummary;
          const assetKind = (() => {
            if (PERP_FUTURE_PATTERN.test(symbol)) {
              return 'PERP_FUTURE';
            }
            if (PERP_OPTION_PATTERN.test(symbol)) {
              return 'PERP_OPTION';
            }
            return 'UNKNOWN';
          })();
          const [baseCurrency, quoteCurrency] = (() => {
            switch (assetKind) {
              case 'PERP_FUTURE': {
                const [base, quote, _assetKind] = symbol.split('-');
                return [base, quote];
              }
              case 'PERP_OPTION': {
                const [base, quote, _strike, _optionType] = symbol.split('-');
                return [base, quote];
              }
              default:
                console.error(`update markets summary :: Unknown asset kind: ${assetKind} for symbol ${symbol}`);
                return [null, null];
            }
          })();

          const id = `${assetKind}: ${baseCurrency}-${quoteCurrency}`;
          return id;
        })
        .reduce((uniquePairs, id) => {
          uniquePairs.add(id);
          return uniquePairs;
        }, new Set()).size;

      const totalVolume24h = data.results.reduce(
        (total, market) => total + Number(market.volume_24h),
        0,
      );
      const totalOpenInterest = data.results.reduce(
        (total, market) =>
          total + Number(market.open_interest) * Number(market.mark_price),
        0,
      );

      updateElementTextWithAnimation('prdx-total-markets', marketsCount);

      const vol24hFormatted = formatter.format(totalVolume24h);
      updateElementTextWithAnimation('24h-volume', vol24hFormatted);

      const oi24hFormatted = formatter.format(totalOpenInterest);
      updateElementTextWithAnimation('24h-oi', oi24hFormatted);
    })
    .catch((error) => {
      console.error('Error updating Markets Summary values:', error);
    });
}

updateTVL();
setInterval(updateTVL, 10 * 1000);

updateMarketsSummary();
setInterval(updateMarketsSummary, 5 * 1000);

const ECOSYSTEM_REWARDS_HUB =
  'https://www.paradex.trade/ecosystem-rewards-hub';
const POINTS_DOCS_URL =
  'https://www.paradex.foundation/blog/introducing-dime-the-native-token-of-the-paradex-network';
const REFERRALS_URL = 'https://app.paradex.trade/referrals';

const BANNER_STYLES = {
  height: '36px',
};

function ThinCrossIcon(props) {
  return (
    <svg
      width={props.size}
      height={props.size}
      {...props}
      viewBox="0 0 8 8"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="m7.2 0 .8.8L4.8 4 8 7.2l-.8.8L4 4.8.8 8 0 7.2 3.2 4 0 .8.8 0 4 3.2 7.2 0Z"
        fill="currentColor"
        fillRule="evenodd"
      />
    </svg>
  );
}

const GIGAVAULT_ADDRESS =
  '0x5f43c92dbe4e995115f351254407e7e84abf04cbe32a536345b9d6c36bc750f';
const GIGAVAULT_APP_URL = `https://app.paradex.trade/vaults/${GIGAVAULT_ADDRESS}`;

function useGigaVaultApr() {
  const [gigaVaultApr, setGigaVaultApr] = React.useState(null);

  React.useEffect(() => {
    const fetchVaultData = async () => {
      try {
        const response = await fetch(
          `https://api.prod.paradex.trade/v1/vaults/summary?address=${GIGAVAULT_ADDRESS}`
        );
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        const apr = data?.results?.[0]?.last_month_return;
        console.log('giga vault results===>', data);
        if (apr != null && apr !== '') {
          const aprPercentage = Number(apr) * 100;
          setGigaVaultApr(`${aprPercentage.toFixed(2)}%`);
        }
      } catch (error) {
        console.error('Error fetching vault data:', error);
      }
    };

    fetchVaultData();
    const timer = setInterval(fetchVaultData, 10000);

    return () => {
      clearInterval(timer);
    };
  }, []);

  return gigaVaultApr;
}

const AnimatedTextBase = styled.span`
  @keyframes paradex_fadeUpAnimation {
    0% {
      opacity: 0;
      transform: translateY(-40%);
    }
    10% {
      opacity: 1;
      transform: translateY(-50%);
    }
    40% {
      opacity: 1;
      transform: translateY(-50%);
    }
    50% {
      opacity: 0;
      transform: translateY(-60%);
    }
    100% {
      opacity: 0;
      transform: translateY(-60%);
    }
  }

  display: flex;
  align-items: center;
  text-align: center;
  gap: 4px;
  top: 50%;
  position: absolute;
  animation: paradex_fadeUpAnimation 8s;
  width: 100%;
  height: 100%;
`;

const Container = styled.div.attrs({
  role: 'banner',
  'aria-label': 'Marketing Banner',
})`
  flex-shrink: 0;
  display: grid;
  grid-template-columns: 1fr auto;
  place-items: center;
  padding: 0 16px;
  height: ${BANNER_STYLES.height};
  background-image: linear-gradient(
    138deg,
    rgba(204, 56, 255, 0.81),
    rgba(188, 68, 255, 0.4) 95%
  );
  backdrop-filter: blur(10px);

  @media (max-width: 720px) {
    height: 52px;
  }
`;

const AnimatedTextContainer = styled.div`
  position: relative;
  display: flex;
  justify-content: center;
  color: '#fff' !important;
  opacity: 0.9;
  font-size: 13px;
  font-weight: 500;
  letter-spacing: 0;
  &:hover {
    opacity: unset;
  }
  width: 100%;
  height: 100%;
`;

const ExternalLink = styled.a.attrs({
  target: '_blank',
  rel: 'noopener',
})`
  color: inherit;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
`;

const CloseButton = styled.button.attrs({
  children: <ThinCrossIcon size={14} />,
  type: 'button',
  'aria-label': 'Close',
})`
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  line-height: 1px;
  border-radius: 4px;
  padding: 10px;

  &:hover {
    color: '#fff';
  }
`;

function MarketingBanner() {
  const [open, setOpen] = React.useState(true);
  const gigaVaultApr = useGigaVaultApr();
  const shouldDisplay = open;

  const handleClose = () => {
    setOpen(false);
  };

  const Texts = [
    <AnimatedTextBase key="0">
      <ExternalLink href={REFERRALS_URL}>
        <span>😀 Refer Friends: Earn 5% while they Save 5%! 😀</span>
      </ExternalLink>
    </AnimatedTextBase>,
    <AnimatedTextBase key="1">
      <ExternalLink href={POINTS_DOCS_URL}>
        <span>🚀 Learn about Season 2 for XP and the $DIME Airdrop 🚀</span>
      </ExternalLink>
    </AnimatedTextBase>,
    ...(gigaVaultApr != null && gigaVaultApr !== ''
      ? [
          <AnimatedTextBase key="2">
            <ExternalLink href={GIGAVAULT_APP_URL}>
              <span>{`🔥 Earn ${gigaVaultApr} APR by depositing in the Gigavault 🔥`}</span>
            </ExternalLink>
          </AnimatedTextBase>,
        ]
      : []),
  ];
  console.log('APR ===>', gigaVaultApr);
  console.log('texts length ===>', Texts.length);
  console.log('shouldDisplay ===>', shouldDisplay);

  const [currentText, setCurrentText] = React.useState(0);
  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentText((prevIndex) => (prevIndex + 1) % Texts.length);
    }, 4000);

    return () => {
      clearInterval(timer);
    };
  }, [Texts.length]);

  if (!shouldDisplay) return null;

  return (
    <Container>
      <AnimatedTextContainer>{Texts[currentText]}</AnimatedTextContainer>
      <CloseButton onClick={handleClose} />
    </Container>
  );
}

const HorizontalMarketsContainer = styled.div`
  height: 100%;
  width: 100%;
`;

const Shadow = styled.div`
  height: 100%;
  width: 100%;
  position: absolute;
  z-index: 3;
  --background: #181825;
  background-image: linear-gradient(
    to right,
    var(--background),
    rgba(26, 26, 44, 0) 20%,
    rgba(26, 26, 44, 0) 80%,
    var(--background)
  );
`;

const HorizontalMarketsWrapper = styled.div`
  @keyframes scroll-horizontal {
    from {
      transform: translateX(0%);
    }
    to {
      transform: translateX(-50%);
    }
  }

  gap: 10px;
  width: fit-content;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  overflow: hidden;
  white-space: nowrap;
  animation: scroll-horizontal 190s linear infinite;
  animation-delay: 1s;
  margin: 0;

  &:hover {
    -webkit-animation-play-state: paused;
    -moz-animation-play-state: paused;
    -o-animation-play-state: paused;
    animation-play-state: paused;
  }

  & > div:nth-child(2) {
    margin-left: 32px;
  }
`;

const MarketItemLink = styled.a`
  display: flex;
  background-color: rgba(242, 206, 255, 0.1);
  border-radius: 10px;
  flex-flow: column;
  justify-content: center;
  align-items: flex-start;
  width: 165px;
  padding: 8px 8px 8px 12px;
  backdrop-filter: blur(5px);

  &:hover {
    background-color: rgba(242, 206, 255, 0.2);
  }
`;

const Value = styled.span`
  font-size: 0.85rem;
  color: white;
  margin: 0;
`;

const Title = styled.span`
  font-size: 0.875rem;
  color: white;
`;

const HorizontalMarketsSubtitle = styled.span`
  font-size: 11px;
  color: #A3A3A3;
`;

const HorizontalMarketsAssetIcon = styled.img`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background-color: transparent;
`;

const HorizontalMarketsRowContainer = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;
  height: 100%;
  gap: 12px;
`;

const HorizontalMarketsValueChange = styled.span`
  font-size: 0.85rem;
  margin: 0 4px;
  ${({ direction }) =>
    direction != null &&
    `color: ${direction === 'up' ? '#00EE91' : '#FF005C'}`} !important;
`;

const HorizontalMarketsVertical = styled.div`
  display: flex;
  width: 100%;
  height: 100%;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  gap: 4px;
`;

const HorizontalMarketsHorizontal = styled.div`
  display: flex;
  width: 100%;
  height: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 12px;
`;

const Header = styled(HorizontalMarketsHorizontal)`
  justify-content: space-between;
`;

const HorizontalMarketsBadge = styled.div`
  display: inline-flex;
  font-size: 0.625rem;
  background-color: rgb(56, 56, 77);
  border-radius: 0.25rem;
  color: rgb(250, 250, 253);
  letter-spacing: 0.05em;
  line-height: 1.3;
  align-items: center;
  user-select: none;
  padding: 0.125rem 0.219rem 0.125rem 0.25rem;
`;

const sortDescByVolume = (a, b) => {
  return parseFloat(b.volume_24h ?? 0) - parseFloat(a.volume_24h ?? 0);
};

function directionSign(number) {
  const parsedNumber = parseFloat(number);
  if (parsedNumber > 0) {
    return 'up';
  } else if (parsedNumber < 0) {
    return 'down';
  }
  return null;
}

function formatMoney(amount, decimalCount = 2, decimal = '.', thousands = ',') {
  try {
    decimalCount = Math.abs(decimalCount);
    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;

    const negativeSign = amount < 0 ? '-' : '';

    let i = parseInt(
      (amount = Math.abs(Number(amount) || 0).toFixed(decimalCount))
    ).toString();
    let j = i.length > 3 ? i.length % 3 : 0;

    return (
      negativeSign +
      (j ? i.substr(0, j) + thousands : '') +
      i.substr(j).replace(/(\d{3})(?=\d)/g, '$1' + thousands) +
      (decimalCount
        ? decimal +
          Math.abs(amount - i)
            .toFixed(decimalCount)
            .slice(2)
        : '')
    );
  } catch (e) {
    console.log(e);
  }
}

const formatterThousands = Intl.NumberFormat('en-US', {
  notation: 'compact',
});

const formatterChange = new Intl.NumberFormat('en-US', {
  style: 'percent',
  maximumFractionDigits: 2,
  minimumFractionDigits: 2,
  signDisplay: 'always',
});

function formatPercentChange(value) {
  return value ? formatterChange.format(parseFloat(value)) : '-';
}

function formatThausands(value) {
  return value ? `$${formatterThousands.format(parseFloat(value))}` : '-';
}

function MarketItem({ market }) {
  const link = `https://app.paradex.trade/trade/${market.symbol}`;
  const direction = directionSign(market.price_change_rate_24h);
  const priceChangePercent = formatPercentChange(market.price_change_rate_24h);
  const underlyingPrice = formatMoney(market.underlying_price);

  return (
    <MarketItemLink key={market.symbol} href={link} target="_blank">
      <HorizontalMarketsVertical>
        <Title>{market.symbol}</Title>
        <HorizontalMarketsHorizontal>
          <Value>${underlyingPrice}</Value>
          <HorizontalMarketsValueChange direction={direction}>
            {priceChangePercent}
          </HorizontalMarketsValueChange>
        </HorizontalMarketsHorizontal>
      </HorizontalMarketsVertical>
    </MarketItemLink>
  );
}

function HorizontalMarkets() {
  const [markets, setMarkets] = React.useState([]);

  React.useEffect(() => {
    const fetchMarkets = async () => {
      try {
        const response = await fetch(
          'https://api.prod.paradex.trade/v1/markets/summary?market=ALL'
        );
        const data = await response.json();
        setMarkets(
          data.results
            .filter((m) => m.symbol !== 'USDC')
            .sort(sortDescByVolume)
        );
      } catch (error) {
        console.error('Error fetching markets:', error);
      }
    };

    fetchMarkets();
    const interval = setInterval(fetchMarkets, 40000);
    return () => clearInterval(interval);
  }, []);

  console.log('===========>', markets);

  return (
    <HorizontalMarketsContainer>
      <HorizontalMarketsWrapper>
        <HorizontalMarketsRowContainer>
          {markets?.map((market) => (
            <MarketItem market={market} key={market.symbol} />
          ))}
        </HorizontalMarketsRowContainer>
      </HorizontalMarketsWrapper>
    </HorizontalMarketsContainer>
  );
}

// Монтирование компонентов в контейнеры index.html
ReactDOM.render(
  <MarketingBanner />,
  document.getElementById('paradex-react-component-marketing-banner')
);

ReactDOM.render(
  <HorizontalMarkets />,
  document.getElementById('markets-horizontal-infinite-scroll')
);
