
import { ReactNode } from 'react';
import AdminSidebar from '@/components/AdminSidebar';
import { useIsMobile } from '@/hooks/use-mobile';

type AdminLayoutProps = {
  children: ReactNode;
};

const AdminLayout = ({ children }: AdminLayoutProps) => {
  const isMobile = useIsMobile();
  
  return (
    <div className="flex min-h-screen bg-background">
      <AdminSidebar />
      <div className={`flex-1 ${isMobile ? 'ml-[70px]' : 'ml-[250px]'} transition-all duration-300`}>
        <div className="container py-8 px-4 md:px-6">
          {children}
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
