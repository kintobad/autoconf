
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>About Budsy | Premium Cannabis Products</title>
        <meta name="description" content="Learn about Budsy, our mission, and the team behind our premium cannabis products." />
      </Helmet>
      
      <Navbar />
      
      <main className="flex-grow container mx-auto py-8 px-4 mt-16">
        <h1 className="text-4xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">About Budsy</h1>
        <p className="text-lg text-muted-foreground mb-8">Discover the story behind our premium cannabis brand</p>
        
        <Tabs defaultValue="company" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="company">Our Company</TabsTrigger>
            <TabsTrigger value="mission">Our Mission</TabsTrigger>
          </TabsList>
          
          <TabsContent value="company" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Our Story</CardTitle>
                <CardDescription>From seed to success: The Budsy journey</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                  <div>
                    <p className="mb-4">
                      Founded in 2020 by a group of cannabis enthusiasts and industry experts, Budsy began with a simple mission: 
                      to create premium, sustainably sourced cannabis products that enhance people's lives and challenge industry norms.
                    </p>
                    <p>
                      What started as a small direct-to-consumer operation has evolved into one of the fastest-growing cannabis brands 
                      in the market. We've expanded our product line to include a diverse range of flowers, extracts, edibles, and accessories, 
                      all crafted with our commitment to quality and innovation.
                    </p>
                  </div>
                  <div className="order-first md:order-last">
                    <img 
                      src="/placeholder.svg" 
                      alt="Budsy founding team" 
                      className="w-full rounded-lg shadow-md" 
                    />
                  </div>
                </div>
                
                <div className="mt-8">
                  <h3 className="text-xl font-semibold mb-4">Our Growth</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { number: "2020", text: "Year Founded" },
                      { number: "50+", text: "Team Members" },
                      { number: "20,000+", text: "Happy Customers" },
                      { number: "100+", text: "Premium Products" }
                    ].map((stat, index) => (
                      <div key={index} className="bg-muted p-4 rounded-lg text-center">
                        <p className="text-3xl font-bold text-primary">{stat.number}</p>
                        <p className="text-sm text-muted-foreground">{stat.text}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="mission" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Our Mission & Values</CardTitle>
                <CardDescription>What drives us every day</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-muted p-6 rounded-lg border border-border">
                  <h3 className="text-xl font-semibold text-center mb-4">Mission Statement</h3>
                  <p className="text-center text-lg italic">
                    "To provide exceptional cannabis products that enhance wellbeing, foster community, 
                    and promote sustainability through ethical practices and innovation."
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                  {[
                    {
                      title: "Quality",
                      description: "We maintain rigorous standards throughout our supply chain, from cultivation to delivery."
                    },
                    {
                      title: "Sustainability",
                      description: "We're committed to environmentally responsible practices in growing, processing, and packaging."
                    },
                    {
                      title: "Education",
                      description: "We believe in empowering customers with knowledge about cannabis products and their effects."
                    },
                    {
                      title: "Innovation",
                      description: "We continuously explore new methods and technologies to improve our products."
                    },
                    {
                      title: "Community",
                      description: "We actively support and engage with local communities through various initiatives."
                    },
                    {
                      title: "Transparency",
                      description: "We provide clear information about our products, ingredients, and practices."
                    }
                  ].map((value, index) => (
                    <div key={index} className="p-4 rounded-lg border">
                      <h4 className="font-bold text-lg mb-2 text-primary">{value.title}</h4>
                      <p className="text-sm">{value.description}</p>
                    </div>
                  ))}
                </div>
                
                <Separator className="my-6" />
                
                <div className="flex flex-col items-center">
                  <h3 className="text-xl font-semibold mb-4">Join Our Journey</h3>
                  <p className="text-center mb-6 max-w-2xl">
                    We're always looking for passionate individuals and partners who share our values and vision. 
                    Whether you're interested in career opportunities, business partnerships, or community initiatives, 
                    we'd love to hear from you.
                  </p>
                  <Button size="lg" className="hover-up">Contact Us</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      <Footer />
    </div>
  );
};

export default About;
