import { useEffect, useState } from 'react';
import { Post } from '@/lib/models';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Edit, Trash2, Eye } from 'lucide-react';
import PostFormDialog from '@/components/admin/PostFormDialog';
import DeleteConfirmDialog from '@/components/admin/DeleteConfirmDialog';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'react-router-dom';

const API_URL = 'http://localhost:3001/api/admin/posts';

const Posts = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isAddPostOpen, setIsAddPostOpen] = useState(false);
  const [isEditPostOpen, setIsEditPostOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);

  const fetchPosts = async () => {
    try {
      const res = await fetch(API_URL);
      const data = await res.json();
      setPosts(data);
    } catch (error: any) {
      toast({ title: 'Error fetching posts', description: error.message });
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const categories = Array.from(new Set(posts.map(post => post.category)));

  const filteredPosts = posts.filter(post => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = categoryFilter === 'all' || post.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || post.status === statusFilter;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleAddPost = () => {
    setSelectedPost(null);
    setIsAddPostOpen(true);
  };

  const handleEditPost = (post: Post) => {
    setSelectedPost(post);
    setIsEditPostOpen(true);
  };

  const handleDeletePost = (post: Post) => {
    setSelectedPost(post);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!selectedPost) return;

    try {
      const res = await fetch(`${API_URL}/${selectedPost.id}`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('Failed to delete post');
      setPosts(prev => prev.filter(p => p.id !== selectedPost.id));
      toast({ title: 'Post deleted' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message });
    }
    setIsDeleteConfirmOpen(false);
  };

  const handleSavePost = async (post: Post) => {
  const isNew = !post.id;
  const method = isNew ? 'POST' : 'PUT';
  const url = isNew ? API_URL : `${API_URL}/${post.id}`;

  const { id, createdAt, updatedAt, imageUrl, ...rest } = post;

  const safePost = {
    ...rest,
    imageurl: imageUrl ?? null, 
  };

  try {
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(safePost),
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.error || 'Failed to save post');

    setPosts(prev => {
      const exists = prev.find(p => p.id === data.id);
      return exists ? prev.map(p => (p.id === data.id ? data : p)) : [data, ...prev];
    });

    toast({ title: 'Post saved' });
    setIsAddPostOpen(false);
    setIsEditPostOpen(false);
  } catch (error: any) {
    toast({ title: 'Error', description: error.message });
  }
};


  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    }).format(date);
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Blog Posts</h2>
        <p className="text-muted-foreground">Manage your blog content.</p>
      </div>

      <div className="flex justify-between items-center">
        <Button onClick={handleAddPost}>
          <Plus size={16} className="mr-2" /> Add New Post
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search posts..."
            className="pl-9"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="w-full sm:w-48">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-full sm:w-48">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="published">Published</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Blog Posts</CardTitle>
          <CardDescription>{filteredPosts.length} posts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPosts.map(post => (
                  <TableRow key={post.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <img
                          src={post.imageUrl || 'https://placehold.co/100'}
                          alt={post.title}
                          className="w-10 h-10 object-cover rounded"
                        />
                        <div className="flex flex-col">
                          <span className="font-medium">{post.title}</span>
                          <span className="text-xs text-muted-foreground truncate max-w-[300px]">
                            {post.excerpt?.substring(0, 80)}...
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{post.category}</TableCell>
                    <TableCell>
                      <Badge variant={post.status === 'published' ? 'default' : 'outline'}>
                        {post.status === 'published' ? 'Published' : 'Draft'}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatDate(post.updatedAt)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {post.status === 'published' && (
                          <Button variant="outline" size="sm" asChild>
                            <Link to={`/blog/${post.slug}`} target="_blank">
                              <Eye size={14} />
                            </Link>
                          </Button>
                        )}
                        <Button variant="outline" size="sm" onClick={() => handleEditPost(post)}>
                          <Edit size={14} />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeletePost(post)} className="text-destructive hover:bg-destructive/10">
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {isAddPostOpen && (
        <PostFormDialog
          isOpen={isAddPostOpen}
          onClose={() => setIsAddPostOpen(false)}
          mode="add"
          onSave={handleSavePost}
        />
      )}

      {isEditPostOpen && selectedPost && (
        <PostFormDialog
          isOpen={isEditPostOpen}
          onClose={() => setIsEditPostOpen(false)}
          mode="edit"
          post={selectedPost}
          onSave={handleSavePost}
        />
      )}

      {isDeleteConfirmOpen && selectedPost && (
        <DeleteConfirmDialog
          open={isDeleteConfirmOpen}
          onOpenChange={setIsDeleteConfirmOpen}
          onConfirm={handleDeleteConfirm}
          title="Delete Post"
          description={`Are you sure you want to delete "${selectedPost.title}"? This action cannot be undone.`}
        />
      )}
    </div>
  );
};

export default Posts;
