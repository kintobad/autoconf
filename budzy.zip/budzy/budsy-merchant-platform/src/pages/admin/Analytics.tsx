  import { useState, useEffect } from "react";
  import { Helmet } from "react-helmet";
  import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
    ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell
  } from "recharts";

  import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
  import {
    Card, CardContent, CardDescription, CardHeader, CardTitle
  } from "@/components/ui/card";
  import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue
  } from "@/components/ui/select";
  import {
    ArrowUpRight, TrendingUp, DollarSign, Users, Package
  } from "lucide-react";

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"];

  const Analytics = () => {
    const [timeFrame, setTimeFrame] = useState("last30days");
    const [overview, setOverview] = useState({
      totalRevenue: 0,
      totalOrders: 0,
      totalCustomers: 0,
      conversionRate: 0,
    });
    const [monthlySalesData, setMonthlySalesData] = useState([]);
    const [salesByCategory, setSalesByCategory] = useState([]);
    const [trafficData, setTrafficData] = useState([]);

  useEffect(() => {
    // Fetch overview
    fetch("http://localhost:3001/api/admin/analytics/overview")
      .then((res) => res.json())
      .then(setOverview)
      .catch((err) => console.error("Overview fetch error:", err));

    // Fetch monthly sales
    fetch("http://localhost:3001/api/admin/analytics/monthly-sales")
      .then((res) => res.json())
      .then((data) => {
        const formatted = data.map((item) => ({
          name: item.month,
          sales: item.sales,
          orders: item.orders,
        }));
        setMonthlySalesData(formatted);
      })
      .catch((err) => console.error("Monthly sales fetch error:", err));

    // Fetch product category sales
    fetch("http://localhost:3001/api/admin/analytics/product-category-sales")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setSalesByCategory(data);
        else setSalesByCategory([]);
      })
      .catch((err) => console.error("Product category sales fetch error:", err));

    // Fetch traffic with timeFrame
    fetch(`http://localhost:3001/api/admin/analytics/daily-traffic?range=${timeFrame}`)
      .then((res) => res.json())
      .then((data) => {
        console.log("Traffic API:", data);
        if (Array.isArray(data)) setTrafficData(data);
        else setTrafficData([]);
      })
      .catch((err) => console.error("Traffic fetch error:", err));
  }, [timeFrame]);


    return (
      <>
        <Helmet>
          <title>Analytics | Budsy Admin</title>
        </Helmet>

        <div className="space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
              <p className="text-muted-foreground">Analyze your shop's performance with detailed metrics</p>
            </div>
            <Select value={timeFrame} onValueChange={setTimeFrame}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select time frame" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="last7days">Last 7 Days</SelectItem>
                <SelectItem value="last30days">Last 30 Days</SelectItem>
                <SelectItem value="thisMonth">This Month</SelectItem>
                <SelectItem value="lastMonth">Last Month</SelectItem>
                <SelectItem value="thisYear">This Year</SelectItem>
                <SelectItem value="custom">Custom Range</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: "Total Revenue", icon: DollarSign, value: `£${overview.totalRevenue.toFixed(2)}`, change: "+12.5%" },
              { title: "Total Orders", icon: Package, value: overview.totalOrders, change: "+8.2%" },
              { title: "Total Customers", icon: Users, value: overview.totalCustomers, change: "+5.7%" },
              { title: "Conversion Rate", icon: TrendingUp, value: `${overview.conversionRate.toFixed(1)}%`, change: "+1.1%" }
            ].map((card, idx) => (
              <Card key={idx}>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
                  <card.icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{card.value}</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500 inline-flex items-center">
                      {card.change} <ArrowUpRight className="h-3 w-3 ml-1" />
                    </span>{" "}from last period
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Tabs */}
          <Tabs defaultValue="sales">
            <TabsList className="mb-4">
              <TabsTrigger value="sales">Sales</TabsTrigger>
              <TabsTrigger value="products">Products</TabsTrigger>
              <TabsTrigger value="traffic">Traffic</TabsTrigger>
            </TabsList>

            {/* Sales */}
            <TabsContent value="sales" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Sales</CardTitle>
                  <CardDescription>Revenue and orders by month</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlySalesData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Bar yAxisId="left" dataKey="sales" name="Revenue (£)" fill="#8884d8" />
                      <Bar yAxisId="right" dataKey="orders" name="Orders" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Products */}
            <TabsContent value="products" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Sales by Category</CardTitle>
                  <CardDescription>Revenue breakdown by category</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={salesByCategory}
                        cx="50%"
                        cy="50%"
                        labelLine
                        label={({ name, percent }) =>
                          `${name}: ${(percent * 100).toFixed(0)}%`
                        }
                        outerRadius={150}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {salesByCategory.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `£${value}`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Traffic */}
            <TabsContent value="traffic" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Daily Website Traffic</CardTitle>
                  <CardDescription>Visitors per weekday</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trafficData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="visitors" name="Visitors" stroke="#8884d8" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </>
    );
  };

  export default Analytics;
