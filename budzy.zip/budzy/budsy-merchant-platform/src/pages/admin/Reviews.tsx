import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Star, Search, MessageSquare, CheckCircle, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import DeleteConfirmDialog from "@/components/admin/DeleteConfirmDialog";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";

interface Review {
  id: string;
  productId: string;
  productName: string;
  productImage: string;
  customer: {
    id: string;
    name: string;
    avatar: string;
  };
  rating: number;
  comment: string;
  date: string;
  status: "published" | "pending" | "rejected";
}

const Reviews = () => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [ratingFilter, setRatingFilter] = useState<string>("all");
  const [isLoading, setIsLoading] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [reviewToDelete, setReviewToDelete] = useState<Review | null>(null);
  const [viewedReview, setViewedReview] = useState<Review | null>(null);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const res = await fetch("/api/admin/reviews");
        const data = await res.json();
        setReviews(data);
      } catch (error) {
        toast.error("Failed to fetch reviews");
      }
    };

    fetchReviews();
  }, []);

  const filteredReviews = reviews.filter((review) => {
    const matchesSearch =
      review.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.comment.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === "all" || review.status === statusFilter;
    const matchesRating = ratingFilter === "all" || review.rating === parseInt(ratingFilter);

    return matchesSearch && matchesStatus && matchesRating;
  });

  const handleOpenDeleteDialog = (review: Review) => {
    setReviewToDelete(review);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!reviewToDelete) return;
    setIsLoading(true);

    try {
      const res = await fetch(`/api/admin/reviews/${reviewToDelete.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();

      setReviews(reviews.filter((r) => r.id !== reviewToDelete.id));
      toast.success("Review deleted successfully");
    } catch {
      toast.error("Failed to delete review");
    } finally {
      setIsLoading(false);
      setDeleteDialogOpen(false);
      setReviewToDelete(null);
    }
  };

  const handleChangeStatus = async (reviewId: string, newStatus: "published" | "pending" | "rejected") => {
    try {
      const res = await fetch(`/api/admin/reviews/${reviewId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      if (!res.ok) throw new Error();

      setReviews(reviews.map(r => r.id === reviewId ? { ...r, status: newStatus } : r));
      toast.success(`Status updated to ${newStatus}`);
    } catch {
      toast.error("Failed to update status");
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, i) => (
      <Star key={i} className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
    ));
  };

  return (
    <>
      <Helmet>
        <title>Reviews Management | Budsy Admin</title>
      </Helmet>

      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reviews</h1>
          <p className="text-muted-foreground">Manage customer reviews and ratings</p>
        </div>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search reviews..."
              className="w-full pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="published">Published</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
          <Select value={ratingFilter} onValueChange={setRatingFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Filter by rating" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Ratings</SelectItem>
              <SelectItem value="5">5 Stars</SelectItem>
              <SelectItem value="4">4 Stars</SelectItem>
              <SelectItem value="3">3 Stars</SelectItem>
              <SelectItem value="2">2 Stars</SelectItem>
              <SelectItem value="1">1 Star</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Rating</TableHead>
                <TableHead>Review</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredReviews.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    No reviews found. Try changing your filters.
                  </TableCell>
                </TableRow>
              ) : (
                filteredReviews.map((review) => (
                  <TableRow key={review.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={review.productImage} alt={review.productName} />
                          <AvatarFallback>{review.productName.substring(0, 2)}</AvatarFallback>
                        </Avatar>
                        <span>{review.productName}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={review.customer.avatar} alt={review.customer.name} />
                          <AvatarFallback>{review.customer.name.substring(0, 2)}</AvatarFallback>
                        </Avatar>
                        <span>{review.customer.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex">{renderStars(review.rating)}</div>
                    </TableCell>
                    <TableCell className="max-w-[300px]">
                      <p className="truncate">{review.comment}</p>
                    </TableCell>
                    <TableCell>{new Date(review.date).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          review.status === "published"
                            ? "bg-green-100 text-green-800 hover:bg-green-100"
                            : review.status === "pending"
                            ? "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                            : "bg-red-100 text-red-800 hover:bg-red-100"
                        }
                      >
                        {review.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        title="View full review"
                        onClick={() => setViewedReview(review)}
                      >
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                      {review.status !== "published" && (
                        <Button
                          size="icon"
                          variant="ghost"
                          title="Approve review"
                          onClick={() => handleChangeStatus(review.id, "published")}
                        >
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        </Button>
                      )}
                      {review.status !== "rejected" && (
                        <Button
                          size="icon"
                          variant="ghost"
                          title="Reject review"
                          onClick={() => handleChangeStatus(review.id, "rejected")}
                        >
                          <XCircle className="h-4 w-4 text-red-600" />
                        </Button>
                      )}
                      <Button
                        size="icon"
                        variant="ghost"
                        title="Delete review"
                        onClick={() => handleOpenDeleteDialog(review)}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="h-4 w-4 text-red-600"
                        >
                          <path d="M3 6h18"></path>
                          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path>
                          <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <DeleteConfirmDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={handleDelete}
        isLoading={isLoading}
        title="Delete Review"
        description={
          reviewToDelete
            ? `Are you sure you want to delete this review from ${reviewToDelete.customer.name}? This action cannot be undone.`
            : "Are you sure you want to delete this review?"
        }
      />

      <Dialog open={!!viewedReview} onOpenChange={() => setViewedReview(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Review by {viewedReview?.customer.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <p><strong>Product:</strong> {viewedReview?.productName}</p>
            <p><strong>Rating:</strong> {viewedReview?.rating} stars</p>
            <p><strong>Date:</strong> {new Date(viewedReview?.date || "").toLocaleDateString()}</p>
            <p><strong>Comment:</strong></p>
            <p>{viewedReview?.comment}</p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Reviews;
