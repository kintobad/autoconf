import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Search, History as HistoryIcon, User, Settings, Package,
  ShoppingCart, CreditCard, Tag,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

// Интерфейс истории
interface HistoryEvent {
  id: string;
  action: string;
  actionType: "create" | "update" | "delete" | "login" | "other";
  entityType: "user" | "product" | "order" | "category" | "payment" | "setting";
  entityId: string;
  entityName: string;
  performedBy: {
    id: string;
    name: string;
    avatar: string;
    role: string;
  };
  timestamp: string;
  details?: string;
}

const HistoryPage = () => {
  const [history, setHistory] = useState<HistoryEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState("");
  const [actionTypeFilter, setActionTypeFilter] = useState("all");
  const [entityTypeFilter, setEntityTypeFilter] = useState("all");
  const [userFilter, setUserFilter] = useState("all");

  // Загрузка истории с сервера
  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const res = await fetch(`${import.meta.env.VITE_API_URL}/admin/history`);

        const data = await res.json();
        setHistory(data);
      } catch (err: any) {
        setError("Failed to load activity history.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, []);

  const users = [...new Set(history.map(e => e.performedBy.name))];

  const filteredHistory = history.filter(event => {
    const matchesSearch =
      event.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.entityName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (event.details && event.details.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesActionType = actionTypeFilter === "all" || event.actionType === actionTypeFilter;
    const matchesEntityType = entityTypeFilter === "all" || event.entityType === entityTypeFilter;
    const matchesUser = userFilter === "all" || event.performedBy.name === userFilter;
    return matchesSearch && matchesActionType && matchesEntityType && matchesUser;
  });

  const getActionTypeBadge = (actionType: string) => {
    switch (actionType) {
      case "create":
        return <Badge className="bg-green-100 text-green-800">Created</Badge>;
      case "update":
        return <Badge className="bg-blue-100 text-blue-800">Updated</Badge>;
      case "delete":
        return <Badge className="bg-red-100 text-red-800">Deleted</Badge>;
      case "login":
        return <Badge className="bg-purple-100 text-purple-800">Login</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Other</Badge>;
    }
  };

  const getEntityTypeIcon = (entityType: string) => {
    switch (entityType) {
      case "user": return <User className="h-4 w-4" />;
      case "product": return <Package className="h-4 w-4" />;
      case "order": return <ShoppingCart className="h-4 w-4" />;
      case "category": return <Tag className="h-4 w-4" />;
      case "payment": return <CreditCard className="h-4 w-4" />;
      case "setting": return <Settings className="h-4 w-4" />;
      default: return <HistoryIcon className="h-4 w-4" />;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit", month: "short", year: "numeric",
      hour: "2-digit", minute: "2-digit"
    }).format(date);
  };

  return (
    <>
      <Helmet>
        <title>Activity History | Budsy Admin</title>
      </Helmet>

      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Activity History</h1>
          <p className="text-muted-foreground">Track all changes and actions in the system</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search activity..."
              className="w-full pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={actionTypeFilter} onValueChange={setActionTypeFilter}>
            <SelectTrigger className="w-full md:w-40"><SelectValue placeholder="Action Type" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem>
              <SelectItem value="create">Create</SelectItem>
              <SelectItem value="update">Update</SelectItem>
              <SelectItem value="delete">Delete</SelectItem>
              <SelectItem value="login">Login</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          <Select value={entityTypeFilter} onValueChange={setEntityTypeFilter}>
            <SelectTrigger className="w-full md:w-40"><SelectValue placeholder="Entity Type" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Entities</SelectItem>
              <SelectItem value="user">User</SelectItem>
              <SelectItem value="product">Product</SelectItem>
              <SelectItem value="order">Order</SelectItem>
              <SelectItem value="category">Category</SelectItem>
              <SelectItem value="payment">Payment</SelectItem>
              <SelectItem value="setting">Setting</SelectItem>
            </SelectContent>
          </Select>
          <Select value={userFilter} onValueChange={setUserFilter}>
            <SelectTrigger className="w-full md:w-40"><SelectValue placeholder="User" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Users</SelectItem>
              {users.map(user => (
                <SelectItem key={user} value={user}>{user}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Table */}
        <div className="rounded-md border">
          {loading ? (
            <div className="p-6 text-center text-muted-foreground">Loading...</div>
          ) : error ? (
            <div className="p-6 text-center text-red-500">{error}</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Action</TableHead>
                  <TableHead>Entity</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredHistory.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      No activity found. Try changing your filters.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredHistory.map(event => (
                    <TableRow key={event.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getActionTypeBadge(event.actionType)}
                          <span>{event.action}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getEntityTypeIcon(event.entityType)}
                          <span>{event.entityName}</span>
                          <span className="text-xs text-muted-foreground">(ID: {event.entityId})</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={event.performedBy.avatar} alt={event.performedBy.name} />
                            <AvatarFallback>{event.performedBy.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div className="flex flex-col">
                            <span>{event.performedBy.name}</span>
                            <span className="text-xs text-muted-foreground">{event.performedBy.role}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{formatDate(event.timestamp)}</TableCell>
                      <TableCell className="max-w-md">{event.details || "-"}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          )}
        </div>
      </div>
    </>
  );
};

export default HistoryPage;
