import { useEffect, useState } from 'react';
import { BarChart2, DollarSign, Package, Users } from 'lucide-react';
import AdminCard from '@/components/AdminCard';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabaseClient';

type Order = {
  id: string;
  customer: string;
  date: string;
  status: 'completed' | 'pending' | 'processing' | 'cancelled';
  total?: number; 
};

type User = {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  orderCount?: number;
  totalSpent?: number;
};

type Stats = {
  totalSales: number;
  orderCount: number;
  userCount: number;
  completionRate: number;
};

const fetchWithAuth = async (url: string) => {
  const { data, error } = await supabase.auth.getSession();
  const token = data.session?.access_token;

  if (!token || error) {
    console.error('❌ Нет токена');
    throw new Error('Not authenticated');
  }

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`❌ ${res.status}: ${errText}`);
  }

  return res.json();
};

const Dashboard = () => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [visitorCount, setVisitorCount] = useState(0);

  const { user, loading } = useAuth();

  useEffect(() => {
    if (loading || !user) return;

    fetchWithAuth('/api/admin/stats')
      .then(setStats)
      .catch(console.error);

    fetchWithAuth('/api/admin/orders/recent')
      .then(setOrders)
      .catch(console.error);

    fetchWithAuth('/api/admin/users/recent')
      .then(setUsers)
      .catch(console.error);

    setVisitorCount(Math.floor(Math.random() * 1000) + 500);
  }, [loading, user]);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Welcome to Budsy Cannabis E-Shop admin panel.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <AdminCard
          title="Total Sales"
          value={stats ? `£${stats.totalSales.toFixed(2)}` : '...'}
          icon={<DollarSign />}
          trend={{ value: 12.5, positive: true }}
        />
        <AdminCard
          title="Orders"
          value={stats ? stats.orderCount : '...'}
          icon={<Package />}
          trend={{ value: 8.2, positive: true }}
        />
        <AdminCard
          title="Visitors"
          value={visitorCount}
          icon={<Users />}
          trend={{ value: 5.1, positive: true }}
        />
        <AdminCard
          title="Completion Rate"
          value={stats ? `${stats.completionRate}%` : '...'}
          icon={<BarChart2 />}
          trend={{ value: 2.3, positive: true }}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>
              You have {stats?.orderCount ?? '...'} total orders
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between border-b pb-2"
                >
                  <div>
                    <p className="font-medium">{order.customer}</p>
                    <p className="text-sm text-muted-foreground">{order.date}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        order.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : order.status === 'cancelled'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                    <span className="font-medium">
                      £{typeof order.total === 'number' ? order.total.toFixed(2) : '0.00'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Recent Users</CardTitle>
            <CardDescription>
              You have {stats?.userCount ?? '...'} total users
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {users.map((user) => (
                <div key={user.id} className="flex items-center gap-4 border-b pb-2">
                  <img
                    src={user.avatar || 'https://i.pravatar.cc/100?u=placeholder'}
                    alt={user.name}
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <p className="font-medium leading-none">{user.name}</p>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                  <div className="text-sm text-right">
                    <p className="font-medium">{user.orderCount ?? 0} orders</p>
                    <p className="text-muted-foreground">
                      £{typeof user.totalSpent === 'number' ? user.totalSpent.toFixed(2) : '0.00'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
