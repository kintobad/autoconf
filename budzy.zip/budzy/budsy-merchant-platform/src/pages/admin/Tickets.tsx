import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  Inbox,
  ArrowUpRight,
  MessageSquare,
  CheckCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import axios from "axios";

interface TicketPriority {
  value: string;
  label: string;
  color: string;
}

const priorities: TicketPriority[] = [
  { value: "low", label: "Low", color: "bg-blue-100 text-blue-800 hover:bg-blue-100" },
  { value: "medium", label: "Medium", color: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100" },
  { value: "high", label: "High", color: "bg-orange-100 text-orange-800 hover:bg-orange-100" },
  { value: "urgent", label: "Urgent", color: "bg-red-100 text-red-800 hover:bg-red-100" },
];

interface TicketStatus {
  value: string;
  label: string;
  color: string;
}

const statuses: TicketStatus[] = [
  { value: "open", label: "Open", color: "bg-green-100 text-green-800 hover:bg-green-100" },
  { value: "in_progress", label: "In Progress", color: "bg-blue-100 text-blue-800 hover:bg-blue-100" },
  { value: "waiting", label: "Waiting", color: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100" },
  { value: "resolved", label: "Resolved", color: "bg-gray-100 text-gray-800 hover:bg-gray-100" },
  { value: "closed", label: "Closed", color: "bg-gray-100 text-gray-800 hover:bg-gray-100" },
];

interface Ticket {
  id: string;
  subject: string;
  customer: {
    id: string;
    name: string;
    email: string;
    avatar: string;
  };
  department: string;
  priority: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  lastResponse?: string;
}

const Tickets = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const { toast } = useToast();

  useEffect(() => {
    fetchTickets();
  }, []);

const fetchTickets = async () => {
  try {
    const res = await axios.get<Ticket[]>(
      `${import.meta.env.VITE_API_URL}/api/admin/tickets`
    );
    setTickets(res.data); 
  } catch (error) {
    console.error("Error loading tickets", error);
    toast({ title: "Error", description: "Failed to fetch tickets" });
  }
};


  const updateTicket = async (id: string, updates: Partial<Ticket>) => {
    try {
      await axios.patch(`/api/admin/tickets/${id}`, updates);
      fetchTickets();
      toast({ title: "Success", description: `Ticket ${id} updated.` });
    } catch (err) {
      console.error("Error updating ticket", err);
      toast({ title: "Error", description: `Failed to update ticket ${id}` });
    }
  };

  const departments = [...new Set(tickets.map(ticket => ticket.department))];

  const filteredTickets = tickets.filter((ticket) => {
    const matchesSearch =
      ticket.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.customer.email.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === "all" || ticket.status === statusFilter;
    const matchesPriority = priorityFilter === "all" || ticket.priority === priorityFilter;
    const matchesDepartment = departmentFilter === "all" || ticket.department === departmentFilter;

    return matchesSearch && matchesStatus && matchesPriority && matchesDepartment;
  });

  const getStatusBadge = (statusValue: string) => {
    const status = statuses.find(s => s.value === statusValue);
    return <Badge variant="outline" className={status?.color}>{status?.label}</Badge>;
  };

  const getPriorityBadge = (priorityValue: string) => {
    const priority = priorities.find(p => p.value === priorityValue);
    return <Badge variant="outline" className={priority?.color}>{priority?.label}</Badge>;
  };

  const formatRelativeDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
    if (diff < 60) return `${diff} sec ago`;
    const min = Math.floor(diff / 60);
    if (min < 60) return `${min} min ago`;
    const hrs = Math.floor(min / 60);
    if (hrs < 24) return `${hrs} hr ago`;
    const days = Math.floor(hrs / 24);
    return `${days} day${days !== 1 ? 's' : ''} ago`;
  };

  const handleResolveTicket = (ticketId: string) => {
    updateTicket(ticketId, { status: 'resolved' });
  };

  return (
    <>
      <Helmet><title>Tickets Management</title></Helmet>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Support Tickets</h1>
          <Button><Inbox className="mr-2 h-4 w-4" /> New Ticket</Button>
        </div>

        <div className="flex gap-4">
          <Input
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              {statuses.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              {priorities.map(p => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
            <SelectTrigger><SelectValue placeholder="Department" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              {departments.map(dep => <SelectItem key={dep} value={dep}>{dep}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ticket</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Updated</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTickets
                  .filter(ticket => ticket.customer && ticket.customer.name && ticket.customer.email)
                  .map(ticket => (

                <TableRow key={ticket.id}>
                  
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-semibold">{ticket.id}</span>
                      <span>{ticket.subject}</span>
                      <span className="text-xs text-muted-foreground">Created {formatRelativeDate(ticket.createdAt)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={ticket.customer.avatar} alt={ticket.customer.name} />
                        <AvatarFallback>
                          {ticket.customer?.name
                            ? ticket.customer.name.slice(0, 2).toUpperCase()
                            : "NA"}
                        </AvatarFallback>

                      </Avatar>
                      <div className="flex flex-col">
                        <span>{ticket.customer.name}</span>
                        <span className="text-xs text-muted-foreground">{ticket.customer.email}</span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{ticket.department}</TableCell>
                  <TableCell>{getPriorityBadge(ticket.priority)}</TableCell>
                  <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                  <TableCell>{formatRelativeDate(ticket.updatedAt)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-2 justify-end">
                      <Button size="sm" variant="outline" onClick={() => console.log(ticket.id)}>
                        <ArrowUpRight className="h-4 w-4" />
                        <span className="sr-only md:not-sr-only md:ml-2">View</span>
                      </Button>
                      {ticket.status !== 'resolved' && ticket.status !== 'closed' && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-green-700 border-green-200 hover:bg-green-50"
                          onClick={() => handleResolveTicket(ticket.id)}
                        >
                          <CheckCircle className="h-4 w-4" />
                          <span className="sr-only md:not-sr-only md:ml-2">Resolve</span>
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </>
  );
};

export default Tickets;
