import { useAuth } from "@/context/AuthContext";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

import {
  ShoppingCart,
  ArrowLeft,
  Trash2,
  CreditCard,
  Truck,
  Package,
  Shield,
} from "lucide-react";

import { toast } from "sonner";
import CartItem from "@/components/CartItem";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useAppKit } from "@reown/appkit/react";
import { useMerchantAddress } from "@/hooks/useMerchantAddress";
import BTCModal from "@/components/BTCModal";

export default function Cart() {
  const { user, loading } = useAuth();
  const { cartItems, clearCart, cartTotal } = useCart();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [shippingOption, setShippingOption] = useState("standard");
  const [withStealthBox, setWithStealthBox] = useState(false);
  const [btcModalData, setBtcModalData] = useState<{
    address: string;
    orderNumber: string;
  } | null>(null);
  const { open } = useAppKit();
  const merchantAddress = useMerchantAddress(0);

  useEffect(() => {
    if (!user) {
      clearCart();
    }
  }, [user]);

  if (loading) {
    return (
      <div className="py-16 text-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-center px-4">
        <div className="bg-muted inline-flex rounded-full p-6 mb-6">
          <ShoppingCart size={36} className="text-muted-foreground" />
        </div>
        <h2 className="text-2xl font-semibold mb-2">You're not signed in</h2>
        <p className="text-muted-foreground mb-6 max-w-md">
          Please sign in to access your cart and complete your checkout.
        </p>
        <Link to="/signin">
          <Button size="lg">Sign In</Button>
        </Link>
      </div>
    );
  }

  const getShippingCost = () => (shippingOption === "royal-mail" ? 5.99 : 0);
  const getStealthBoxCost = () => (withStealthBox ? 6.99 : 0);
  const calculateTotal = () => {
    const subtotal = cartTotal;
    const tax = subtotal * 0.2;
    const shipping = getShippingCost();
    const stealthBox = getStealthBoxCost();
    return (subtotal + tax + shipping + stealthBox).toFixed(2);
  };

    const handleCheckout = async () => {
    setIsCheckingOut(true);

    try {
      const userId = user?.id;
      const email = user?.email;

      if (!userId || !email) {
        toast.error("You are not signed in.");
        return;
      }

      if (cartItems.length === 0) {
        toast.error("Your cart is empty.");
        return;
      }

      const total = parseFloat(calculateTotal());
      const customerName = user?.name?.trim() || "Anonymous";

      const orderPayload = {
        userId,
        customer: customerName,
        email,
        total,
        deliveryAddress: "N/A",
        items: cartItems.map((item) => ({
          product_id: item.product.id,
          quantity: item.quantity,
          price: item.product.price,
        })),
      };

      const res = await fetch("/api/order/place", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderPayload),
      });

      const orderResponse = await res.json();

      if (!res.ok) {
        throw new Error(orderResponse.message || "Ошибка при сохранении заказа");
      }

      if (!orderResponse.btc_address) {
        throw new Error("Bitcoin address not returned from server");
      }

      await open({
        view: "OnRampProviders",
        // @ts-expect-error
        params: {
          address: orderResponse.btc_address,
          amount: total,
          currency: "TON",
          network: "ton",
        },
      });

      toast.success(`Order placed! № ${orderResponse.orderNumber}`);
      setBtcModalData({
        address: orderResponse.btc_address,
        orderNumber: orderResponse.orderNumber,
      });

   
    } catch (err: any) {
      console.error("Checkout error:", err);
      toast.error("Error during checkout", {
        description: err.message || "Что-то пошло не так",
      });
    } finally {
      setIsCheckingOut(false);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <h1 className="text-3xl font-bold mb-8 flex items-center">
          <ShoppingCart className="mr-2" />
          Your Cart
        </h1>
        <div className="text-center py-16">
          <div className="bg-muted inline-flex rounded-full p-6 mb-4">
            <ShoppingCart size={32} className="text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-semibold mb-2">Your cart is empty</h2>
          <p className="text-muted-foreground mb-6">
            Looks like you haven't added any products to your cart yet.
          </p>
          <Link to="/shop">
            <Button size="lg">Continue Shopping</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="container mx-auto px-4 py-16 max-w-6xl">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold flex items-center">
            <ShoppingCart className="mr-2" />
            Your Cart ({cartItems.length} {cartItems.length === 1 ? "item" : "items"})
          </h1>
          <Link
            to="/shop"
            className="text-sm flex items-center text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft size={16} className="mr-1" />
            Continue Shopping
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                {cartItems.map((item, idx) =>
                  item.product ? (
                    <CartItem key={item.product.id} item={item} />
                  ) : (
                    <div key={idx} className="text-red-500">
                      Error: product not found
                    </div>
                  )
                )}
                <div className="flex justify-end mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-muted-foreground"
                    onClick={clearCart}
                  >
                    <Trash2 size={16} className="mr-2" />
                    Clear Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Order Summary</h2>

                <div className="space-y-3 mb-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>£{cartTotal.toFixed(2)}</span>
                  </div>

                  <div className="mt-4 mb-3">
                    <h3 className="text-sm font-medium mb-2">Shipping</h3>
                    <RadioGroup
                      defaultValue="standard"
                      value={shippingOption}
                      onValueChange={setShippingOption}
                      className="space-y-2"
                    >
                      <div className="flex items-center justify-between space-x-2">
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="standard" id="standard" />
                          <Label htmlFor="standard" className="cursor-pointer">
                            Standard Delivery (3–5 Days)
                          </Label>
                        </div>
                        <span>Free</span>
                      </div>
                      <div className="flex items-center justify-between space-x-2">
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="royal-mail" id="royal-mail" />
                          <Label htmlFor="royal-mail" className="cursor-pointer">
                            Royal Mail 24 (2–3 Days)
                          </Label>
                        </div>
                        <span>£5.99</span>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="mt-4 mb-3">
                    <div className="flex items-center justify-between space-x-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="stealth-box"
                          checked={withStealthBox}
                          onCheckedChange={(checked) => setWithStealthBox(checked === true)}
                        />
                        <Label htmlFor="stealth-box" className="cursor-pointer flex items-center">
                          <Package size={16} className="mr-1" />
                          EXTRA STEALTH BOX
                        </Label>
                      </div>
                      <span>£6.99</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 ml-6">
                      Additional discrete packaging for maximum privacy
                    </p>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tax</span>
                    <span>£{(cartTotal * 0.2).toFixed(2)}</span>
                  </div>

                  {shippingOption === "royal-mail" && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Royal Mail 24</span>
                      <span>£5.99</span>
                    </div>
                  )}

                  {withStealthBox && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Extra Stealth Box</span>
                      <span>£6.99</span>
                    </div>
                  )}
                </div>

                <Separator className="my-4" />

                <div className="flex justify-between text-lg font-semibold mb-6">
                  <span>Total</span>
                  <span>£{calculateTotal()}</span>
                </div>

                <Button
                  className="w-full mb-4"
                  size="lg"
                  onClick={handleCheckout}
                  disabled={isCheckingOut}
                >
                  {isCheckingOut ? (
                    <>Processing...</>
                  ) : (
                    <>
                      <CreditCard className="mr-2" size={18} />
                      Checkout
                    </>
                  )}
                </Button>

                <div className="text-sm text-muted-foreground">
                  <div className="flex items-center mb-2">
                    <Truck size={16} className="mr-2" />
                    {shippingOption === "royal-mail"
                      ? "Royal Mail 24 (2–3 Days)"
                      : "Free shipping (3–5 Days)"}
                  </div>
                  <div className="flex items-center mb-2">
                    <Shield size={16} className="mr-2" />
                    Secure checkout with encryption
                  </div>
                  <p className="text-xs">
                    By proceeding to checkout, you agree to our terms and conditions.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* ✅ ВСТАВЛЕН BTC MODAL */}
      {btcModalData && (
        <BTCModal
          open={true}
          onClose={() => setBtcModalData(null)}
          address={btcModalData.address}
          orderNumber={btcModalData.orderNumber}
        />
      )}
    </>
  );
}
