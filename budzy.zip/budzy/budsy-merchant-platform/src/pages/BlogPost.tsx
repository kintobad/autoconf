import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { samplePosts } from '@/lib/sampleData';
import { Post } from '@/lib/models';
import NotFound from './NotFound';
import ReactMarkdown from 'react-markdown';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CalendarIcon, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const BlogPost = () => {
  const { slug } = useParams();
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real app, this would be an API call
    const fetchPost = () => {
      setLoading(true);
      const foundPost = samplePosts.find(p => p.slug === slug && p.status === 'published');
      setPost(foundPost || null);
      setLoading(false);
    };

    fetchPost();
  }, [slug]);

  if (loading) {
    return (
      <div className="container max-w-4xl mx-auto py-10 px-4">
        <div className="space-y-4">
          <div className="h-12 w-3/4 bg-gray-200 animate-pulse rounded-md"></div>
          <div className="h-6 w-1/2 bg-gray-200 animate-pulse rounded-md"></div>
          <div className="h-96 bg-gray-200 animate-pulse rounded-md"></div>
        </div>
      </div>
    );
  }

  if (!post) {
    return <NotFound />;
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };

  return (
    <div className="container max-w-4xl mx-auto py-10 px-4">
      <div className="mb-6">
        <Button variant="outline" size="sm" asChild>
          <Link to="/blog" className="flex items-center gap-2">
            <span>← Back to Blog</span>
          </Link>
        </Button>
      </div>

      <article className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
          <div className="flex flex-wrap gap-2 items-center text-muted-foreground">
            <div className="flex items-center gap-1">
              <User size={14} />
              <span>{post.author}</span>
            </div>
            <div className="flex items-center gap-1">
              <CalendarIcon size={14} />
              <span>{formatDate(post.createdAt)}</span>
            </div>
          </div>
        </div>

        {post.imageUrl && (
          <div className="w-full h-[400px] rounded-lg overflow-hidden">
            <img
              src={post.imageUrl}
              alt={post.title}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        <Card>
          <CardContent className="pt-6 prose prose-sm md:prose-base lg:prose-lg max-w-none dark:prose-invert">
            <ReactMarkdown>{post.content}</ReactMarkdown>
          </CardContent>
        </Card>

        <div className="flex flex-wrap gap-2 pt-4">
          {post.tags.map(tag => (
            <Badge key={tag} variant="secondary">
              {tag}
            </Badge>
          ))}
        </div>
      </article>
    </div>
  );
};

export default BlogPost;
