import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { fetchProducts } from '@/lib/api';
import ProductCard from '@/components/ProductCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Search, FilterX, ChevronDown, ChevronUp } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { supabase } from '@/lib/supabaseClient';
import { Category } from '@/types';

const Shop = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [allProducts, setAllProducts] = useState<any[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100]);
  const [thcRange, setThcRange] = useState<[number, number]>([0, 100]);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    fetchProducts()
      .then((data) => {
        setAllProducts(data);
        const maxPrice = Math.max(...data.map(p => p.price || 0), 100);
        setPriceRange([0, maxPrice]);
        setFilteredProducts(data);
      })
      .catch((err) => console.error('Ошибка загрузки продуктов:', err));
  }, []);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data, error } = await supabase.from('categories').select('*');
      if (error) {
        console.error('Ошибка загрузки категорий:', error.message);
      } else {
        setCategories(data || []);
      }
    };

    fetchCategories();
  }, []);

  useEffect(() => {
    let filtered = [...allProducts];

    if (searchTerm) {
      filtered = filtered.filter(product =>
        product.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCategory) {
      const categoryObj = categories.find(c => c.name === selectedCategory);
      if (categoryObj) {
        filtered = filtered.filter(product => product.category_id === categoryObj.id);
      }
    }

    filtered = filtered.filter(product => {
      const price = product.price || 0;
      return price >= priceRange[0] && price <= priceRange[1];
    });

    filtered = filtered.filter(product => {
      const thc = product.thc_percentage ?? 0;
      return thc >= thcRange[0] && thc <= thcRange[1];
    });

    setFilteredProducts(filtered);
  }, [allProducts, searchTerm, selectedCategory, priceRange, thcRange, categories]);

  const handleCategoryChange = (category: string | null) => {
    setSelectedCategory(category);
    const params = new URLSearchParams(location.search);
    if (category) {
      params.set('category', category);
    } else {
      params.delete('category');
    }
    navigate({ search: params.toString() });
  };

  const resetFilters = () => {
    setSearchTerm('');
    setSelectedCategory(null);
    const max = Math.max(...allProducts.map(p => p.price || 0), 100);
    setPriceRange([0, max]);
    setThcRange([0, 100]);
    navigate('/shop');
  };

  const maxPrice = Math.max(...allProducts.map(p => p.price || 0), 100);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow pt-24 pb-12">
        <div className="page-container">
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Shop Cannabis Products</h1>
            <p className="text-muted-foreground">Browse our selection of premium cannabis products</p>
          </div>

          <div className="lg:hidden mb-4">
            <Button variant="outline" className="w-full justify-between" onClick={() => setFiltersOpen(!filtersOpen)}>
              <span>Filters</span>
              {filtersOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </Button>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            <aside className={`lg:w-1/4 ${filtersOpen ? 'block' : 'hidden'} lg:block animate-fade-in`}>
              <div className="sticky top-24 space-y-6 bg-card p-6 rounded-xl shadow-sm">
                <div>
                  <h3 className="font-medium mb-3">Search</h3>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search products..."
                      className="pl-9"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-3">Categories</h3>
                  <div className="space-y-1 flex flex-wrap">
                    <Button
                      variant={selectedCategory === null ? "default" : "outline"}
                      size="sm"
                      className="mr-2 mb-2"
                      onClick={() => handleCategoryChange(null)}
                    >
                      All
                    </Button>
                    {categories.map((category) => (
                      <Button
                        key={category.id}
                        variant={selectedCategory === category.name ? "default" : "outline"}
                        size="sm"
                        className="mr-2 mb-2"
                        onClick={() => handleCategoryChange(category.name)}
                      >
                        {category.name.charAt(0).toUpperCase() + category.name.slice(1)}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-3">Price Range</h3>
                  <Slider
                    defaultValue={[0, maxPrice]}
                    max={maxPrice}
                    step={1}
                    value={priceRange}
                    onValueChange={(value) => setPriceRange(value as [number, number])}
                    className="my-6"
                  />
                  <div className="flex justify-between text-sm">
                    <span>${priceRange[0].toFixed(2)}</span>
                    <span>${priceRange[1].toFixed(2)}</span>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-3">THC Percentage</h3>
                  <Slider
                    defaultValue={[0, 100]}
                    max={100}
                    step={1}
                    value={thcRange}
                    onValueChange={(value) => setThcRange(value as [number, number])}
                    className="my-6"
                  />
                  <div className="flex justify-between text-sm">
                    <span>{thcRange[0]}%</span>
                    <span>{thcRange[1]}%</span>
                  </div>
                </div>

                <Button variant="outline" className="w-full" onClick={resetFilters}>
                  <FilterX size={16} className="mr-2" />
                  Reset Filters
                </Button>
              </div>
            </aside>

            <div className="lg:w-3/4">
              {filteredProducts.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-xl font-medium mb-4">No products found</p>
                  <p className="text-muted-foreground mb-6">Try adjusting your search or filter criteria</p>
                  <Button onClick={resetFilters}>
                    <FilterX size={16} className="mr-2" />
                    Reset Filters
                  </Button>
                </div>
              ) : (
                <>
                  <p className="text-muted-foreground mb-6">
                    Showing {filteredProducts.length} {filteredProducts.length === 1 ? 'product' : 'products'}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                    {filteredProducts.map((product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Shop;
