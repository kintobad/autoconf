
import { Helmet } from "react-helmet";
import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import UserSidebar from "@/components/UserSidebar";
import UserProfile from "@/components/user/UserProfile";
import UserOrders from "@/components/user/UserOrders";
import UserAddresses from "@/components/user/UserAddresses";
import UserSettings from "@/components/user/UserSettings";
import UserTickets from "@/components/user/UserTickets";

const UserCabinet = () => {
  const [activeTab, setActiveTab] = useState("profile");

  const tabComponents = {
    profile: <UserProfile />,
    orders: <UserOrders />,
    addresses: <UserAddresses />,
    tickets: <UserTickets />,
    settings: <UserSettings />
  };

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Helmet>
        <title>My Account | Budsy</title>
        <meta name="description" content="Manage your Budsy account, orders, and preferences" />
      </Helmet>
      
      <Navbar />
      
      <main className="flex-grow container py-8 px-4 max-w-7xl mx-auto lg:py-12 mt-20">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Account</h1>
          <p className="text-muted-foreground">Manage your profile, orders, and preferences</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-3">
            <div className="lg:sticky lg:top-24">
              <UserSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
            </div>
          </div>
          
          {/* Main Content */}
          <div className="lg:col-span-9">
            <div className="bg-background rounded-lg border shadow-sm animate-in fade-in-50 duration-300">
              {tabComponents[activeTab as keyof typeof tabComponents]}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default UserCabinet;
