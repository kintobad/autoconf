import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabaseClient';
import type { Product } from '@/types';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import {
  ShoppingCart,
  Heart,
  Share2,
  ChevronRight,
  Minus,
  Plus,
  Star,
  Truck,
  ShieldCheck,
  BarChart,
} from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';

const Product = () => {
  const { id } = useParams();
  const { addToCart } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;

      setLoading(true);
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          categories(name)
        `)
        .eq('id', id)
        .single();

      if (error) {
        toast({ title: 'Ошибка загрузки', description: error.message, variant: 'destructive' });
        setProduct(null);
      } else {
        setProduct({
          ...data,
          category: data.categories?.name ?? '',
        });
        fetchRelated(data.category_id, data.id);
      }

      setLoading(false);
    };

    const fetchRelated = async (category_id: number, currentId: string) => {
      const { data } = await supabase
        .from('products')
        .select('*')
        .eq('category_id', category_id)
        .neq('id', currentId)
        .limit(3);

      if (data) setRelatedProducts(data);
    };

    fetchProduct();
  }, [id]);

  const handleAddToCart = () => {
    if (product) addToCart(product, quantity);
  };

  const incrementQuantity = () => {
    if (product && quantity < product.stock) {
      setQuantity(quantity + 1);
    } else {
      toast({
        title: 'Максимум',
        description: `Только ${product?.stock} в наличии`,
        variant: 'destructive',
      });
    }
  };

  const decrementQuantity = () => {
    if (quantity > 1) setQuantity(quantity - 1);
  };

  const productImages = product?.image_urls?.length
    ? product.image_urls
    : product?.imageUrl
    ? [product.imageUrl]
    : [];

  const ProgressBar = ({ percentage, label }: { percentage?: number; label: string }) =>
    percentage !== undefined ? (
      <div className="mb-3">
        <div className="flex justify-between items-center mb-1">
          <span className="text-sm font-medium">{label}</span>
          <span className="text-sm font-medium">{percentage}%</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div className="bg-primary rounded-full h-2" style={{ width: `${percentage}%` }}></div>
        </div>
      </div>
    ) : null;

  if (loading) return <div className="text-center mt-20 text-muted">Загрузка...</div>;
  if (!product) return <div className="text-center mt-20 text-destructive">Товар не найден</div>;

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow pt-24 pb-12">
        <div className="page-container">
          {/* Хлебные крошки */}
          <div className="flex items-center text-sm text-muted-foreground mb-6 gap-2 flex-wrap">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <ChevronRight size={14} />
            <Link to="/shop" className="hover:text-foreground transition-colors">Shop</Link>
            <ChevronRight size={14} />

            <Select
              value={String(product.category_id)}
              onValueChange={() => {
                if (product?.category) {
                  navigate(`/shop?category=${product.category}`);
                }
              }}
            >
              <SelectTrigger className="w-[180px] h-8 text-xs sm:text-sm">
                <SelectValue placeholder={product.category || 'Категория'} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={String(product.category_id)}>
                  {product.category || '—'}
                </SelectItem>
              </SelectContent>
            </Select>

            <ChevronRight size={14} />
            <span className="text-foreground">{product.title}</span>
          </div>

          {/* Детали */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div>
              <div className="mb-4 aspect-square rounded-xl overflow-hidden bg-muted">
                {!imageLoaded && (
                  <div className="absolute inset-0 flex items-center justify-center bg-muted animate-pulse">
                    <span className="sr-only">Loading...</span>
                  </div>
                )}
                <img
                  src={productImages[selectedImage]}
                  alt={product.title}
                  className={`w-full h-full object-cover transition-opacity duration-300 ${
                    imageLoaded ? 'opacity-100' : 'opacity-0'
                  }`}
                  onLoad={() => setImageLoaded(true)}
                />
              </div>
              <div className="flex space-x-2">
                {productImages.map((img, index) => (
                  <button
                    key={index}
                    className={`w-20 h-20 rounded-md overflow-hidden ${
                      selectedImage === index ? 'ring-2 ring-primary' : 'opacity-70'
                    } transition-all`}
                    onClick={() => setSelectedImage(index)}
                  >
                    <img src={img} alt={`${product.title} ${index + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="mb-2">
                <span className="px-3 py-1 bg-muted text-xs font-medium rounded-full">
                  {product.category || '—'}
                  {product.subcategory ? ` - ${product.subcategory}` : ''}
                </span>
              </div>

              <h1 className="text-3xl md:text-4xl font-bold mb-2">{product.title}</h1>

              <div className="flex items-center mb-4">
                <div className="flex text-amber-500">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} size={16} fill="currentColor" />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground ml-2">4.9 (124 reviews)</span>
              </div>

              <div className="mb-4">
                <span className="text-2xl font-bold">£{product.price.toFixed(2)}</span>
                {product.weight && (
                  <span className="text-sm text-muted-foreground ml-2">{product.weight}g</span>
                )}
              </div>

              <p className="text-muted-foreground mb-6">{product.description}</p>

              {product.effects?.length > 0 && (
                <div className="mb-6">
                  <h3 className="font-medium mb-2">Effects:</h3>
                  <div className="flex flex-wrap gap-2">
                    {product.effects.map((e, i) => (
                      <span key={i} className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">
                        {e}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {product.flavors?.length > 0 && (
                <div className="mb-6">
                  <h3 className="font-medium mb-2">Flavors:</h3>
                  <div className="flex flex-wrap gap-2">
                    {product.flavors.map((f, i) => (
                      <span key={i} className="px-3 py-1 bg-muted text-sm rounded-full">
                        {f}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {(product.thcPercentage ||
                product.cbdPercentage ||
                product.indicaPercentage ||
                product.sativaPercentage) && (
                <div className="mb-6">
                  <h3 className="font-medium mb-3">Cannabinoid Profile:</h3>
                  <div className="space-y-2">
                    <ProgressBar percentage={product.thcPercentage} label="THC" />
                    <ProgressBar percentage={product.cbdPercentage} label="CBD" />
                    <ProgressBar percentage={product.indicaPercentage} label="Indica" />
                    <ProgressBar percentage={product.sativaPercentage} label="Sativa" />
                  </div>
                </div>
              )}

              <div className="flex items-center mb-6">
                <span className="mr-4 font-medium">Quantity:</span>
                <div className="flex items-center border border-input rounded-md">
                  <Button variant="ghost" size="icon" onClick={decrementQuantity} className="h-10 w-10 rounded-none">
                    <Minus size={16} />
                  </Button>
                  <span className="w-12 text-center">{quantity}</span>
                  <Button variant="ghost" size="icon" onClick={incrementQuantity} className="h-10 w-10 rounded-none">
                    <Plus size={16} />
                  </Button>
                </div>
                <span className="ml-4 text-sm text-muted-foreground">{product.stock} available</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <Button size="lg" className="flex-1 btn-hover" onClick={handleAddToCart}>
                  <ShoppingCart size={18} className="mr-2" />
                  Add to Cart
                </Button>
                <Button variant="outline" size="icon" className="btn-hover">
                  <Heart size={18} />
                </Button>
                <Button variant="outline" size="icon" className="btn-hover">
                  <Share2 size={18} />
                </Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="flex items-center p-3 bg-muted rounded-lg">
                  <ShieldCheck size={18} className="text-primary mr-2" />
                  <span className="text-sm">Quality Guaranteed</span>
                </div>
                <div className="flex items-center p-3 bg-muted rounded-lg">
                  <Truck size={18} className="text-primary mr-2" />
                  <span className="text-sm">Fast Delivery</span>
                </div>
                <div className="flex items-center p-3 bg-muted rounded-lg">
                  <BarChart size={18} className="text-primary mr-2" />
                  <span className="text-sm">Lab Tested</span>
                </div>
              </div>
            </div>
          </div>

          {relatedProducts.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Related Products</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {relatedProducts.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Product;
