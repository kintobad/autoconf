
import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useCart } from '@/context/CartContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { 
  ShoppingCart, 
  Minus, 
  Plus, 
  ArrowLeft, 
  Star, 
  Package, 
  Leaf, 
  Tag 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState<any>(null);
  const [relatedProducts, setRelatedProducts] = useState<any[]>([]);
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const [activeTab, setActiveTab] = useState('description');

useEffect(() => {
  const fetchProduct = async () => {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      console.error('Ошибка получения продукта:', error.message);
    } else {
      setProduct({
        ...data,
        imageUrl: data.image_urls?.[0] || null,
        thcPercentage: data.thc_percentage,
        cbdPercentage: data.cbd_percentage,
        indicaPercentage: data.indica_percentage,
        sativaPercentage: data.sativa_percentage,
        shortDescription: data.short_description,
      });
    }

    window.scrollTo(0, 0);
  };

  if (id) fetchProduct();
}, [id]);

  const handleQuantityChange = (value: number) => {
    if (value < 1) value = 1;
    if (product && value > product.stock) {
      toast.error(`Only ${product.stock} items available`);
      value = product.stock;
    }
    setQuantity(value);
  };

  const handleAddToCart = () => {
    if (product) {
      addToCart(product, quantity);
      toast.success(`${quantity} × ${product.title} added to cart`);
    }
  };

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <p className="mb-6">Sorry, the product you're looking for doesn't exist.</p>
        <Link to="/shop">
          <Button>Return to Shop</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <div className="mb-6">
        <Link to="/shop" className="flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft size={16} className="mr-1" />
          Back to Shop
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Product Image */}
        <div className="bg-muted rounded-xl overflow-hidden">
          <img 
            src={product.imageUrl || '/placeholder.svg'} 
            alt={product.title} 
            className="w-full h-full object-cover aspect-square" 
          />
        </div>

        {/* Product Details */}
        <div className="flex flex-col">
          <div className="flex justify-between items-start gap-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">
                {product.category} {product.subcategory && `• ${product.subcategory}`}
              </p>
              <h1 className="text-3xl font-bold">{product.title}</h1>
            </div>
            <div className="text-2xl font-bold text-primary">
              £{product.price.toFixed(2)}
            </div>
          </div>

          {/* Rating Placeholder */}
          <div className="flex items-center mt-2 mb-4">
            <div className="flex text-yellow-500">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={16} fill={i < 4 ? "currentColor" : "none"} />
              ))}
            </div>
            <span className="text-sm text-muted-foreground ml-2">
              4.0 (24 reviews)
            </span>
          </div>

          {/* Short Description */}
          <p className="text-muted-foreground my-4">
            {product.shortDescription}
          </p>

          {/* Product Attributes */}
          <div className="grid grid-cols-2 gap-4 my-6">
            {product.thcPercentage !== undefined && (
              <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                <Badge variant="outline" className="h-8 w-8 rounded-full flex items-center justify-center p-0">
                  <span className="text-xs font-bold">THC</span>
                </Badge>
                <div>
                  <p className="text-sm font-medium">{product.thcPercentage}%</p>
                  <p className="text-xs text-muted-foreground">THC Content</p>
                </div>
              </div>
            )}
            
            {product.cbdPercentage !== undefined && (
              <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                <Badge variant="outline" className="h-8 w-8 rounded-full flex items-center justify-center p-0">
                  <span className="text-xs font-bold">CBD</span>
                </Badge>
                <div>
                  <p className="text-sm font-medium">{product.cbdPercentage}%</p>
                  <p className="text-xs text-muted-foreground">CBD Content</p>
                </div>
              </div>
            )}
            
            {product.weight !== undefined && (
              <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                <Badge variant="outline" className="h-8 w-8 rounded-full flex items-center justify-center p-0">
                  <Package size={14} />
                </Badge>
                <div>
                  <p className="text-sm font-medium">{product.weight}g</p>
                  <p className="text-xs text-muted-foreground">Weight</p>
                </div>
              </div>
            )}
            
            {product.effects && product.effects.length > 0 && (
              <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                <Badge variant="outline" className="h-8 w-8 rounded-full flex items-center justify-center p-0">
                  <Leaf size={14} />
                </Badge>
                <div>
                  <p className="text-sm font-medium">{product.effects[0]}</p>
                  <p className="text-xs text-muted-foreground">Primary Effect</p>
                </div>
              </div>
            )}
          </div>

          {/* Strain Type Indicators (for cannabis) */}
          {(product.indicaPercentage !== undefined || product.sativaPercentage !== undefined) && (
            <div className="my-6">
              <p className="text-sm font-medium mb-2">Strain Profile</p>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                {product.indicaPercentage && product.sativaPercentage && (
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-600 to-purple-600" 
                    style={{ width: `${product.sativaPercentage}%` }}
                  ></div>
                )}
              </div>
              <div className="flex justify-between text-xs mt-1">
                <span>Indica {product.indicaPercentage}%</span>
                <span>Sativa {product.sativaPercentage}%</span>
              </div>
            </div>
          )}

          {/* Stock Status */}
          <div className="mt-2 mb-6">
            <p className="text-sm">
              Status: 
              <span className={`ml-2 font-medium ${product.stock > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {product.stock > 0 ? 'In Stock' : 'Out of Stock'}
              </span>
              {product.stock > 0 && (
                <span className="text-muted-foreground ml-1">
                  ({product.stock} available)
                </span>
              )}
            </p>
          </div>

          <Separator className="my-6" />

          {/* Quantity Selector */}
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:gap-8">
            <div className="flex items-center">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => handleQuantityChange(quantity - 1)}
                disabled={quantity <= 1}
              >
                <Minus size={16} />
              </Button>
              <span className="w-14 text-center">{quantity}</span>
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => handleQuantityChange(quantity + 1)}
                disabled={product.stock <= quantity}
              >
                <Plus size={16} />
              </Button>
            </div>
            
            {/* Add to Cart Button */}
            <Button 
              className="flex-1" 
              size="lg"
              onClick={handleAddToCart}
              disabled={product.stock <= 0}
            >
              <ShoppingCart size={18} className="mr-2" />
              Add to Cart
            </Button>
          </div>
          
          {/* Product tags */}
          {product.flavors && product.flavors.length > 0 && (
            <div className="mt-8">
              <div className="flex items-center gap-2 mb-2">
                <Tag size={16} />
                <span className="text-sm font-medium">Flavors:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.flavors.map((flavor, idx) => (
                  <Badge key={idx} variant="secondary">{flavor}</Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Product Tabs */}
      <div className="mt-16">
        <div className="flex border-b">
          <button
            className={`px-4 py-2 font-medium text-sm ${activeTab === 'description' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}
            onClick={() => setActiveTab('description')}
          >
            Description
          </button>
          {product.effects && (
            <button
              className={`px-4 py-2 font-medium text-sm ${activeTab === 'effects' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}
              onClick={() => setActiveTab('effects')}
            >
              Effects & Flavors
            </button>
          )}
          <button
            className={`px-4 py-2 font-medium text-sm ${activeTab === 'reviews' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}
            onClick={() => setActiveTab('reviews')}
          >
            Reviews
          </button>
        </div>
        
        <div className="py-6">
          {activeTab === 'description' && (
            <div>
              <p className="leading-relaxed">
                {product.description}
              </p>
            </div>
          )}
          
          {activeTab === 'effects' && (
            <div>
              {product.effects && (
                <>
                  <h3 className="font-semibold text-lg mb-2">Effects</h3>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {product.effects.map((effect, idx) => (
                      <Badge key={idx} variant="outline" className="px-3 py-1">
                        {effect}
                      </Badge>
                    ))}
                  </div>
                </>
              )}
              
              {product.flavors && (
                <>
                  <h3 className="font-semibold text-lg mb-2">Flavors</h3>
                  <div className="flex flex-wrap gap-2">
                    {product.flavors.map((flavor, idx) => (
                      <Badge key={idx} variant="outline" className="px-3 py-1">
                        {flavor}
                      </Badge>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
          
          {activeTab === 'reviews' && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                No reviews yet. Be the first to review this product.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Related Products (placeholder) */}
      {/* Related Products */}
<div className="mt-16">
  <h2 className="text-2xl font-bold mb-8">You might also like</h2>
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    {relatedProducts.map(relatedProduct => (
      <div key={relatedProduct.id} className="bg-card rounded-lg overflow-hidden shadow-sm">
        <Link to={`/product/${relatedProduct.id}`}>
          <img 
            src={relatedProduct.imageUrl || '/placeholder.svg'} 
            alt={relatedProduct.title} 
            className="w-full h-40 object-cover"
          />
          <div className="p-4">
            <h3 className="font-medium">{relatedProduct.title}</h3>
            <p className="text-primary font-bold mt-1">
              £{relatedProduct.price?.toFixed(2)}
            </p>
          </div>
        </Link>
      </div>
    ))}
  </div>
</div>

    </div>
  );
}
