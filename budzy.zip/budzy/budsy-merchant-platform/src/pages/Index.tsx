
import { CartProvider } from '@/context/CartContext';
import AdminLink from '@/components/AdminLink';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Cannabis, Coffee, Beaker, Pill, Package, ChevronRight } from 'lucide-react';
import FeaturedProducts from '@/components/FeaturedProducts';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function Index() {
  return (
    <CartProvider>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 pt-24">
          {/* Hero section */}
          <section className="bg-gradient-to-b from-background to-muted py-16">
            <div className="container mx-auto px-4">
              <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">
                Welcome to Budsy Cannabis E-Shop
              </h1>
              <p className="text-lg text-center max-w-2xl mx-auto mb-8">
                Your premium destination for high-quality cannabis products, with detailed information,
                secure shopping, and reliable delivery.
              </p>
              <div className="flex justify-center gap-4">
                <Link to="/shop">
                  <Button size="lg" className="gap-2">
                    Shop Now
                    <ChevronRight size={16} />
                  </Button>
                </Link>
                <Link to="/about">
                  <Button variant="outline" size="lg">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
          </section>

          {/* Categories section */}
          <section className="py-16 bg-background">
            <div className="container mx-auto px-4">
              <h2 className="text-3xl font-bold mb-8 text-center">Shop by Category</h2>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <CategoryCard 
                  icon={<Cannabis size={24} />} 
                  title="Flowers" 
                  description="Indica, Sativa & Hybrid"
                  href="/shop/flowers"
                />
                <CategoryCard 
                  icon={<Beaker size={24} />} 
                  title="Extracts" 
                  description="Oils, Wax & Concentrates"
                  href="/shop/extracts"
                />
                <CategoryCard 
                  icon={<Coffee size={24} />} 
                  title="Edibles" 
                  description="Gummies, Chocolates & More"
                  href="/shop/edibles"
                />
                <CategoryCard 
                  icon={<Pill size={24} />} 
                  title="Medical" 
                  description="CBD Oils & Topicals"
                  href="/shop/medical"
                />
                <CategoryCard 
                  icon={<Package size={24} />} 
                  title="Accessories" 
                  description="Vaporizers, Bongs & Papers"
                  href="/shop/accessories"
                />
              </div>
            </div>
          </section>

          {/* Featured Products section */}
          <section className="py-16 bg-muted/50">
            <div className="container mx-auto px-4">
              <h2 className="text-3xl font-bold mb-8 text-center">Featured Products</h2>
              <FeaturedProducts />
            </div>
          </section>

          {/* Benefits section */}
          <section className="py-16 bg-background">
            <div className="container mx-auto px-4">
              <h2 className="text-3xl font-bold mb-12 text-center">Why Choose Budsy</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="bg-card p-6 rounded-lg shadow-sm">
                  <h3 className="text-xl font-semibold mb-3">Premium Quality</h3>
                  <p className="text-muted-foreground">All our products are lab-tested and certified to ensure premium quality and safety.</p>
                </div>
                <div className="bg-card p-6 rounded-lg shadow-sm">
                  <h3 className="text-xl font-semibold mb-3">Secure Shopping</h3>
                  <p className="text-muted-foreground">Modern encryption protocols and secure payment systems protect your privacy.</p>
                </div>
                <div className="bg-card p-6 rounded-lg shadow-sm">
                  <h3 className="text-xl font-semibold mb-3">Reliable Delivery</h3>
                  <p className="text-muted-foreground">Fast and discreet delivery to your doorstep with real-time tracking.</p>
                </div>
              </div>
            </div>
          </section>
        </main>
        <Footer />
        <AdminLink />
      </div>
    </CartProvider>
  );
}

// Category card component
function CategoryCard({ icon, title, description, href }: { 
  icon: React.ReactNode, 
  title: string, 
  description: string,
  href: string 
}) {
  return (
    <Link to={href} className="group">
      <div className="bg-card hover:bg-accent transition-colors duration-300 p-6 rounded-lg text-center h-full flex flex-col items-center">
        <div className="mb-3 text-primary">{icon}</div>
        <h3 className="font-semibold mb-1">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </Link>
  );
}
