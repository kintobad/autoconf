import { createContext, useContext } from "react";
import type { AppKit } from "@reown/appkit";

export const AppKitContext = createContext<AppKit | null>(null);

export const useAppKitSafe = (): AppKit => {
  const ctx = useContext(AppKitContext);
  if (!ctx) throw new Error("AppKit not initialized");
  return ctx;
};
