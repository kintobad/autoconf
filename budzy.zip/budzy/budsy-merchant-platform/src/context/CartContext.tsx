import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from 'react';
import { Product } from '@/types';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';
import { CartService } from '@/lib/CartService';

type CartItem = {
  product: Product;
  quantity: number;
};

type CartContextType = {
  cartItems: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartTotal, setCartTotal] = useState(0);
  const [cartCount, setCartCount] = useState(0);
  const { user } = useAuth();

  useEffect(() => {
    if (!user) {
      setCartItems([]);
      return;
    }

    const loadCart = async () => {
      try {
        const serverCart = await CartService.getCart(user.id);
        const mapped = serverCart
          .filter((item) => item.product)
          .map((item) => ({
            product: item.product,
            quantity: item.quantity,
          }));
        setCartItems(mapped);
      } catch (error) {
        console.error('Failed to load cart:', error);
        toast.error('Failed to load cart');
      }
    };

    loadCart();
  }, [user]);

  useEffect(() => {
    const total = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const count = cartItems.reduce((sum, item) => sum + item.quantity, 0);
    setCartTotal(total);
    setCartCount(count);
  }, [cartItems]);

  const addToCart = async (product: Product, quantity = 1) => {
    if (!user) {
      toast.error('Please log in to add items to your cart');
      return;
    }

    try {
      const existing = cartItems.find((item) => item.product.id === product.id);
      const newQuantity = existing ? existing.quantity + quantity : quantity;

      await CartService.addItem(user.id, product.id, newQuantity);

      const updated = existing
        ? cartItems.map((item) =>
            item.product.id === product.id ? { ...item, quantity: newQuantity } : item
          )
        : [...cartItems, { product, quantity }];

      setCartItems(updated);
      toast.success(existing ? 'Cart updated' : 'Added to cart');
    } catch (error) {
      console.error('Failed to add to cart:', error);
      toast.error('Failed to add item to cart');
    }
  };

  const updateQuantity = async (productId: string, quantity: number) => {
    if (!user) return;

    const product = cartItems.find((item) => item.product.id === productId)?.product;
    if (!product) return;

    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }

    try {
      await CartService.addItem(user.id, productId, quantity);
      setCartItems((prev) =>
        prev.map((item) =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      );
      toast.success('Quantity updated');
    } catch (error) {
      console.error('Failed to update quantity:', error);
      toast.error('Could not update quantity');
    }
  };

  const removeFromCart = async (productId: string) => {
    if (!user) return;

    try {
      await CartService.removeItem(user.id, productId);
      setCartItems((prev) =>
        prev.filter((item) => item.product.id !== productId)
      );
      toast.info('Item removed from cart');
    } catch (error) {
      console.error('Failed to remove item:', error);
      toast.error('Could not remove item');
    }
  };

  const clearCart = async () => {
    if (!user) {
      setCartItems([]);
      return;
    }

    try {
      await CartService.clearCart(user.id);
      setCartItems([]);
      toast.info('Cart cleared');
    } catch (error) {
      console.error('Failed to clear cart:', error);
      toast.error('Could not clear cart');
    }
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartTotal,
        cartCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
};
