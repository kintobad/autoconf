import { User as SupabaseUser } from "@supabase/supabase-js";

export interface ExtendedUser extends SupabaseUser {
  wallet_address?: string;
  name?: string;
  avatar?: string;
  role?: string;
}

export interface Category {
  id: number;
  name: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  shortDescription?: string;
  price: number;
  stock: number;
  categoryName?: string;
  category_id: number;
  category?: string;
  subcategory?: string;
  imageUrl: string;
  image_urls?: string[];
  thcPercentage?: number;
  cbdPercentage?: number;
  indicaPercentage?: number;
  sativaPercentage?: number;
  weight?: number;
  effects?: string[];
  flavors?: string[];
}




export type UserRole = 'admin' | 'customer' | 'manager';


export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: UserRole;
  orderCount: number;
  totalSpent: number;
  joinDate: string;
  lastActive: string;
  status: 'active' | 'inactive' | 'suspended';
}

export type OrderStatus = 'processing' | 'completed' | 'cancelled' | 'pending';


export interface Order {
  id: string;
  date: string;
  customer: string;
  status: OrderStatus;
  total: number;
  items: {
    productId: string;
    quantity: number;
    price: number;
  }[];
}

export interface OrderItemWithProduct {
  productId: string;
  quantity: number;
  price: number;
  product: {
    id: string;
    title: string;
    imageUrl: string;
    category: string;
    price: number;
  };
}


export const sampleOrders: Order[] = [
  {
    id: 'ORD-1001',
    date: '2023-05-15',
    customer: 'Jane Smith',
    status: 'completed',
    total: 89.97,
    items: [
      {
        productId: '1',
        quantity: 2,
        price: 25.99,
      },
      {
        productId: '4',
        quantity: 1,
        price: 37.99,
      },
    ],
  },

];



export const sampleUsers: User[] = [
  {
    id: "U001",
    name: "Jane Smith",
    email: "jane.smith@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jane",
    role: "admin",
    orderCount: 0,
    totalSpent: 0,
    joinDate: "2023-02-15",
    lastActive: "2023-09-28",
    status: "active"
  },

];
