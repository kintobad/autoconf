// src/hooks/useLinkReownWallet.ts
import { useState } from 'react';
import axios from 'axios';

interface LinkWalletResult {
  success: boolean;
  error: string | null;
  data?: any;
}

export function useLinkReownWallet() {
  const [loading, setLoading] = useState(false);

  const linkWallet = async (
    email: string,
    walletAddress: string,
    name?: string
  ): Promise<LinkWalletResult> => {
    setLoading(true);
    try {
      const response = await axios.post('/api/user/link-wallet', {
        email,
        walletAddress,
        name,
      });

      return { success: true, error: null, data: response.data };
    } catch (err: any) {
      console.error('❌ linkWallet error:', err);
      return {
        success: false,
        error: err.response?.data?.message || 'Unknown error',
      };
    } finally {
      setLoading(false);
    }
  };

  return { linkWallet, loading };
}
