import { useEffect, useState } from "react";
import { HDKey } from "@scure/bip32";
import { ethers } from "ethers";
import * as secp from "@noble/secp256k1";

const MERCHANT_XPUB =
  "xpub6DWsSX2MgeLtnrhtJTf84tLrvuy5vVsx4VbhPdCudB5akYvU9agHELwxBk7qYFSFjaiMYDWUnCUCAqxnPhuLnGFg5b54PeWR2hwCL4XcUHq";

export const useMerchantAddress = (index: number = 0): string | null => {
  const [address, setAddress] = useState<string | null>(null);

  useEffect(() => {
    try {
      const root = HDKey.fromExtendedKey(MERCHANT_XPUB);

      // ❗ путь должен начинаться с "m"
      const child = root.derive(`m/0/${index}`);

      // ⚠️ Используем только publicKey, но ethers требует НЕ compressed формат
      const compressedPubkey = child.publicKey;

      // ❗ secp256k1 не позволяет "распаковать" compressed без приватного ключа,
      // поэтому мы просто НЕ используем compressed-ключ напрямую

      // ✅ ВРЕМЕННО используем address напрямую из pubkey
      // ethers автоматически поддерживает compressed pubkey (начиная с v5.7)
      const evmAddress = ethers.utils.computeAddress(compressedPubkey);

      setAddress(evmAddress);
    } catch (error) {
      console.error("❌ Ошибка генерации адреса продавца:", error);
      setAddress(null);
    }
  }, [index]);

  return address;
};
