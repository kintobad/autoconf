import { useEffect, useRef } from "react";
import { useAppKitAccount } from "@reown/appkit/react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export function useAutoLinkProfile() {
  const { address, isConnected } = useAppKitAccount();
  const email = localStorage.getItem("user_email");
  const hasLinked = useRef(false);
  const navigate = useNavigate();

  useEffect(() => {
    const linkWallet = async () => {
      if (hasLinked.current || !isConnected || !address || !email) return;

      try {
        const apiUrl = `${import.meta.env.VITE_API_URL}/api/user/link-wallet`;
        await axios.post(apiUrl, {
          email,
          walletAddress: address,
        });

        hasLinked.current = true;
        localStorage.removeItem("user_email");

        console.log("✅ Wallet linked:", email, address);
        navigate("/account");
      } catch (err) {
        console.error("❌ Failed to link wallet:", err);
      }
    };

    linkWallet();
  }, [email, address, isConnected, navigate]);
}
