import { HDNode } from 'ethers/lib/utils';

const xpub = process.env.XPUB_KEY!;

export function generateWalletAddress(index: number): string {
  const node = HDNode.fromExtendedKey(xpub);
  const child = node.derivePath(`m/0/${index}`);
  return child.address;
}
