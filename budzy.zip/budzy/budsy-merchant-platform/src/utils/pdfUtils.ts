import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Order } from '@/lib/data';

interface OrderItem {
  productId: string;
  quantity: number;
  price: number;
  product: {
    id: string;
    title: string;
    imageUrl: string;
    category: string;
    price: number;
  };
} 

export const generatePackingSlip = async (order: Order, orderItems: OrderItem[]) => {
  // Create a new PDF document
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Add header
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('PACKING SLIP', pageWidth / 2, 20, { align: 'center' });
  
  // Add order information
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`Order #: ${order.id}`, 14, 40);
  doc.text(`Date: ${order.date}`, 14, 50);
  doc.text(`Status: ${order.status.toUpperCase()}`, 14, 60);
  
  // Add customer information
  doc.setFont('helvetica', 'bold');
  doc.text('Customer Details:', 14, 80);
  doc.setFont('helvetica', 'normal');
  doc.text(`Name: ${order.customer}`, 14, 90);
  doc.text(`Email: ${order.customer.toLowerCase().replace(/\s/g, '')}@example.com`, 14, 100);
  doc.text(`Address: 123 High Street, London, UK`, 14, 110);
  
  // Add items table
  const tableColumn = ["Item", "SKU", "Quantity", "Price", "Total"];
  const tableRows = orderItems.map(item => [
    item.product.title,
    item.product.id,
    item.quantity.toString(),
    `£${item.price.toFixed(2)}`,
    `£${(item.price * item.quantity).toFixed(2)}`
  ]);
  
  autoTable(doc, {
    head: [tableColumn],
    body: tableRows,
    startY: 130,
    theme: 'striped',
    headStyles: { fillColor: [51, 51, 51] },
  });
  
  // Add totals
  const finalY = (doc as any).lastAutoTable.finalY + 10;
  doc.text(`Subtotal: £${order.total.toFixed(2)}`, pageWidth - 70, finalY);
  doc.text(`Shipping: Free`, pageWidth - 70, finalY + 10);
  doc.text(`Tax (20%): £${(order.total * 0.2).toFixed(2)}`, pageWidth - 70, finalY + 20);
  doc.setFont('helvetica', 'bold');
  doc.text(`Total: £${(order.total * 1.2).toFixed(2)}`, pageWidth - 70, finalY + 30);
  
  // Add footer
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(10);
  doc.text('Thank you for your order!', pageWidth / 2, finalY + 50, { align: 'center' });
  
  // Save the PDF
  doc.save(`packing-slip-order-${order.id}.pdf`);
};
