
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Link } from "react-router-dom";
import { Minus, Plus, Trash2 } from "lucide-react";

type CartItemProps = {
  item: {
    product: {
      id: string;
      title: string;
      price: number;
      imageUrl?: string; 
      category?: string;
      subcategory?: string;
      stock: number;
    };
    quantity: number;
  };
};


const CartItem = ({ item }: CartItemProps) => {
  const { updateQuantity, removeFromCart } = useCart();
  const { product, quantity } = item;
  
  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity < 1) {
      removeFromCart(product.id);
      return;
    }
    if (newQuantity > product.stock) {
      return;
    }
    updateQuantity(product.id, newQuantity);
  };

  const itemTotal = product.price * quantity;

  return (
    <div className="flex flex-col sm:flex-row gap-4 py-4">
      <div className="flex-shrink-0">
        <Link to={`/product/${product.id}`}>
          <img 
            src={product.imageUrl} 
            alt={product.title}
            className="w-20 h-20 object-cover rounded-md"
          />
        </Link>
      </div>
      
      <div className="flex-grow">
        <div className="flex flex-col sm:flex-row sm:justify-between gap-2">
          <div>
            <Link to={`/product/${product.id}`}>
              <h3 className="font-medium hover:text-primary transition-colors">
                {product.title}
              </h3>
            </Link>
            <p className="text-sm text-muted-foreground">
              {product.category} {product.subcategory && `• ${product.subcategory}`}
            </p>
            <p className="text-sm font-medium mt-1">
              £{product.price.toFixed(2)}
            </p>
          </div>
          
          <div className="flex items-center space-x-2 sm:mt-0 mt-2">
            <div className="flex items-center border rounded-md">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-none"
                onClick={() => handleQuantityChange(quantity - 1)}
                disabled={quantity <= 1}
              >
                <Minus size={14} />
              </Button>
              <span className="w-8 text-center text-sm">{quantity}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-none"
                onClick={() => handleQuantityChange(quantity + 1)}
                disabled={quantity >= product.stock}
              >
                <Plus size={14} />
              </Button>
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-destructive"
              onClick={() => removeFromCart(product.id)}
            >
              <Trash2 size={16} />
            </Button>
          </div>
        </div>
        
        <div className="flex justify-between items-center mt-2">
          <span className="text-sm text-muted-foreground">
            {quantity} × £{product.price.toFixed(2)}
          </span>
          <span className="font-medium">
            £{itemTotal.toFixed(2)}
          </span>
        </div>
      </div>
      <Separator className="my-4" />
    </div>
  );
};

export default CartItem;
