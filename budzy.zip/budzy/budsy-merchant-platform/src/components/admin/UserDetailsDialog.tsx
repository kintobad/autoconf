
import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Loader2, Mail, User as UserIcon, CalendarDays, Clock, ShoppingCart, CreditCard } from 'lucide-react';
import { User, UserRole } from '@/types';

interface UserDetailsDialogProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
}

const UserDetailsDialog = ({ user, isOpen, onClose }: UserDetailsDialogProps) => {
  const [role, setRole] = useState<UserRole>(user.role);
  const [status, setStatus] = useState<'active' | 'inactive' | 'suspended'>(user.status);
  const [isUpdating, setIsUpdating] = useState(false);

const handleUpdateUser = async () => {
  setIsUpdating(true);

  try {
    const res = await fetch(`/api/admin/users/${user.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role, status }),
    });

    if (!res.ok) {
      const { error } = await res.json();
      throw new Error(error);
    }

    toast.success(`User ${user.name} has been updated`);
    onClose();
  } catch (err: any) {
    toast.error("Failed to update user", {
      description: err.message,
    });
  } finally {
    setIsUpdating(false);
  }
};


  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'active':
        return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>;
      case 'inactive':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Inactive</Badge>;
      case 'suspended':
        return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Suspended</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getRoleBadge = (role: string) => {
    switch(role) {
      case 'admin':
        return <Badge variant="outline" className="bg-purple-100 text-purple-800 hover:bg-purple-100">Admin</Badge>;
      case 'manager':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">Manager</Badge>;
      case 'customer':
        return <Badge variant="outline" className="bg-gray-100 text-gray-800 hover:bg-gray-100">Customer</Badge>;
      default:
        return <Badge variant="outline">{role}</Badge>;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>User Details</span>
            {getStatusBadge(user.status)}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* User Profile */}
          <div className="flex items-start gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="space-y-1">
              <h3 className="text-xl font-semibold">{user.name}</h3>
              <div className="flex items-center gap-2">
                {getRoleBadge(user.role)}
                <span className="text-sm text-muted-foreground">ID: {user.id}</span>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Mail size={14} className="mr-1" />
                {user.email}
              </div>
            </div>
          </div>

          <Separator />

          {/* User Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground flex items-center">
                <CalendarDays size={14} className="mr-1" />
                Joined
              </p>
              <p>{user.joinDate}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground flex items-center">
                <Clock size={14} className="mr-1" />
                Last Active
              </p>
              <p>{user.lastActive}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground flex items-center">
                <ShoppingCart size={14} className="mr-1" />
                Orders
              </p>
              <p>{user.orderCount}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground flex items-center">
                <CreditCard size={14} className="mr-1" />
                Total Spent
              </p>
              <p>£{user.totalSpent.toFixed(2)}</p>
            </div>
          </div>

          <Separator />

          {/* User Settings */}
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Role</label>
              <Select value={role} onValueChange={(value) => setRole(value as UserRole)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="customer">Customer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-1 block">Status</label>
              <Select 
                value={status} 
                onValueChange={(value) => setStatus(value as 'active' | 'inactive' | 'suspended')}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleUpdateUser} disabled={isUpdating}>
            {isUpdating ? (
              <>
                <Loader2 size={16} className="mr-2 animate-spin" />
                Updating...
              </>
            ) : (
              'Update User'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default UserDetailsDialog;
