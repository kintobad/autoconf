import { useState, useEffect } from 'react';
import { Product } from '@/types';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { ImageIcon, X } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

interface Category {
  id: number;
  name: string;
}

interface ProductFormDialogProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'add' | 'edit';
  product?: Product;
  onSaved?: () => void;
  categories: Category[];
}

const ProductFormDialog = ({
  isOpen,
  onClose,
  mode,
  product,
  onSaved,
  categories
}: ProductFormDialogProps) => {
  const defaultForm = {
    title: '',
    price: 0,
    description: '',
    shortDescription: '',
    category_id: 0,
    subcategory: '',
    imageUrl: '',
    stock: 0,
    thcPercentage: 0,
    cbdPercentage: 0,
    indicaPercentage: 0,
    sativaPercentage: 0,
  };

  const [formData, setFormData] = useState(defaultForm);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (mode === 'edit' && product) {
        setFormData({
          title: product.title || '',
          price: product.price || 0,
          description: product.description || '',
          shortDescription: product.shortDescription || '',
          category_id: product.category_id || 0,
          subcategory: product.subcategory || '',
          imageUrl: product.image_urls?.[0] || '',
          stock: product.stock || 0,
          thcPercentage: product.thcPercentage || 0,
          cbdPercentage: product.cbdPercentage || 0,
          indicaPercentage: product.indicaPercentage || 0,
          sativaPercentage: product.sativaPercentage || 0,
        });
      } else {
        setFormData(defaultForm);
      }
    }
  }, [isOpen, mode, product]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const numericFields = ['price', 'stock', 'thcPercentage', 'cbdPercentage', 'indicaPercentage', 'sativaPercentage'];
    setFormData({
      ...formData,
      [name]: numericFields.includes(name) ? parseFloat(value) || 0 : value,
    });
  };

  const handleSelectChange = (value: string) => {
    setFormData({ ...formData, category_id: parseInt(value) });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('File must be an image');
      return;
    }

    const formDataToSend = new FormData();
    formDataToSend.append('file', file);

    setIsUploadingImage(true);

    try {
      const response = await fetch('/api/admin/products/upload', {
        method: 'POST',
        body: formDataToSend,
      });

      const result = await response.json();

      if (!response.ok) throw new Error(result.error || 'Upload failed');

      setFormData((prev) => ({ ...prev, imageUrl: result.url }));
      toast.success('Image uploaded successfully');
    } catch (err: any) {
      console.error('Image upload error:', err.message);
      toast.error(`Upload error: ${err.message}`);
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);

    if (isUploadingImage) {
      toast.error('Please wait for image upload to complete');
      setIsSubmitting(false);
      return;
    }

    if (!formData.title) {
      toast.error('Title is required');
      setIsSubmitting(false);
      return;
    }

    const dataToSave = {
      title: formData.title,
      description: formData.description,
      short_description: formData.shortDescription,
      category_id: formData.category_id || null,
      subcategory: formData.subcategory,
      price: formData.price,
      stock: formData.stock,
      thc_percentage: formData.thcPercentage,
      cbd_percentage: formData.cbdPercentage,
      indica_percentage: formData.indicaPercentage,
      sativa_percentage: formData.sativaPercentage,
      image_urls: [formData.imageUrl].filter(Boolean),
    };

    try {
      let response;
      if (mode === 'add') {
        response = await supabase.from('products').insert([dataToSave]).select().single();
      } else if (mode === 'edit' && product?.id) {
        response = await supabase.from('products').update(dataToSave).eq('id', product.id).select().single();
      }

      if (response?.error) throw response.error;

      toast.success(
        mode === 'add'
          ? `Product "${formData.title}" added`
          : `Product "${formData.title}" updated`
      );

      onSaved?.();
      onClose();
    } catch (err: any) {
      console.error('Save failed:', err.message);
      toast.error(`Save error: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === 'add' ? 'Add Product' : `Edit: ${product?.title}`}
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="text-sm font-medium">Title *</label>
              <Input name="title" value={formData.title} onChange={handleChange} />
            </div>

            <div>
              <label className="text-sm font-medium">Category</label>
              <Select value={formData.category_id.toString()} onValueChange={handleSelectChange}>
                <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id.toString()}>
                      {cat.name.charAt(0).toUpperCase() + cat.name.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">Subcategory</label>
              <Input name="subcategory" value={formData.subcategory} onChange={handleChange} />
            </div>

            <div>
              <label className="text-sm font-medium">Price (£)</label>
              <Input name="price" type="number" step="0.01" value={formData.price} onChange={handleChange} />
            </div>

            <div>
              <label className="text-sm font-medium">Stock</label>
              <Input name="stock" type="number" value={formData.stock} onChange={handleChange} />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium">Product Image</label>
            <div className="border-2 border-dashed rounded p-4">
              {formData.imageUrl ? (
                <div className="relative">
                  <img
                    src={formData.imageUrl}
                    onError={(e) => { e.currentTarget.src = '/default.png'; }}
                    className="h-32 mx-auto object-cover rounded"
                  />
                  <button onClick={() => setFormData({ ...formData, imageUrl: '' })} className="absolute top-0 right-0 bg-destructive text-white p-1 rounded-full">
                    <X size={12} />
                  </button>
                </div>
              ) : (
                <div className="text-center flex flex-col items-center gap-2">
                  <ImageIcon className="h-12 w-12 text-muted-foreground" />
                  <Input name="imageUrl" type="text" value={formData.imageUrl} onChange={handleChange} placeholder="Image URL" />
                  <Input type="file" accept="image/*" onChange={handleImageUpload} />
                </div>
              )}
            </div>
          </div>

          {(formData.category_id === 1 || formData.category_id === 2) && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">THC %</label>
                <Input name="thcPercentage" type="number" step="0.1" value={formData.thcPercentage} onChange={handleChange} />
              </div>
              <div>
                <label className="text-sm font-medium">CBD %</label>
                <Input name="cbdPercentage" type="number" step="0.1" value={formData.cbdPercentage} onChange={handleChange} />
              </div>
              {formData.category_id === 1 && (
                <>
                  <div>
                    <label className="text-sm font-medium">Indica %</label>
                    <Input name="indicaPercentage" type="number" step="1" value={formData.indicaPercentage} onChange={handleChange} />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Sativa %</label>
                    <Input name="sativaPercentage" type="number" step="1" value={formData.sativaPercentage} onChange={handleChange} />
                  </div>
                </>
              )}
            </div>
          )}

          <div>
            <label className="text-sm font-medium">Short Description</label>
            <Input name="shortDescription" value={formData.shortDescription} onChange={handleChange} />
          </div>

          <div>
            <label className="text-sm font-medium">Full Description</label>
            <Textarea name="description" rows={4} value={formData.description} onChange={handleChange} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={isSubmitting || isUploadingImage}>
            {isSubmitting || isUploadingImage
              ? 'Saving...'
              : mode === 'add'
              ? 'Add'
              : 'Update'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ProductFormDialog;
