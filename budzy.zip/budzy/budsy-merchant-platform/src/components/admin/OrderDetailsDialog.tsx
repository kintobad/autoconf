import { useState, useEffect } from 'react';
import { Order, OrderStatus, Product } from '@/types';
import { supabase } from '@/lib/supabaseClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  Loader2, MapPin, Phone, Mail, Clock,
  Truck, CreditCard, User, FileText
} from 'lucide-react';
import { generatePackingSlip } from '@/utils/pdfUtils';

interface OrderDetailsDialogProps {
  order: Order;
  isOpen: boolean;
  onClose: () => void;
}

const OrderDetailsDialog = ({ order, isOpen, onClose }: OrderDetailsDialogProps) => {
  const [status, setStatus] = useState<OrderStatus>(order.status);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [productsMap, setProductsMap] = useState<Record<string, Product>>({});

  useEffect(() => {
    if (!isOpen) return;

    const loadProducts = async () => {
      const productIds = order.items.map(i => i.productId);
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .in('id', productIds);

      if (error) {
        toast.error('Failed to load products');
        console.error(error);
        return;
      }

      const map: Record<string, Product> = {};
      data?.forEach((product: Product) => {
        map[product.id] = product;
      });
      setProductsMap(map);
    };

    loadProducts();
  }, [isOpen, order.items]);

  const orderItems = order.items.map(item => {
    const product = productsMap[item.productId];

    const normalizedProduct = {
      id: product?.id ?? item.productId,
      title: product?.title ?? 'Unknown Product',
      imageUrl: product?.imageUrl ?? '/placeholder.svg',
      category: product?.category ?? 'N/A',
      price: product?.price ?? item.price,
    };

    return {
      ...item,
      product: normalizedProduct,
    };
  });

  const handleUpdateStatus = () => {
    setIsUpdating(true);
    setTimeout(() => {
      toast.success(`Order ${order.id} status updated to ${status}`);
      setIsUpdating(false);
      onClose();
    }, 1000);
  };

  const handleGeneratePackingSlip = async () => {
    setIsGeneratingPdf(true);
    try {
      await generatePackingSlip(order, orderItems);
      toast.success('Packing slip generated successfully');
    } catch (error) {
      toast.error('Failed to generate packing slip');
      console.error(error);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    const map: Record<OrderStatus, JSX.Element> = {
      completed: <Badge className="bg-green-100 text-green-800">Completed</Badge>,
      cancelled: <Badge className="bg-red-100 text-red-800">Cancelled</Badge>,
      processing: <Badge className="bg-yellow-100 text-yellow-800">Processing</Badge>,
      pending: <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>,
    };
    return map[status] ?? <Badge>{status}</Badge>;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Order #{order.id}</span>
            {getStatusBadge(status)}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="bg-muted/30 p-4 rounded-lg">
            <h3 className="font-medium mb-3 flex items-center">
              <User size={16} className="mr-2" />
              Customer Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start">
                <Mail size={16} className="mr-2 mt-0.5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p>{order.customer.toLowerCase().replace(/\s/g, '')}@example.com</p>
                </div>
              </div>
              <div className="flex items-start">
                <Phone size={16} className="mr-2 mt-0.5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <p>+44 {Math.floor(Math.random() * 9000000000 + 1000000000)}</p>
                </div>
              </div>
              <div className="flex items-start">
                <MapPin size={16} className="mr-2 mt-0.5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Address</p>
                  <p>123 High Street, London</p>
                </div>
              </div>
              <div className="flex items-start">
                <Clock size={16} className="mr-2 mt-0.5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Order Date</p>
                  <p>{order.date}</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-3 flex items-center">
              <Truck size={16} className="mr-2" />
              Order Status
            </h3>
            <Select value={status} onValueChange={(v) => setStatus(v as OrderStatus)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="processing">Processing</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          <div>
            <h3 className="font-medium mb-3 flex items-center">
              <CreditCard size={16} className="mr-2" />
              Order Items
            </h3>
            <div className="space-y-3">
              {orderItems.map((item, index) => (
                <div key={index} className="flex items-center gap-3 border-b pb-3">
                  <img
                    src={item.product.imageUrl}
                    alt={item.product.title}
                    className="w-16 h-16 object-cover rounded-md"
                  />
                  <div className="flex-grow">
                    <h4 className="font-medium">{item.product.title}</h4>
                    <p className="text-sm text-muted-foreground">{item.product.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">£{item.price.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-medium mb-3">Order Summary</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>£{order.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span>Free</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax</span>
                <span>£{(order.total * 0.2).toFixed(2)}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span>£{(order.total * 1.2).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:justify-between">
          <Button
            variant="outline"
            onClick={handleGeneratePackingSlip}
            disabled={isGeneratingPdf}
            className="w-full sm:w-auto"
          >
            {isGeneratingPdf ? (
              <>
                <Loader2 className="mr-2 animate-spin" size={16} />
                Generating...
              </>
            ) : (
              <>
                <FileText className="mr-2" size={16} />
                Generate Packing Slip
              </>
            )}
          </Button>
          <div className="flex gap-2 w-full sm:w-auto">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleUpdateStatus} disabled={isUpdating}>
              {isUpdating ? (
                <>
                  <Loader2 className="mr-2 animate-spin" size={16} />
                  Updating...
                </>
              ) : (
                'Update Order'
              )}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default OrderDetailsDialog;
