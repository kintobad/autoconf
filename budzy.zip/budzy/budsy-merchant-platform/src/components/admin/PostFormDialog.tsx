
import { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter, 
  DialogDescription
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Post } from '@/lib/models';
import { useToast } from '@/hooks/use-toast';
import { v4 as uuidv4 } from 'uuid';

// Categories for blog posts
const postCategories = [
  'Education',
  'Science',
  'Cultivation',
  'Industry',
  'Wellness',
  'Recipes',
  'News',
  'Community'
];

interface PostFormDialogProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'add' | 'edit';
  post?: Post;
  onSave?: (post: Post) => void;
}

const PostFormDialog = ({ isOpen, onClose, mode, post, onSave }: PostFormDialogProps) => {
  const { toast } = useToast();
  const [title, setTitle] = useState(post?.title || '');
  const [slug, setSlug] = useState(post?.slug || '');
  const [excerpt, setExcerpt] = useState(post?.excerpt || '');
  const [content, setContent] = useState(post?.content || '');
  const [category, setCategory] = useState(post?.category || postCategories[0]);
  const [tags, setTags] = useState(post?.tags?.join(', ') || '');
  const [imageUrl, setImageUrl] = useState(post?.imageUrl || '');
  const [status, setStatus] = useState<'draft' | 'published'>(post?.status || 'draft');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const generateSlugFromTitle = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^\w\s]/gi, '')
      .replace(/\s+/g, '-');
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTitle = e.target.value;
    setTitle(newTitle);
    
    // Only auto-generate slug if this is a new post or the slug hasn't been manually modified
    if (mode === 'add' || (post && post.slug === slug)) {
      setSlug(generateSlugFromTitle(newTitle));
    }
  };

  const validateForm = (): boolean => {
    if (!title.trim()) {
      toast({
        title: "Validation Error",
        description: "Title is required",
        variant: "destructive"
      });
      return false;
    }

    if (!slug.trim()) {
      toast({
        title: "Validation Error",
        description: "Slug is required",
        variant: "destructive"
      });
      return false;
    }

    if (!content.trim()) {
      toast({
        title: "Validation Error",
        description: "Content is required",
        variant: "destructive"
      });
      return false;
    }

    return true;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const tagArray = tags
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag !== '');

      const newPost: Post = {
        id: post?.id || uuidv4(),
        title,
        slug,
        excerpt,
        content,
        category,
        tags: tagArray,
        imageUrl,
        status,
        author: post?.author || 'Admin User', // In a real app, this would be the current user
        createdAt: post?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      // In a real app, this would be an API call
      if (onSave) {
        onSave(newPost);
      }

      toast({
        title: `Post ${mode === 'add' ? 'created' : 'updated'} successfully`,
        description: `"${title}" has been ${mode === 'add' ? 'added to' : 'updated in'} your blog posts.`,
      });

      onClose();
    } catch (error) {
      console.error('Error saving post:', error);
      toast({
        title: "Error",
        description: `Failed to ${mode === 'add' ? 'create' : 'update'} post. Please try again.`,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === 'add' ? 'Add New Blog Post' : 'Edit Blog Post'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'add' 
              ? 'Create a new blog post to publish on your site.' 
              : 'Make changes to your existing blog post.'}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-1 gap-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={title}
              onChange={handleTitleChange}
              placeholder="Enter post title"
            />
          </div>
          
          <div className="grid grid-cols-1 gap-2">
            <Label htmlFor="slug">Slug</Label>
            <Input
              id="slug"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              placeholder="url-friendly-title"
            />
          </div>
          
          <div className="grid grid-cols-1 gap-2">
            <Label htmlFor="excerpt">Excerpt</Label>
            <Textarea
              id="excerpt"
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              placeholder="Brief summary of the post"
              rows={2}
            />
          </div>
          
          <div className="grid grid-cols-1 gap-2">
            <Label htmlFor="content">Content</Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Full post content in Markdown"
              rows={10}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    {postCategories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="status">Status</Label>
              <Select 
                value={status} 
                onValueChange={(value: 'draft' | 'published') => setStatus(value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 gap-2">
            <Label htmlFor="tags">Tags (comma separated)</Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="e.g., CBD, Education, Research"
            />
          </div>
          
          <div className="grid grid-cols-1 gap-2">
            <Label htmlFor="imageUrl">Featured Image URL</Label>
            <Input
              id="imageUrl"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://example.com/image.jpg"
            />
          </div>
          
          {imageUrl && (
            <div className="mt-2 rounded-md overflow-hidden h-40 bg-muted">
              <img 
                src={imageUrl} 
                alt="Post preview" 
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://placehold.co/600x400?text=Image+Preview';
                }}
              />
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? 'Saving...' : mode === 'add' ? 'Create Post' : 'Update Post'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PostFormDialog;
