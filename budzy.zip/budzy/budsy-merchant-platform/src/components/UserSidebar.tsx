import {
  User,
  ShoppingBag,
  MapPin,
  Settings,
  LogOut,
  Ticket,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/lib/supabaseClient";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";

interface UserSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const UserSidebar = ({ activeTab, setActiveTab }: UserSidebarProps) => {
  const navigate = useNavigate();
  const [logoutOpen, setLogoutOpen] = useState(false);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out");
    navigate("/signin");
  };

  const menuItems = [
    { id: "profile", label: "My Profile", icon: User },
    { id: "orders", label: "My Orders", icon: ShoppingBag },
    { id: "addresses", label: "My Addresses", icon: MapPin },
    { id: "tickets", label: "Support Tickets", icon: Ticket },
    { id: "settings", label: "Account Settings", icon: Settings },
  ];

  return (
    <div className="bg-background rounded-lg border shadow-sm overflow-hidden">
      <div className="p-4">
        <h2 className="font-medium text-lg mb-4">Account Menu</h2>
        <nav className="space-y-1">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant={activeTab === item.id ? "default" : "ghost"}
              className={`w-full justify-start text-base ${
                activeTab === item.id
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground/80 hover:text-foreground"
              }`}
              onClick={() => setActiveTab(item.id)}
            >
              <item.icon className="mr-3 h-5 w-5" />
              {item.label}
            </Button>
          ))}
        </nav>
      </div>

      <div className="border-t p-4">
        <AlertDialog open={logoutOpen} onOpenChange={setLogoutOpen}>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              className="w-full justify-start text-destructive hover:bg-destructive/10 hover:text-destructive text-base"
            >
              <LogOut className="mr-3 h-5 w-5" />
              Sign Out
            </Button>
          </AlertDialogTrigger>

          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure you want to sign out?</AlertDialogTitle>
              <AlertDialogDescription>
                This will end your session and take you to the sign-in page.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleLogout}>Sign Out</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
};

export default UserSidebar;
