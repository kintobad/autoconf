
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Facebook, Mail, PhoneCall } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-muted py-12 mt-auto">
      <div className="page-container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and brief description */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex flex-col space-y-4">
              <Link to="/" className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                Budsy
              </Link>
              <p className="text-muted-foreground text-sm mt-2">
                Premium cannabis products curated for the discerning consumer.
              </p>
              <div className="flex space-x-4 mt-4">
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors" aria-label="Instagram">
                  <Instagram size={20} />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors" aria-label="Twitter">
                  <Twitter size={20} />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors" aria-label="Facebook">
                  <Facebook size={20} />
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/shop" className="text-muted-foreground hover:text-primary transition-colors">
                  Shop All
                </Link>
              </li>
              <li>
                <Link to="/shop?category=flowers" className="text-muted-foreground hover:text-primary transition-colors">
                  Cannabis Flowers
                </Link>
              </li>
              <li>
                <Link to="/shop?category=extracts" className="text-muted-foreground hover:text-primary transition-colors">
                  Extracts & Concentrates
                </Link>
              </li>
              <li>
                <Link to="/shop?category=edibles" className="text-muted-foreground hover:text-primary transition-colors">
                  Edibles
                </Link>
              </li>
              <li>
                <Link to="/shop?category=medical" className="text-muted-foreground hover:text-primary transition-colors">
                  Medical Products
                </Link>
              </li>
              <li>
                <Link to="/shop?category=accessories" className="text-muted-foreground hover:text-primary transition-colors">
                  Accessories
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div className="col-span-1">
            <h3 className="font-semibold text-lg mb-4">Support</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/faq" className="text-muted-foreground hover:text-primary transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/shipping" className="text-muted-foreground hover:text-primary transition-colors">
                  Shipping & Returns
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-muted-foreground hover:text-primary transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-muted-foreground hover:text-primary transition-colors">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="col-span-1">
            <h3 className="font-semibold text-lg mb-4">Contact</h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <Mail size={18} className="mr-3 text-primary" />
                <a href="mailto:info@budsy.com" className="text-muted-foreground hover:text-primary transition-colors">
                  info@budsy.com
                </a>
              </div>
              <div className="flex items-center">
                <PhoneCall size={18} className="mr-3 text-primary" />
                <a href="tel:+1234567890" className="text-muted-foreground hover:text-primary transition-colors">
                  (123) 456-7890
                </a>
              </div>
              <p className="text-sm text-muted-foreground pt-4">
                1234 Cannabis Street<br />
                Green City, CA 98765
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Budsy. All rights reserved.
          </p>
          <div className="flex mt-4 md:mt-0 space-x-6">
            <Link to="/privacy" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
