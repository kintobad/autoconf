
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  ShoppingBag,
  Package,
  Users,
  CreditCard,
  BarChart2,
  MessageSquare,
  Ticket,
  History,
  Wrench,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  FolderTree,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState, useEffect } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';

type SidebarItem = {
  icon: React.ElementType;
  label: string;
  path: string;
  disabled?: boolean;
};

const sidebarItems: SidebarItem[] = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/admin' },
  { icon: ShoppingBag, label: 'Orders', path: '/admin/orders' },
  { icon: Package, label: 'Products', path: '/admin/products' },
  { icon: FolderTree, label: 'Categories', path: '/admin/categories' },
  { icon: Users, label: 'Users', path: '/admin/users' },
  { icon: FileText, label: 'Blog Posts', path: '/admin/posts' },
  { icon: BarChart2, label: 'Analytics', path: '/admin/analytics' },
  { icon: MessageSquare, label: 'Reviews', path: '/admin/reviews' },
  { icon: Ticket, label: 'Tickets', path: '/admin/tickets' },
  { icon: History, label: 'History', path: '/admin/history' },
  { icon: CreditCard, label: 'Payments', path: '/admin/payments', disabled: true },
  { icon: Wrench, label: 'Tools', path: '/admin/tools', disabled: true },
  { icon: Settings, label: 'Settings', path: '/admin/settings', disabled: true },
];

const AdminSidebar = () => {
  const location = useLocation();
  const isMobile = useIsMobile();
  const [collapsed, setCollapsed] = useState(false);

  // Auto-collapse on mobile
  useEffect(() => {
    if (isMobile) {
      setCollapsed(true);
    } else {
      setCollapsed(false);
    }
  }, [isMobile]);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  return (
    <div
      className={`h-screen fixed top-0 left-0 z-40 bg-sidebar transition-all duration-300 flex flex-col ${
        collapsed ? 'w-[70px]' : 'w-[250px]'
      } border-r border-border`}
    >
      {/* Logo area */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        {!collapsed && (
          <Link to="/" className="flex items-center">
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary truncate">
              Budsy Admin
            </span>
          </Link>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleSidebar}
          className="ml-auto"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </Button>
      </div>

      {/* Navigation links */}
      <div className="flex-1 py-4 overflow-y-auto">
        <nav className="px-2 space-y-1">
          {sidebarItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.label}
                to={item.disabled ? '#' : item.path}
                className={`flex items-center px-3 py-2.5 rounded-md transition-colors ${
                  isActive
                    ? 'bg-primary/10 text-primary'
                    : 'hover:bg-sidebar-accent text-sidebar-foreground hover:text-sidebar-foreground'
                } ${item.disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={(e) => item.disabled && e.preventDefault()}
              >
                <item.icon size={20} className={collapsed ? 'mx-auto' : 'mr-3'} />
                {!collapsed && <span>{item.label}</span>}
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Logout button */}
      <div className="p-4 border-t border-border">
        <Link to="/">
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start text-muted-foreground hover:text-foreground"
          >
            <LogOut size={20} className={collapsed ? 'mx-auto' : 'mr-3'} />
            {!collapsed && <span>Back to Shop</span>}
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default AdminSidebar;
