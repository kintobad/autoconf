
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { LayoutDashboard } from 'lucide-react';

const AdminLink = () => {
  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Link to="/admin">
        <Button size="lg" className="rounded-full shadow-lg">
          <LayoutDashboard className="mr-2" size={20} />
          Admin Panel
        </Button>
      </Link>
    </div>
  );
};

export default AdminLink;
