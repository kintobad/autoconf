// Импорты
import { useEffect, useState } from "react";
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription
} from "@/components/ui/card";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage
} from "@/components/ui/form";
import { Ticket, Plus, MessageSquare, Search } from "lucide-react";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/context/UserContext";

// Типы
interface MessageType {
  id: string;
  content: string;
  isAdmin: boolean;
  createdAt: string;
}

interface TicketType {
  id: string;
  subject: string;
  message: string;
  status: "open" | "in_progress" | "closed" | "resolved";
  priority: "low" | "medium" | "high" | "urgent";
  createdAt: string;
  updatedAt: string;
  department: string;
  customer_id: string;
  messages: MessageType[];
}

// Цвета
const statusColors = {
  open: "bg-green-100 text-green-800 hover:bg-green-100",
  in_progress: "bg-blue-100 text-blue-800 hover:bg-blue-100",
  closed: "bg-gray-100 text-gray-800 hover:bg-gray-100",
  resolved: "bg-purple-100 text-purple-800 hover:bg-purple-100"
};

const priorityColors = {
  low: "bg-blue-100 text-blue-800 hover:bg-blue-100",
  medium: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100",
  high: "bg-orange-100 text-orange-800 hover:bg-orange-100",
  urgent: "bg-red-100 text-red-800 hover:bg-red-100"
};

const UserTickets = () => {
  const { user, loading } = useUser();
  const { toast } = useToast();

  const [tickets, setTickets] = useState<TicketType[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<TicketType | null>(null);
  const [isNewTicketDialogOpen, setIsNewTicketDialogOpen] = useState(false);
  const [isViewTicketDialogOpen, setIsViewTicketDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const form = useForm({
    defaultValues: {
      subject: "",
      message: "",
      department: "support",
      priority: "medium"
    }
  });

  const fetchTickets = async () => {
    if (!user?.id) return;

    try {
      const res = await fetch(`/api/tickets/${user.id}`);
      const text = await res.text();
      const data = JSON.parse(text);
      setTickets(data);
    } catch (err) {
      console.error("❌ Error loading tickets:", err);
      toast({
        title: "Error",
        description: "Failed to load tickets.",
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    if (user?.id) fetchTickets();
  }, [user]);

  const handleCreateTicket = async (data: any) => {
    try {
      const res = await fetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, customer_id: user?.id })
      });

      if (res.ok) {
        const newTicket = await res.json();
        setTickets((prev) => [newTicket, ...prev]);
        setIsNewTicketDialogOpen(false);
        form.reset();
        toast({
          title: "Ticket Created",
          description: `Ticket ${newTicket.id} submitted successfully.`
        });
      } else {
        throw new Error();
      }
    } catch {
      toast({
        title: "Error",
        description: "Could not create ticket.",
        variant: "destructive"
      });
    }
  };

  const handleReplyToTicket = async (content: string) => {
    if (!selectedTicket) return;

    try {
      const res = await fetch(`/api/tickets/reply/${selectedTicket.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: content })
      });

      if (res.ok) {
        await fetchTickets();
        toast({ title: "Reply Sent", description: "Your message has been sent." });
      } else {
        throw new Error();
      }
    } catch {
      toast({
        title: "Error",
        description: "Could not send reply.",
        variant: "destructive"
      });
    }
  };

  const filteredTickets = tickets.filter((ticket) => {
    const matchesSearch =
      ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || ticket.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const formatDate = (dateString: string) =>
    new Date(dateString).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });

  if (loading) return <div className="p-6 text-muted-foreground">Loading tickets...</div>;
  if (!user) return <div className="p-6 text-red-500">User not found</div>;

  return (
    <div className="p-6 space-y-6">
      {/* Заголовок и кнопка */}
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Support Tickets</h1>
          <p className="text-muted-foreground">Manage your support requests</p>
        </div>
        <Dialog open={isNewTicketDialogOpen} onOpenChange={setIsNewTicketDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" />New Ticket</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create a Ticket</DialogTitle>
              <DialogDescription>We'll get back to you soon.</DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleCreateTicket)} className="space-y-4">
                <FormField control={form.control} name="subject" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl><Input {...field} required /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="department" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Department" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="support">Support</SelectItem>
                        <SelectItem value="billing">Billing</SelectItem>
                        <SelectItem value="shipping">Shipping</SelectItem>
                        <SelectItem value="technical">Technical</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="priority" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="message" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Message</FormLabel>
                    <FormControl><Textarea {...field} required /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsNewTicketDialogOpen(false)}>Cancel</Button>
                  <Button type="submit">Submit</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Фильтры */}
      <div className="flex gap-4">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search tickets..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Таблица */}
      <Card>
        <CardHeader />
        <CardContent>
          <div className="border rounded-md overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Updated</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTickets.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-6">No tickets found</TableCell>
                  </TableRow>
                ) : filteredTickets.map((ticket) => (
                  <TableRow key={ticket.id}>
                    <TableCell>{ticket.id}</TableCell>
                    <TableCell>{ticket.subject}</TableCell>
                    <TableCell>
                      <Badge className={statusColors[ticket.status]}>{ticket.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={priorityColors[ticket.priority]}>{ticket.priority}</Badge>
                    </TableCell>
                    <TableCell>{formatDate(ticket.updatedAt)}</TableCell>
                    <TableCell className="text-right">
                      <Dialog
                        open={isViewTicketDialogOpen && selectedTicket?.id === ticket.id}
                        onOpenChange={(open) => {
                          setIsViewTicketDialogOpen(open);
                          if (open) setSelectedTicket(ticket);
                        }}
                      >
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <MessageSquare className="mr-2 h-4 w-4" />
                            View
                          </Button>
                        </DialogTrigger>
                        {selectedTicket && (
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle className="flex gap-2 items-center">
                                <Ticket className="w-5 h-5" /> {selectedTicket.subject}
                              </DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="max-h-[300px] overflow-y-auto pr-2 space-y-2">
                                {selectedTicket.messages.map((msg) => (
                                  <div
                                    key={msg.id}
                                    className={`flex flex-col ${msg.isAdmin ? "items-start" : "items-end"}`}
                                  >
                                    <div className={`max-w-[80%] p-3 rounded-lg ${msg.isAdmin ? "bg-muted" : "bg-primary/10"}`}>
                                      <p className="text-sm">{msg.content}</p>
                                    </div>
                                    <div className="text-xs text-muted-foreground mt-1">
                                      {msg.isAdmin ? "Support" : "You"} • {formatDate(msg.createdAt)}
                                    </div>
                                  </div>
                                ))}
                              </div>
                              {selectedTicket.status !== "closed" && (
                                <form
                                  onSubmit={(e) => {
                                    e.preventDefault();
                                    const content = new FormData(e.currentTarget).get("reply") as string;
                                    handleReplyToTicket(content);
                                    e.currentTarget.reset();
                                  }}
                                  className="space-y-2"
                                >
                                  <Textarea name="reply" required placeholder="Your reply..." />
                                  <div className="flex justify-end">
                                    <Button type="submit">Send</Button>
                                  </div>
                                </form>
                              )}
                            </div>
                          </DialogContent>
                        )}
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserTickets;
