import { useEffect, useState } from "react";
import { useUser } from "@/context/UserContext";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Key, Shield, AlertTriangle } from "lucide-react";
import ParcelTracker from "@/components/user/ParcelTracker";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { supabase } from "@/lib/supabaseClient";

const UserSettings = () => {
  const { user } = useUser();
  const { toast } = useToast();

  const [orderUpdates, setOrderUpdates] = useState(true);
  const [emailMarketing, setEmailMarketing] = useState(true);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [newPassword, setNewPassword] = useState("");

  const [qr, setQr] = useState("");
  const [token, setToken] = useState("");
  const [show2FADialog, setShow2FADialog] = useState(false);

  useEffect(() => {
    const fetchPreferences = async () => {
      if (!user?.email) return;
      try {
        const res = await fetch(`/api/user/profile/${user.email}`);
        const data = await res.json();
        setOrderUpdates(data.order_updates ?? true);
        setEmailMarketing(data.email_marketing ?? true);
      } catch (e) {
        console.error("Failed to load preferences:", e);
      }
    };
    fetchPreferences();
  }, [user]);

  const savePreferences = async (type: string, value: boolean) => {
    if (!user?.id) return;

    const body = {
      userId: user.id,
      orderUpdates: type === "order_updates" ? value : orderUpdates,
      emailMarketing: type === "email_marketing" ? value : emailMarketing,
    };

    try {
      await fetch("/api/user/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      toast({ title: "Preferences saved" });
    } catch (e) {
      toast({ title: "Error", description: "Could not save preferences", variant: "destructive" });
    }
  };

  const handleDelete = async () => {
    if (!user?.id) return;
    const confirmDelete = window.confirm("Are you sure you want to delete your account?");
    if (!confirmDelete) return;

    try {
      const res = await fetch("/api/user", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id }),
      });
      if (res.ok) {
        toast({ title: "Account deleted" });
      } else {
        throw new Error();
      }
    } catch (e) {
      toast({ title: "Error", description: "Could not delete account", variant: "destructive" });
    }
  };

  const handleChangePassword = async () => {
    if (!newPassword) return;
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      toast({ title: "Password updated successfully" });
      setShowPasswordDialog(false);
    } catch (e) {
      toast({ title: "Error", description: "Failed to update password", variant: "destructive" });
    }
  };

  const handle2FASetup = async () => {
    if (!user?.id || !user.email) return;
    const res = await fetch("/api/user/2fa/setup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: user.id, email: user.email }),
    });
    const data = await res.json();
    setQr(data.qr);
    setShow2FADialog(true);
  };

  const handle2FAVerify = async () => {
    const res = await fetch("/api/user/2fa/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: user?.id, token }),
    });

    if (res.ok) {
      toast({ title: "2FA Enabled" });
      setShow2FADialog(false);
    } else {
      toast({ title: "Error", description: "Invalid token", variant: "destructive" });
    }
  };

  return (
    <div className="p-6 space-y-8">
      {/* Notifications */}
      <section>
        <h2 className="text-2xl font-semibold mb-4">Notifications</h2>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="order-updates">Order Updates</Label>
              <p className="text-sm text-muted-foreground">Receive notifications about order status</p>
            </div>
            <Switch id="order-updates" checked={orderUpdates} onCheckedChange={val => {
              setOrderUpdates(val);
              savePreferences("order_updates", val);
            }} />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="email-marketing">Email Marketing</Label>
              <p className="text-sm text-muted-foreground">Receive emails about promotions</p>
            </div>
            <Switch id="email-marketing" checked={emailMarketing} onCheckedChange={val => {
              setEmailMarketing(val);
              savePreferences("email_marketing", val);
            }} />
          </div>
        </div>
      </section>

      <Separator className="my-6" />

      {/* Parcel Tracking */}
      <section>
        <h2 className="text-2xl font-semibold mb-4">Parcel Tracking</h2>
        <ParcelTracker />
      </section>

      <Separator className="my-6" />

      {/* Security */}
      <section>
        <h2 className="text-2xl font-semibold mb-4">Security</h2>
        <div className="space-y-6">
          <div className="flex justify-between gap-4 items-center">
            <div className="flex items-start gap-4">
              <Key className="h-5 w-5 text-muted-foreground" />
              <div>
                <h4 className="font-medium">Password</h4>
                <p className="text-sm text-muted-foreground">Last changed 3 months ago</p>
              </div>
            </div>
            <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
              <DialogTrigger asChild>
                <Button variant="outline">Change Password</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Change Your Password</DialogTitle></DialogHeader>
                <Input type="password" placeholder="New password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
                <Button onClick={handleChangePassword}>Update Password</Button>
              </DialogContent>
            </Dialog>
          </div>

          <Separator />

          <div className="flex justify-between gap-4 items-center">
            <div className="flex items-start gap-4">
              <Shield className="h-5 w-5 text-muted-foreground" />
              <div>
                <h4 className="font-medium">Two-Factor Authentication</h4>
                <p className="text-sm text-muted-foreground">Add extra security to your account</p>
              </div>
            </div>
            <Button variant="outline" onClick={handle2FASetup}>Enable 2FA</Button>
            <Dialog open={show2FADialog} onOpenChange={setShow2FADialog}>
              <DialogContent>
                <DialogHeader><DialogTitle>Scan QR and enter code</DialogTitle></DialogHeader>
                <img src={qr} alt="2FA QR Code" className="mx-auto" />
                <Input type="text" placeholder="Enter 6-digit code" value={token} onChange={(e) => setToken(e.target.value)} />
                <Button onClick={handle2FAVerify}>Verify</Button>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </section>

      <Separator className="my-6" />

      {/* Danger Zone */}
      <section>
        <h2 className="text-2xl font-semibold text-destructive mb-4">Danger Zone</h2>
        <div className="bg-destructive/5 border border-destructive/20 rounded-lg p-6">
          <div className="flex justify-between items-center">
            <div className="flex items-start gap-4">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              <div>
                <h4 className="font-medium">Delete Account</h4>
                <p className="text-sm text-muted-foreground">This will remove your account permanently</p>
              </div>
            </div>
            <Button variant="destructive" onClick={handleDelete}>Delete Account</Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default UserSettings;
