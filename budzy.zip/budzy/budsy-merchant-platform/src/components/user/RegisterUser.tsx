import { useAppKit, useAppKitAccount } from "@reown/appkit/react";
import axios from "axios";
import { useState } from "react";

export default function RegisterUser() {
  const { address, isConnected } = useAppKitAccount();
  const { open } = useAppKit();

  const [email, setEmail] = useState<string | null>(
    localStorage.getItem("user_email")
  );

  const register = async () => {
    if (!isConnected || !email || !address) {
      alert("Please connect your wallet and verify your email.");
      return;
    }

    try {
      await axios.post("http://localhost:3001/api/user/register", {
        email,
        walletAddress: address,
      });

      alert("Registration successful!");
      localStorage.removeItem("user_email");
    } catch (err) {
      console.error(err);
      alert("Registration failed. Please try again.");
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">User Registration</h2>
      <p>Email: {email || "—"}</p>
      <p>Wallet: {address || "—"}</p>

      <button
        onClick={() => open()}
        className="mt-2 p-2 bg-gray-200 text-black rounded"
      >
        Connect Wallet
      </button>

      <button
        onClick={register}
        className="mt-4 p-2 bg-blue-600 text-white rounded"
      >
        Register
      </button>
    </div>
  );
}
 