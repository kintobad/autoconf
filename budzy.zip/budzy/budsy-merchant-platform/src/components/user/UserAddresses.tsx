// Импорты
import { useEffect, useState } from "react";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, MapPin } from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import {
  Form, FormField, FormItem, FormLabel, FormControl, FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { useUser } from "@/context/UserContext";

// Тип адреса
interface Address {
  id: number;
  name: string;
  street: string;
  city: string;
  state: string;
  zip_code: string;
  is_default: boolean;
}

const fieldNames = ["name", "street", "city", "state", "zipCode"] as const;
type FieldName = typeof fieldNames[number];

const UserAddresses = () => {
  const { user } = useUser();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentAddress, setCurrentAddress] = useState<Address | null>(null);

  const form = useForm({
    defaultValues: {
      name: "",
      street: "",
      city: "",
      state: "",
      zipCode: ""
    }
  });

  useEffect(() => {
    if (user?.email) fetchAddresses();
  }, [user]);

  const fetchAddresses = async () => {
    try {
      const res = await fetch(`/api/addresses/${user.email}`);
      const data = await res.json();
      setAddresses(data);
    } catch {
      toast.error("Failed to load addresses");
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: any) => {
    const payload = {
      name: data.name,
      street: data.street,
      city: data.city,
      state: data.state,
      zipCode: data.zipCode
    };

    try {
      if (currentAddress) {
        await fetch(`/api/addresses/${currentAddress.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        toast.success("Address updated");
      } else {
        await fetch(`/api/addresses/${user.email}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        toast.success("Address added");
      }
      setIsDialogOpen(false);
      fetchAddresses();
    } catch {
      toast.error("Error saving address");
    }
  };

  const handleDeleteAddress = async (id: number, isDefault: boolean) => {
    if (isDefault && addresses.length > 1) {
      toast.error("Set another address as default first.");
      return;
    }
    try {
      await fetch(`/api/addresses/${id}`, { method: "DELETE" });
      toast.success("Address deleted");
      fetchAddresses();
    } catch {
      toast.error("Failed to delete address");
    }
  };

  const handleSetDefault = async (id: number) => {
    try {
      await fetch(`/api/addresses/${id}/default`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: user.email })
      });
      toast.success("Default address set");
      fetchAddresses();
    } catch {
      toast.error("Failed to update default");
    }
  };

  const handleEditAddress = (address: Address) => {
    setCurrentAddress(address);
    form.reset({
      name: address.name,
      street: address.street,
      city: address.city,
      state: address.state,
      zipCode: address.zip_code
    });
    setIsDialogOpen(true);
  };

  const handleAddAddress = () => {
    setCurrentAddress(null);
    form.reset({
      name: "",
      street: "",
      city: "",
      state: "",
      zipCode: ""
    });
    setIsDialogOpen(true);
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>My Addresses</CardTitle>
          <CardDescription>Manage your shipping and billing addresses</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading...</p>
          ) : addresses.length === 0 ? (
            <div className="text-center py-16 bg-muted/30 rounded-lg">
              <MapPin className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-4 text-lg">No saved addresses</p>
              <Button onClick={handleAddAddress}>
                <Plus className="mr-2 h-4 w-4" />
                Add Address
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {addresses.map((address) => (
                <Card key={address.id} className={`border ${address.is_default ? "border-primary border-2" : ""}`}>
                  {address.is_default && (
                    <div className="absolute top-0 right-0">
                      <Badge variant="default" className="rounded-bl-md rounded-tr-md px-3 py-1">
                        Default
                      </Badge>
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle>{address.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{address.street}</p>
                    <p className="text-muted-foreground">
                      {address.city}, {address.state} {address.zip_code}
                    </p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm" onClick={() => handleEditAddress(address)}>
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive"
                        onClick={() => handleDeleteAddress(address.id, address.is_default)}
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                    {!address.is_default && (
                      <Button variant="outline" size="sm" onClick={() => handleSetDefault(address.id)}>
                        Set as Default
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{currentAddress ? "Edit Address" : "Add Address"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {fieldNames.map((fieldName: FieldName) => (
                <FormField
                  key={fieldName}
                  control={form.control}
                  name={fieldName}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{fieldName.charAt(0).toUpperCase() + fieldName.slice(1)}</FormLabel>
                      <FormControl>
                        <Input placeholder={fieldName} {...field} required />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ))}
              <Separator className="my-2" />
              <DialogFooter>
                <Button type="submit" className="w-full">
                  {currentAddress ? "Save Changes" : "Add Address"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default UserAddresses;
