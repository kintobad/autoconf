import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar } from "@/components/ui/avatar";
import { User as UserIcon, Mail, Edit } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabaseClient";
import Navbar from "@/components/Navbar";

const API_BASE = "http://localhost:3001";

const UserProfile = () => {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    wallet_address: "",
  });
  const [editedData, setEditedData] = useState(userData);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = async () => {
    setLoading(true);
    try {
      const {
        data: { session },
        error: sessionError,
      } = await supabase.auth.getSession();

      if (sessionError || !session?.user) {
        throw new Error("No active session");
      }

      const email = session.user.email;
      if (!email) throw new Error("User email not found");

      const res = await fetch(`${API_BASE}/api/user/profile/${email}`);
      if (!res.ok) {
        const msg = await res.text();
        throw new Error("Failed to fetch profile: " + msg);
      }

      const profile = await res.json();
      setUserData(profile);
      setEditedData(profile);
    } catch (err: any) {
      console.error("❌ Profile load error:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleSave = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/user/profile/${userData.email}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: editedData.name }),
      });

      if (!res.ok) throw new Error("Failed to update profile");

      const updated = await res.json();
      setUserData(updated);
      setEditedData(updated);
      setIsEditing(false);
      toast.success("Profile updated");
    } catch (err: any) {
      toast.error(err.message || "Update failed");
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out");
    navigate("/signin");
  };

  const truncateWallet = (wallet: string) =>
    wallet ? `${wallet.slice(0, 6)}...${wallet.slice(-4)}` : "—";

  if (loading) return <div className="p-4 text-muted-foreground">Loading profile...</div>;
  if (error) return <div className="p-4 text-red-500">Error: {error}</div>;

  return (
    <>
      <Navbar />
      <div className="p-6 max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Profile Information</h2>
          <Button variant="outline" onClick={() => (isEditing ? handleSave() : setIsEditing(true))}>
            {isEditing ? "Save Changes" : (
              <>
                <Edit className="mr-2 h-4 w-4" />
                Edit Profile
              </>
            )}
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-[200px_1fr] gap-8">
          <div className="flex flex-col items-center text-center">
            <Avatar className="h-32 w-32 border-2">
              <UserIcon className="h-16 w-16" />
            </Avatar>
            <p className="mt-4 text-sm text-muted-foreground break-words">
              Wallet: {truncateWallet(userData.wallet_address)}
            </p>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              {isEditing ? (
                <Input
                  id="name"
                  value={editedData.name}
                  onChange={(e) => setEditedData({ ...editedData, name: e.target.value })}
                />
              ) : (
                <div className="flex items-center p-3 rounded-md bg-muted">
                  <UserIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                  <span>{userData.name}</span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <div className="flex items-center p-3 rounded-md bg-muted">
                <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
                <span>{userData.email}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserProfile;
