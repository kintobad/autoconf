
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Package, MapPin, Navigation, Route, Check, Clock, Truck } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

interface TrackingStatus {
  status: "delivered" | "in-transit" | "processing" | "out-for-delivery" | null;
  location: string;
  lastUpdated: string;
  estimatedDelivery: string;
  trackingEvents: {
    date: string;
    time: string;
    location: string;
    status: string;
    description: string;
  }[];
}

const ParcelTracker = () => {
  const [trackingNumber, setTrackingNumber] = useState("");
  const [loading, setLoading] = useState(false);
  const [trackingResult, setTrackingResult] = useState<TrackingStatus | null>(null);
  const { toast } = useToast();

  // Mock tracking data - in a real app, this would come from Royal Mail API
  const mockTrackingData: Record<string, TrackingStatus> = {
    "RM123456789GB": {
      status: "in-transit",
      location: "London Sorting Centre",
      lastUpdated: "2023-08-17 14:30",
      estimatedDelivery: "2023-08-19",
      trackingEvents: [
        {
          date: "16 Aug 2023",
          time: "09:15",
          location: "Sender's Depot",
          status: "Collected",
          description: "Item collected from sender"
        },
        {
          date: "16 Aug 2023",
          time: "17:45",
          location: "Regional Hub",
          status: "Processing",
          description: "Item is being processed at our hub"
        },
        {
          date: "17 Aug 2023",
          time: "14:30",
          location: "London Sorting Centre",
          status: "In Transit",
          description: "Item is in transit to delivery office"
        }
      ]
    },
    "RM987654321GB": {
      status: "delivered",
      location: "Birmingham",
      lastUpdated: "2023-08-15 11:20",
      estimatedDelivery: "2023-08-15",
      trackingEvents: [
        {
          date: "14 Aug 2023",
          time: "10:00",
          location: "Sender's Depot",
          status: "Collected",
          description: "Item collected from sender"
        },
        {
          date: "14 Aug 2023",
          time: "16:30",
          location: "Regional Hub",
          status: "Processing",
          description: "Item is being processed at our hub"
        },
        {
          date: "15 Aug 2023",
          time: "08:45",
          location: "Local Delivery Office",
          status: "Out for Delivery",
          description: "Item is out for delivery"
        },
        {
          date: "15 Aug 2023",
          time: "11:20",
          location: "Birmingham",
          status: "Delivered",
          description: "Item has been delivered"
        }
      ]
    }
  };

  const handleTrack = () => {
    if (!trackingNumber.trim()) {
      toast({
        title: "Tracking number required",
        description: "Please enter a valid tracking number",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    // Simulate API call with a timeout
    setTimeout(() => {
      const result = mockTrackingData[trackingNumber];
      
      if (result) {
        setTrackingResult(result);
      } else {
        toast({
          title: "Tracking information not found",
          description: "Please check your tracking number and try again",
          variant: "destructive"
        });
        setTrackingResult(null);
      }
      
      setLoading(false);
    }, 1500);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Collected":
        return <Package className="h-4 w-4" />;
      case "Processing":
        return <Clock className="h-4 w-4" />;
      case "In Transit":
        return <Truck className="h-4 w-4" />;
      case "Out for Delivery":
        return <Navigation className="h-4 w-4" />;
      case "Delivered":
        return <Check className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  const getStatusBadge = (status: string | null) => {
    if (!status) return null;
    
    switch (status) {
      case "delivered":
        return <Badge className="bg-green-500 hover:bg-green-600">Delivered</Badge>;
      case "in-transit":
        return <Badge className="bg-blue-500 hover:bg-blue-600">In Transit</Badge>;
      case "processing":
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Processing</Badge>;
      case "out-for-delivery":
        return <Badge>Out for Delivery</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Route className="h-5 w-5" />
            Royal Mail Parcel Tracking
          </CardTitle>
          <CardDescription>
            Track your Royal Mail parcels and see delivery status
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="Enter tracking number (e.g., RM123456789GB)"
              value={trackingNumber}
              onChange={(e) => setTrackingNumber(e.target.value)}
              className="flex-grow"
            />
            <Button 
              onClick={handleTrack} 
              disabled={loading}
              className="whitespace-nowrap"
            >
              {loading ? "Tracking..." : "Track Parcel"}
            </Button>
          </div>
          
          <div className="text-sm text-muted-foreground mt-2">
            <p>Try sample tracking numbers: RM123456789GB or RM987654321GB</p>
          </div>
        </CardContent>
      </Card>

      {trackingResult && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>Tracking Details</CardTitle>
                <CardDescription className="mt-1">
                  Tracking Number: {trackingNumber}
                </CardDescription>
              </div>
              {getStatusBadge(trackingResult.status)}
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Current Location</p>
                <p className="font-medium flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  {trackingResult.location}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Last Updated</p>
                <p className="font-medium">{trackingResult.lastUpdated}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Estimated Delivery</p>
                <p className="font-medium">{trackingResult.estimatedDelivery}</p>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-3">Tracking History</h3>
              <div className="space-y-4">
                {trackingResult.trackingEvents.map((event, index) => (
                  <div 
                    key={index} 
                    className="flex items-start gap-3 pb-4 border-b last:border-0"
                  >
                    <div className="mt-1 bg-muted rounded-full p-1">
                      {getStatusIcon(event.status)}
                    </div>
                    <div className="flex-grow">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">{event.status}</span>
                        <span className="text-sm text-muted-foreground">
                          {event.date} at {event.time}
                        </span>
                      </div>
                      <p className="text-sm mb-1">{event.description}</p>
                      <p className="text-sm text-muted-foreground">
                        <MapPin className="inline h-3 w-3 mr-1" />
                        {event.location}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ParcelTracker;
