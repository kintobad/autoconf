import { Link, useLocation } from 'react-router-dom';
import { useCart } from '@/context/CartContext';
import { ShoppingCart, Menu, X, User, Home, ShoppingBag, LogIn, Shield } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAuth } from "@/context/AuthContext";
import { Button } from '@/components/ui/button';

const Navbar = () => {
  const location = useLocation();
  const { cartCount } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const { user, loading, isAdmin } = useAuth(); 
  const isLoggedIn = !!user;

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);
  const isActive = (path: string) => location.pathname === path;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'py-3 glass-effect' : 'py-6 bg-transparent'}`}>
      <div className="page-container">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center" onClick={closeMenu}>
            <span className="text-xl md:text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
              Budsy
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            <Link to="/" className={`nav-link ${isActive('/') ? 'nav-link-active' : ''}`}>Home</Link>
            <Link to="/shop" className={`nav-link ${isActive('/shop') ? 'nav-link-active' : ''}`}>Shop</Link>

            {isAdmin && (
              <Link to="/admin" className={`nav-link ${location.pathname.startsWith('/admin') ? 'nav-link-active text-red-500' : ''}`}>
                Admin
              </Link>
            )}
          </nav>

          {/* Desktop Buttons */}
          <div className="hidden md:flex items-center space-x-2">
            {!loading && isLoggedIn ? (
              <Link to="/account">
                <Button variant="ghost" size="sm" className="btn-hover">
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </Button>
              </Link>
            ) : (
              !loading && (
                <>
                  <Link to="/signin">
                    <Button variant="ghost" size="sm" className="btn-hover">
                      Sign In
                    </Button>
                  </Link>
                  <Link to="/signup">
                    <Button size="sm" className="btn-hover">
                      Sign Up
                    </Button>
                  </Link>
                </>
              )
            )}

            <Link to="/cart">
              <Button variant="ghost" size="icon" className="btn-hover relative">
                <ShoppingCart size={20} />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
            </Link>
          </div>

          {/* Mobile Toggle */}
          <div className="md:hidden flex items-center space-x-2">
            <Link to="/cart">
              <Button variant="ghost" size="icon" className="relative mr-1">
                <ShoppingCart size={20} />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
            </Link>
            <Button variant="ghost" size="icon" onClick={toggleMenu}>
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 glass-effect animate-fade-in">
          <div className="flex flex-col p-4 space-y-3">
            <Link to="/" className="flex items-center p-2 hover:bg-background/50 rounded-md" onClick={closeMenu}>
              <Home size={18} className="mr-2" /> Home
            </Link>

            <Link to="/shop" className="flex items-center p-2 hover:bg-background/50 rounded-md" onClick={closeMenu}>
              <ShoppingBag size={18} className="mr-2" /> Shop
            </Link>

            {!loading && isAdmin && (
              <Link to="/admin" className={`nav-link ${location.pathname.startsWith('/admin') ? 'nav-link-active text-red-500' : ''}`}>
                Admin
              </Link>
            )}


            {!loading && isLoggedIn ? (
              <Link to="/account" className="flex items-center p-2 hover:bg-background/50 rounded-md" onClick={closeMenu}>
                <User size={18} className="mr-2" /> Profile
              </Link>
            ) : (
              !loading && (
                <Link to="/signin" className="flex items-center p-2 hover:bg-background/50 rounded-md" onClick={closeMenu}>
                  <LogIn size={18} className="mr-2" /> Sign In / Sign Up
                </Link>
              )
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
