
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ShoppingCart } from "lucide-react";
import { Badge } from "@/components/ui/badge";

// Sample product data (would come from API in a real application)
const featuredProducts = [
  {
    id: 1,
    name: "Purple Haze",
    category: "Flowers",
    type: "Sativa",
    thc: 22,
    cbd: 0.1,
    price: 12.99,
    image: "/placeholder.svg",
    isBestseller: true,
  },
  {
    id: 2,
    name: "CBD Relax Oil",
    category: "Extracts",
    type: "CBD",
    thc: 0.3,
    cbd: 20,
    price: 39.99,
    image: "/placeholder.svg",
  },
  {
    id: 3,
    name: "Cannabis Gummies",
    category: "Edibles",
    type: "THC",
    thc: 10,
    cbd: 2,
    price: 24.99,
    image: "/placeholder.svg",
    isNew: true,
  },
  {
    id: 4,
    name: "Classic Glass Bong",
    category: "Accessories",
    price: 49.99,
    image: "/placeholder.svg",
  },
];

const FeaturedProducts = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {featuredProducts.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
};

interface Product {
  id: number;
  name: string;
  category: string;
  type?: string;
  thc?: number;
  cbd?: number;
  price: number;
  image: string;
  isBestseller?: boolean;
  isNew?: boolean;
}

const ProductCard = ({ product }: { product: Product }) => {
  return (
    <Card className="product-card h-full overflow-hidden transition-all duration-300 hover:shadow-md">
      <CardContent className="p-0 flex flex-col h-full">
        <div className="relative">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-48 object-cover" 
          />
          {product.isBestseller && (
            <Badge className="absolute top-2 left-2 bg-yellow-500 text-white hover:bg-yellow-600">
              Bestseller
            </Badge>
          )}
          {product.isNew && (
            <Badge className="absolute top-2 left-2 bg-green-500 text-white hover:bg-green-600">
              New
            </Badge>
          )}
        </div>
        <div className="p-4 flex-1 flex flex-col">
          <div className="text-sm font-medium text-muted-foreground mb-1">
            {product.category} {product.type && `• ${product.type}`}
          </div>
          <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
          {(product.thc !== undefined || product.cbd !== undefined) && (
            <div className="flex gap-2 text-xs mb-3">
              {product.thc !== undefined && (
                <Badge variant="outline" className="text-xs">
                  THC {product.thc}%
                </Badge>
              )}
              {product.cbd !== undefined && (
                <Badge variant="outline" className="text-xs">
                  CBD {product.cbd}%
                </Badge>
              )}
            </div>
          )}
          <div className="mt-auto flex items-center justify-between">
            <span className="font-bold text-primary">£{product.price.toFixed(2)}</span>
            <div className="flex gap-2">
              <Link to={`/product/${product.id}`}>
                <Button variant="ghost" size="sm">
                  View
                </Button>
              </Link>
              <Button size="sm" className="w-9 p-0">
                <ShoppingCart size={16} />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FeaturedProducts;
