import { Link } from 'react-router-dom';
import { Product } from '@/types'; 
import { useCart } from '@/context/CartContext';
import { ShoppingCart, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

type ProductCardProps = {
  product: Product;
};

const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart } = useCart();
  const [isHovered, setIsHovered] = useState(false);
  const [isImageLoaded, setIsImageLoaded] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };

  return (
    <div 
      className="relative rounded-xl card-hover overflow-hidden bg-card"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link to={`/product/${product.id}`}>
        <div className="relative aspect-square overflow-hidden rounded-t-xl">
          {!isImageLoaded && (
            <div className="absolute inset-0 flex items-center justify-center bg-muted animate-pulse">
              <span className="sr-only">Loading...</span>
            </div>
          )}
          <img
            src={product.imageUrl}
            alt={product.title}
            className={`object-cover w-full h-full transition-transform duration-700 ${isHovered ? 'scale-110' : 'scale-100'} ${isImageLoaded ? 'opacity-100' : 'opacity-0'}`}
            onLoad={() => setIsImageLoaded(true)}
          />
          
          {/* Category Tag */}
          <div className="absolute top-3 left-3">
            <span className="text-xs font-medium px-2 py-1 bg-white/80 backdrop-blur-sm rounded-full text-foreground">
              {product.category || '—'}
            </span>
          </div>
        </div>

        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-semibold text-lg line-clamp-1">{product.title}</h3>
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-muted-foreground hover:text-primary transition-colors -mt-1 -mr-1" 
              aria-label="Add to favorites"
            >
              <Heart size={18} />
            </Button>
          </div>
          
          <p className="text-muted-foreground text-sm line-clamp-2 h-10 mb-3">
            {product.shortDescription}
          </p>
          
          {(product.thcPercentage || product.cbdPercentage) && (
            <div className="flex space-x-2 my-2">
              {product.thcPercentage && (
                <span className="text-xs px-2 py-1 bg-muted rounded-full">
                  THC: {product.thcPercentage}%
                </span>
              )}
              {product.cbdPercentage && (
                <span className="text-xs px-2 py-1 bg-muted rounded-full">
                  CBD: {product.cbdPercentage}%
                </span>
              )}
            </div>
          )}
          
          <div className="flex justify-between items-center pt-2">
            <span className="font-bold text-lg">£{product.price.toFixed(2)}</span>
            <Button 
              size="sm" 
              variant="default" 
              className="btn-hover"
              onClick={handleAddToCart}
            >
              <ShoppingCart size={16} className="mr-1" />
              Add
            </Button>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;
