import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { useCart } from "@/context/CartContext";

interface BTCModalProps {
  open: boolean;
  onClose: () => void;
  address: string;
  orderNumber: string;
}

export default function BTCModal({ open, onClose, address, orderNumber }: BTCModalProps) {
  const [copied, setCopied] = useState(false);
  const { clearCart } = useCart(); // ✅ импорт

  const handleCopy = async () => {
    await navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handlePaymentConfirmed = () => {
    clearCart();     // ✅ очищаем корзину
    onClose();       // закрываем окно
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md text-center">
        <DialogHeader>
          <DialogTitle>Order №{orderNumber}</DialogTitle>
        </DialogHeader>

        <div className="my-4 flex justify-center">
          <QRCodeCanvas value={address} size={180} />
        </div>

        <p className="text-sm text-muted-foreground mb-2">Send BTC to:</p>
        <pre className="text-xs bg-muted p-2 rounded break-all border">{address}</pre>

        <Button onClick={handleCopy} variant="secondary" className="mt-2 w-full">
          {copied ? (
            <>
              <Check className="mr-2 h-4 w-4" />
              Copied
            </>
          ) : (
            <>
              <Copy className="mr-2 h-4 w-4" />
              Copy Address
            </>
          )}
        </Button>

        <Button onClick={handlePaymentConfirmed} className="mt-4 w-full">
          ✅ I have paid
        </Button>

        <p className="text-xs text-muted-foreground mt-4">
          Once we receive the payment, your order will be processed.
        </p>
      </DialogContent>
    </Dialog>
  );
}
