import { BrowserRouter, Routes, Route } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";

import { CartProvider } from "@/context/CartContext";
import { AuthProvider } from "@/context/AuthContext";
import { UserProvider } from "@/context/UserContext";

import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Shop from "./pages/Shop";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import About from "./pages/About";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import UserCabinet from "./pages/UserCabinet";
import SignIn from "./pages/SignIn";
import SignUp from "./pages/SignUp";
import RegisterUser from "./components/user/RegisterUser";
import UserProfile from "./components/user/UserProfile";

import ProtectedAdminRoute from "@/components/admin/ProtectedAdminRoute";
import AdminLayout from "./layouts/AdminLayout";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminOrders from "./pages/admin/Orders";
import AdminProducts from "./pages/admin/Products";
import AdminUsers from "./pages/admin/Users";
import AdminCategories from "./pages/admin/Categories";
import AdminAnalytics from "./pages/admin/Analytics";
import AdminReviews from "./pages/admin/Reviews";
import AdminTickets from "./pages/admin/Tickets";
import AdminHistory from "./pages/admin/History";
import AdminPosts from "./pages/admin/Posts";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <UserProvider>
        <CartProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                {/* Public */}
                <Route path="/" element={<Index />} />
                <Route path="/shop" element={<Shop />} />
                <Route path="/shop/:category" element={<Shop />} />
                <Route path="/product/:id" element={<ProductDetail />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/about" element={<About />} />
                <Route path="/blog" element={<Blog />} />
                <Route path="/blog/:slug" element={<BlogPost />} />
                <Route path="/account" element={<UserCabinet />} />
                <Route path="/signin" element={<SignIn />} />
                <Route path="/signup" element={<SignUp />} />
                <Route path="/register-user" element={<RegisterUser />} />
                <Route path="/profile" element={<UserProfile />} />

                {/* Admin */}
                <Route
                  path="/admin"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminDashboard />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/orders"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminOrders />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/products"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminProducts />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/users"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminUsers />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/categories"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminCategories />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/analytics"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminAnalytics />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/reviews"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminReviews />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/tickets"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminTickets />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/history"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminHistory />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route
                  path="/admin/posts"
                  element={
                    <ProtectedAdminRoute>
                      <AdminLayout>
                        <AdminPosts />
                      </AdminLayout>
                    </ProtectedAdminRoute>
                  }
                />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </CartProvider>
      </UserProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
