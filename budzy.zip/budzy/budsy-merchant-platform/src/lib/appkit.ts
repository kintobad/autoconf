import { WagmiAdapter } from "@reown/appkit-adapter-wagmi";
import { createAppKit } from "@reown/appkit/react";
import { createStorage, cookieStorage } from "wagmi";
import { mainnet } from "@reown/appkit/networks";

export const projectId = import.meta.env.VITE_PROJECT_ID!;

export const wagmiAdapter = new WagmiAdapter({
  storage: createStorage({ storage: cookieStorage }),
  ssr: true,
  networks: [mainnet],
  projectId,
});

export const modal = createAppKit({
  adapters: [wagmiAdapter],
  projectId,
  networks: [mainnet],
  metadata: {
    name: "Budsy",
    description: "Cannabis E-Shop",
    url: "http://localhost:8080", 
    icons: [], 
  },
  features: {
    email: true, 
    socials: ["google", "discord"], 
  },
});
