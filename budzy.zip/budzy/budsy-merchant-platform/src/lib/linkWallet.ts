import axios from "axios";

export async function linkWallet(email: string, walletAddress: string) {
  const url = `${import.meta.env.VITE_API_URL}/api/user/link-wallet`;
  console.log("📡 Sending request to:", url);

  await axios.post(url, {
    email,
    walletAddress,
  });

  console.log("✅ Wallet linked successfully:", email, walletAddress);
}
