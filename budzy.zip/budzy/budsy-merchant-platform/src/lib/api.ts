import { supabase } from './supabaseClient';
import { Product } from '@/types';

export async function fetchProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select(`
      *,
      category:categories (name)
    `);

  if (error || !data) {
    console.error('Error fetching products:', error?.message);
    return [];
  }

  return data.map((p) => ({
    id: p.id,
    title: p.title,
    description: p.description,
    shortDescription: p.short_description,
    price: p.price || 0,
    category: typeof p.category === 'object' ? p.category?.name || 'unknown' : 'unknown',
    subcategory: p.subcategory,
    imageUrl: p.image_urls?.[0] || '',
    stock: p.stock ?? 0,
    thcPercentage: p.thc_percentage ?? 0,
    cbdPercentage: p.cbd_percentage ?? 0,
    indicaPercentage: p.indica_percentage ?? 0,
    sativaPercentage: p.sativa_percentage ?? 0,
    weight: p.weight ?? '',
    effects: Array.isArray(p.effects) ? p.effects : [],
    flavors: Array.isArray(p.flavors) ? p.flavors : [],
  })) as Product[];
}
