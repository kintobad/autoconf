import { Product } from '@/types';


const API_BASE = import.meta.env.VITE_API_URL;

export type ServerCartItem = {
  id: string;
  user_id: string;
  product_id: string;
  quantity: number;
  inserted_at: string;
  product: Product;
};

export const CartService = {
  async getCart(userId: string): Promise<ServerCartItem[]> {
    const res = await fetch(`${API_BASE}/api/cart/${userId}`);
    if (!res.ok) {
      const { error } = await res.json();
      throw new Error(error || 'Ошибка при получении корзины');
    }
    return await res.json();
  },

  async addItem(userId: string, productId: string, quantity: number): Promise<void> {
    const res = await fetch(`${API_BASE}/api/cart`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, product_id: productId, quantity }),
    });

    if (!res.ok) {
      const { error } = await res.json();
      throw new Error(error || 'Ошибка при добавлении в корзину');
    }
  },

  async removeItem(userId: string, productId: string): Promise<void> {
    const res = await fetch(`${API_BASE}/api/cart/${userId}/${productId}`, {
      method: 'DELETE',
    });

    if (!res.ok) {
      const { error } = await res.json();
      throw new Error(error || 'Ошибка при удалении из корзины');
    }
  },

  async clearCart(userId: string): Promise<void> {
    const res = await fetch(`${API_BASE}/api/cart/${userId}`, {
      method: 'DELETE',
    });

    if (!res.ok) {
      const { error } = await res.json();
      throw new Error(error || 'Ошибка при очистке корзины');
    }
  },
};
