
import { Post } from './models';

export const samplePosts: Post[] = [
  {
    id: '1',
    title: 'Understanding CBD vs THC: The Key Differences',
    slug: 'understanding-cbd-vs-thc',
    content: `
# Understanding CBD vs THC: The Key Differences

Cannabis contains numerous chemical compounds, with CBD (cannabidiol) and THC (tetrahydrocannabinol) being the most well-known and studied. While they come from the same plant, they have different properties and effects on the body.

## Chemical Structure

CBD and THC have the exact same molecular formula: 21 carbon atoms, 30 hydrogen atoms, and 2 oxygen atoms. However, a slight difference in how these atoms are arranged gives the two compounds different chemical properties, and they affect your body in different ways.

## Psychoactive Properties

The most notable difference between CBD and THC is their effect on your mental state:

- **THC** is psychoactive and produces the "high" associated with cannabis use.
- **CBD** is non-psychoactive and does not produce a high.

## Medical Benefits

Both compounds interact with your body's endocannabinoid system but activate different receptors:

**THC Benefits:**
- Pain relief
- Reduction of nausea and vomiting
- Appetite stimulation
- Muscle relaxation

**CBD Benefits:**
- Anti-inflammatory properties
- Anxiety reduction
- Anti-seizure properties
- Potential neuroprotective effects

## Legal Status

The legal status of these compounds varies significantly:

- **CBD** derived from hemp (containing less than 0.3% THC) is federally legal in many countries
- **THC** remains federally illegal in many jurisdictions, though state laws vary

## Side Effects

**THC** may cause:
- Increased heart rate
- Coordination problems
- Dry mouth
- Red eyes
- Memory loss
- Slower reaction times

**CBD** typically has fewer side effects, which may include:
- Fatigue
- Diarrhea
- Changes in appetite
- Potential interaction with other medications

## Conclusion

Understanding the differences between CBD and THC can help consumers make informed decisions about cannabis products for both recreational and medicinal purposes. Always consult with a healthcare provider before using cannabis products for medical conditions.
    `,
    excerpt: 'Explore the fundamental differences between CBD and THC, from their chemical structures to their effects on the body and legal status.',
    imageUrl: 'https://images.unsplash.com/photo-1536819114556-1e10f967fb61?q=80&w=2070&auto=format&fit=crop',
    category: 'Education',
    tags: ['CBD', 'THC', 'Cannabis', 'Medical'],
    author: 'Dr. Jane Smith',
    status: 'published',
    createdAt: '2023-11-15T10:30:00Z',
    updatedAt: '2023-11-15T10:30:00Z'
  },
  {
    id: '2',
    title: 'The Entourage Effect: How Cannabis Compounds Work Together',
    slug: 'the-entourage-effect',
    content: `
# The Entourage Effect: How Cannabis Compounds Work Together

The cannabis plant contains hundreds of different compounds, including cannabinoids, terpenes, and flavonoids. The "entourage effect" refers to the way these compounds work together to enhance the plant's effects.

## What Is the Entourage Effect?

The entourage effect is the theory that all the compounds in cannabis work together, and when taken together, they produce a better effect than when taken alone. This synergy between compounds means that the medicinal impact of the whole plant is greater than the sum of its parts.

## Key Players in the Entourage Effect

### Cannabinoids
Cannabis contains over 100 different cannabinoids, with THC and CBD being the most well-known. Others include:
- CBG (cannabigerol)
- CBC (cannabichromene)
- CBN (cannabinol)
- THCV (tetrahydrocannabivarin)

### Terpenes
Terpenes are aromatic compounds found in many plants, including cannabis. They give cannabis its distinctive smell and taste, but they also have therapeutic effects:
- Myrcene: Sedative, muscle relaxant
- Limonene: Elevated mood, stress relief
- Pinene: Improved alertness, anti-inflammatory
- Linalool: Anxiety and stress relief
- Beta-caryophyllene: Anti-inflammatory, pain relief

### Flavonoids
Cannabis contains about 20 different flavonoids, which contribute to the plant's color, taste, and smell. They also have antioxidant and anti-inflammatory properties.

## Evidence for the Entourage Effect

Research supporting the entourage effect includes:
- Studies showing that CBD can modulate the psychoactive effects of THC
- Research demonstrating that terpenes can influence how cannabinoids bind to receptors
- Clinical observations that whole-plant extracts often work better than isolated compounds

## Implications for Medical Use

The entourage effect has important implications for medical cannabis use:
- Full-spectrum extracts may provide better relief than isolated compounds
- Individual responses may vary based on the specific combination of compounds
- Tailoring cannabinoid and terpene profiles could lead to more effective treatments

## Conclusion

The entourage effect highlights the complex nature of cannabis and explains why whole-plant medicine may offer advantages over isolated compounds. As research continues, our understanding of these synergistic relationships will continue to evolve.
    `,
    excerpt: 'Discover how the hundreds of compounds in cannabis work together to create the "entourage effect" - a synergy that may enhance therapeutic benefits.',
    imageUrl: 'https://images.unsplash.com/photo-1603909223429-69bb7db9c41a?q=80&w=2069&auto=format&fit=crop',
    category: 'Science',
    tags: ['Entourage Effect', 'Terpenes', 'Cannabinoids', 'Research'],
    author: 'Prof. Mark Johnson',
    status: 'published',
    createdAt: '2023-12-05T14:45:00Z',
    updatedAt: '2023-12-07T09:15:00Z'
  },
  {
    id: '3',
    title: "Cannabis Cultivation: A Beginner's Guide",
    slug: 'cannabis-cultivation-beginners-guide',
    content: 'Draft content for cannabis cultivation guide',
    excerpt: 'Learn the basics of growing cannabis at home, from choosing the right strains to harvesting and curing your own product.',
    imageUrl: 'https://images.unsplash.com/photo-1604344929197-e3e34bf6ddbe?q=80&w=2070&auto=format&fit=crop',
    category: 'Cultivation',
    tags: ['Growing', 'Cultivation', 'Gardening', 'Beginner'],
    author: 'Sarah Green',
    status: 'draft',
    createdAt: '2024-01-10T11:20:00Z',
    updatedAt: '2024-01-15T16:40:00Z'
  }
];
