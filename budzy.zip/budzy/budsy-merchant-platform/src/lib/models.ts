
export interface Post {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  imageUrl: string;
  category: string;
  tags: string[];
  author: string;
  status: 'draft' | 'published';
  createdAt: string;
  updatedAt: string;
}
