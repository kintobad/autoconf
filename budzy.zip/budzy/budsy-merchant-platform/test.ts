import 'dotenv/config';
import { generateWalletAddress } from './src/utils/walletGen';

console.log("Address 0:", generateWalletAddress(0));
console.log("Address 1:", generateWalletAddress(1));
console.log("Address 2:", generateWalletAddress(2));
