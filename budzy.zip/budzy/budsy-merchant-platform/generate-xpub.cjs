const bip39 = require("bip39");
const { HDKey } = require("@scure/bip32");

const DERIVATION_PATH = "m/44'/60'/0'";

const mnemonic = bip39.generateMnemonic();
console.log("🔑 Mnemonic:", mnemonic);

const seed = bip39.mnemonicToSeedSync(mnemonic);
const root = HDKey.fromMasterSeed(seed);

const child = root.derive(DERIVATION_PATH);
const xpub = child.toJSON().xpub;

console.log("🧬 xpub:", xpub);
