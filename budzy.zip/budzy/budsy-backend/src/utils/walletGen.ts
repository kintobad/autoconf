import * as bitcoin from 'bitcoinjs-lib';
import * as ecc from 'tiny-secp256k1';
import { BIP32Factory } from 'bip32';
import bs58check from 'bs58check';
import { Buffer } from 'buffer';
import dotenv from 'dotenv';

dotenv.config();

const bip32 = BIP32Factory(ecc);

function convertZpubToXpub(zpub: string): string {
  const zpubPrefix = Buffer.from('04b24746', 'hex');
  const xpubPrefix = Buffer.from('0488b21e', 'hex');
  const data = bs58check.decode(zpub);
  return bs58check.encode(Buffer.concat([xpubPrefix, data.slice(4)]));
}

const rawXpub = process.env.XPUB_KEY!;
if (!rawXpub) throw new Error('XPUB_KEY not set in .env');

const network = bitcoin.networks.bitcoin;
const xpub = rawXpub.startsWith('zpub') ? convertZpubToXpub(rawXpub) : rawXpub;

export function generateWalletAddress(index: number): string {
  const node = bip32.fromBase58(xpub, network);
  const child = node.derive(index);

  const { address } = bitcoin.payments.p2wpkh({
    pubkey: Buffer.from(child.publicKey),
    network,
  });

  if (!address) throw new Error('Failed to generate address');
  return address;
}
