import nodemailer from "nodemailer";

// Настройка транспорта для отправки писем
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT),
  secure: true, // true — для порта 465, false — для 587
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Интерфейс для товаров
interface OrderItem {
  name: string;
  quantity: number;
  price: number;
}

// Главная функция отправки письма
export async function sendOrderEmail({
  to,
  orderNumber,
  btcAddress,
  items,
}: {
  to: string;
  orderNumber: string;
  btcAddress: string;
  items: OrderItem[];
}) {
  // Формируем HTML-список товаров
  const itemList = items
    .map(
      (item) =>
        `<li>${item.quantity} × <strong>${item.name}</strong> — £${(
          item.price * item.quantity
        ).toFixed(2)}</li>`
    )
    .join("");

  // Считаем общую сумму
  const totalAmount = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  // HTML-содержание письма
  const html = `
    <h2>✅ Order №${orderNumber} confirmed</h2>
    <p>To complete your order, please send payment to the following <strong>Bitcoin address</strong>:</p>
    <pre style="background: #f4f4f4; padding: 10px; font-size: 16px; font-weight: bold;">${btcAddress}</pre>
    <p>🛒 <strong>Order Summary:</strong></p>
    <ul>${itemList}</ul>
    <p><strong>Total:</strong> £${totalAmount.toFixed(2)}</p>
    <p>If you have any questions, feel free to reply to this email.</p>
    <p>Thank you for your purchase!</p>
  `;

  // Отправка письма
  await transporter.sendMail({
    from: `"Your Shop Name" <${process.env.SMTP_USER}>`,
    to,
    subject: `Your Order №${orderNumber} — Payment Instructions`,
    html,
  });
}
