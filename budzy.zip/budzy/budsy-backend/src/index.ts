import dotenv from 'dotenv';
dotenv.config(); 
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import ticketsRouter from './routes/tickets';
import walletRoutes from './routes/wallet';
import userRoutes from './routes/user';
import orderRoutes from './routes/order';
import productRoutes from './routes/product';
import cartRoutes from './routes/cart';
import trackRoutes from "./routes/track";
import adminHistoryRouter from "./routes/admin/history";
import addressesRouter from './routes/addresses';
import trackParcelRouter from "./routes/trackParcel";
import adminRouter from './routes/admin';


const app = express();
const PORT = process.env.PORT || 3001;

if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
  console.error(' SUPABASE_URL или SUPABASE_SERVICE_ROLE_KEY не заданы в .env');
  process.exit(1);
}


app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/api/user', userRoutes);
app.use('/api/order', orderRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use("/api/track", trackRoutes);
app.use("/admin/history", adminHistoryRouter);
app.use('/api/addresses', addressesRouter);
app.use('/api/tickets', ticketsRouter);
app.use("/api/track", trackParcelRouter);
app.use('/api/admin', adminRouter); 
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
