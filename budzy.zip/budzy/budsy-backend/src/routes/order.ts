import express from 'express';
import { supabase } from '../supabaseClient';
import { generateWalletAddress } from '../utils/walletGen';
import { sendOrderEmail } from '../utils/mailer';

const router = express.Router();

router.post('/place', async (req, res) => {
  const { userId, items, deliveryAddress, total, customer, email } = req.body;

  console.log("📦 Запрос на создание заказа:", req.body);

  // ✅ Проверка на обязательные поля
  if (
    !userId ||
    !Array.isArray(items) ||
    items.length === 0 ||
    !deliveryAddress ||
    !total ||
    !customer ||
    !email
  ) {
    return res.status(400).json({ message: 'Недостаточно данных для заказа' });
  }

  // 🆔 Уникальный номер заказа
  const orderNumber = `ORD-${Math.floor(Math.random() * 100000).toString().padStart(5, '0')}`;

  // ⚠️ Безопасный индекс генерации адреса (max 2^32 - 1)
  const orderIndex = Math.floor(Math.random() * 1_000_000); // Можно заменить на auto-increment или hash

  let paymentAddress: string;
  try {
    paymentAddress = generateWalletAddress(orderIndex);
  } catch (err) {
    console.error("❌ Ошибка генерации BTC-адреса:", err);
    return res.status(500).json({ message: 'Ошибка генерации адреса оплаты' });
  }

  const newOrder = {
    user_id: userId,
    order_number: orderNumber,
    date: new Date().toISOString(),
    status: 'processing',
    total,
    created_at: new Date().toISOString(),
    address: deliveryAddress,
    tracking: null,
    customer,
    btc_address: paymentAddress,
  };

  console.log("🧾 Вставляем заказ:", newOrder);

  const { error } = await supabase.from('orders').insert([newOrder]);

  if (error) {
    console.error("❌ Supabase insert error:", error);
    return res.status(500).json({ message: error.message || 'Ошибка при сохранении заказа' });
  }

  // ✉️ Отправка email с деталями заказа
  try {
    await sendOrderEmail({
      to: email,
      orderNumber,
      btcAddress: paymentAddress,
      items: items.map((item: any) => ({
        name: item.product?.name || 'Unknown',
        quantity: item.quantity,
        price: item.price,
      })),
    });
    console.log(`📧 Письмо отправлено на ${email}`);
  } catch (emailError) {
    console.warn("⚠️ Ошибка при отправке письма:", emailError);
  }

  console.log(`✅ Новый заказ ${orderNumber} успешно создан`);

  return res.status(200).json({
    message: 'Заказ успешно размещён',
    orderNumber,
    btc_address: paymentAddress,
  });
});

export default router;
