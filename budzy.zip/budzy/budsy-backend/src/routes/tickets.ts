import express from 'express';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();
const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

router.get('/:userId', async (req, res) => {
  const { userId } = req.params;

  const { data, error } = await supabase
    .from('tickets')
    .select('*')
    .eq('customer_id', userId)
    .order('updated_at', { ascending: false });

  if (error) {
    console.error(' Failed to fetch tickets:', error);
    return res.status(500).json({ message: 'Error loading tickets' });
  }

  return res.status(200).json(data);
});

router.post('/', async (req, res) => {
  const { subject, message, customer_id, department, priority } = req.body;

  if (!subject || !message || !customer_id || !department || !priority) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  const { data, error } = await supabase
    .from('tickets')
    .insert({
      id: crypto.randomUUID(),
      subject,
      customer_id,
      department,
      priority,
      status: 'open',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      last_response: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) {
    console.error(' Failed to create ticket:', error);
    return res.status(500).json({ message: 'Error creating ticket' });
  }

  return res.status(201).json(data);
});


router.put('/reply/:ticketId', async (req, res) => {
  const { ticketId } = req.params;
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ message: 'Message is required' });
  }

  const { data: currentTicket, error: fetchError } = await supabase
    .from('tickets')
    .select('messages')
    .eq('id', ticketId)
    .single();

  if (fetchError || !currentTicket) {
    console.error(' Failed to find ticket:', fetchError);
    return res.status(404).json({ message: 'Ticket not found' });
  }

  const updatedMessages = [
    ...(currentTicket.messages || []),
    {
      id: `msg-${currentTicket.messages?.length + 1 || 1}`,
      content: message,
      isAdmin: false,
      createdAt: new Date().toISOString(),
    },
  ];

  const { error: updateError } = await supabase
    .from('tickets')
    .update({
      messages: updatedMessages,
      updated_at: new Date().toISOString(),
      last_response: new Date().toISOString(),
    })
    .eq('id', ticketId);

  if (updateError) {
    console.error(' Failed to update ticket:', updateError);
    return res.status(500).json({ message: 'Failed to send reply' });
  }

  return res.status(200).json({ message: 'Reply sent' });
});

export default router;
