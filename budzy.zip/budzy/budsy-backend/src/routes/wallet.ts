import express from 'express';
import { Wallet, utils } from 'ethers';
import { HDNode } from 'ethers/lib/utils';

const router = express.Router();

router.get('/generate', (req, res) => {
  try {
    const randomWallet = Wallet.createRandom();
    const mnemonic = randomWallet.mnemonic.phrase;
    const root = HDNode.fromMnemonic(mnemonic);
    const child = root.derivePath(`m/44'/60'/0'/0/0`);

    res.json({
      mnemonic,
      address: child.address,
      path: child.path,
      publicKey: child.publicKey
    });
  } catch (error) {
    res.status(500).json({
      message: 'Wallet generation failed',
      error: String(error)
    });
  }
});

router.post('/derive', (req, res) => {
  const { mnemonic, index } = req.body;

  if (!mnemonic || index === undefined) {
    return res.status(400).json({ message: 'mnemonic and index are required' });
  }

  try {
    const trimmed = mnemonic.trim();

    if (!utils.isValidMnemonic(trimmed)) {
      return res.status(400).json({ message: 'Invalid mnemonic' });
    }

    const root = HDNode.fromMnemonic(trimmed);
    const child = root.derivePath(`m/44'/60'/0'/0/${index}`);

    res.json({
      address: child.address,
      path: child.path,
      publicKey: child.publicKey
    });
  } catch (error) {
    res.status(400).json({
      message: 'Mnemonic processing error',
      error: String(error)
    });
  }
});

export default router;
