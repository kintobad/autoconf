import express from 'express';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import { OAuth2Client } from 'google-auth-library';
import { v4 as uuidv4 } from 'uuid';
import { authenticator } from 'otplib';
import qrcode from 'qrcode';
import { generateWalletAddress } from '../utils/walletGen';


dotenv.config();
const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

router.post('/auth/google', async (req, res) => {
  const { idToken } = req.body;
  if (!idToken) return res.status(400).json({ message: 'Missing idToken' });

  try {
    const ticket = await googleClient.verifyIdToken({
      idToken,
      audience: process.env.GOOGLE_CLIENT_ID,
    });

    const payload = ticket.getPayload();
    if (!payload?.email) {
      return res.status(400).json({ message: 'Invalid token payload' });
    }

    const email = payload.email;
    const name = payload.name || '';
    const avatar = payload.picture || '';


    const { data: existingUser } = await supabase
      .from('users')
      .select('id')
      .eq('email', email)
      .single();

    if (existingUser) {
      return res.status(409).json({ message: 'User already exists' });
    }


    const { data: maxIndexData } = await supabase
      .from('users')
      .select('wallet_index')
      .order('wallet_index', { ascending: false })
      .limit(1)
      .single();

    const nextIndex = (maxIndexData?.wallet_index ?? -1) + 1;
    const wallet_address = generateWalletAddress(nextIndex);


    const { data: newUser, error } = await supabase
      .from('users')
      .insert({
        email,
        name,
        avatar,
        wallet_address,
        wallet_index: nextIndex,
        role: 'user',
      })
      .select()
      .single();

    if (error) {
      console.error(' Error creating user:', error);
      return res.status(500).json({ message: 'Failed to create user' });
    }

    return res.status(201).json(newUser);
  } catch (err) {
    console.error(' Google token verification failed:', err);
    return res.status(401).json({ message: 'Invalid Google token' });
  }
});


router.post('/link-wallet', async (req, res) => {
  const { email, walletAddress, name = '' } = req.body;
  if (!email || !walletAddress) {
    return res.status(400).json({ message: 'Email and walletAddress are required' });
  }

  const { data, error } = await supabase
    .from('users')
    .upsert(
      { email, wallet_address: walletAddress, name, role: 'user' },
      { onConflict: 'email' }
    )
    .select()
    .single();

  if (error) {
    console.error('❌ Error during upsert:', error);
    return res.status(500).json({ message: 'Failed to save user' });
  }

  return res.status(200).json(data);
});


router.get('/profile/:email', async (req, res) => {
  const { email } = req.params;

  const { data, error } = await supabase
    .from('users')
    .select('id, name, email, wallet_address, order_updates, email_marketing, two_fa_enabled')
    .eq('email', email)
    .single();

  if (error || !data) {
    return res.status(404).json({ message: 'User not found' });
  }

  return res.status(200).json(data);
});


router.put('/preferences', async (req, res) => {
  const { userId, orderUpdates, emailMarketing } = req.body;
  if (!userId) return res.status(400).json({ message: 'Missing userId' });

  const { error } = await supabase
    .from('users')
    .update({
      order_updates: orderUpdates,
      email_marketing: emailMarketing,
    })
    .eq('id', userId);

  if (error) {
    console.error(' Failed to update preferences:', error);
    return res.status(500).json({ message: 'Failed to update preferences' });
  }

  return res.status(200).json({ message: 'Preferences updated' });
});

router.delete('/', async (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ message: 'Missing userId' });

  const { error: deleteAuthError } = await supabase.auth.admin.deleteUser(userId);
  const { error: deleteDbError } = await supabase.from('users').delete().eq('id', userId);

  if (deleteAuthError || deleteDbError) {
    console.error('❌ Error deleting user:', deleteAuthError || deleteDbError);
    return res.status(500).json({ message: 'Failed to delete user' });
  }

  return res.status(200).json({ message: 'Account deleted successfully' });
});

router.put('/change-password', async (_req, res) => {
  return res.status(501).json({ message: 'Change password on frontend using Supabase client.' });
});

router.post('/2fa/setup', async (req, res) => {
  const { userId, email } = req.body;
  if (!userId || !email) return res.status(400).json({ message: 'Missing userId or email' });

  const secret = authenticator.generateSecret();
  const otpauth = authenticator.keyuri(email, "Budsy", secret);
  const qr = await qrcode.toDataURL(otpauth);

  const { error } = await supabase
    .from('users')
    .update({ two_fa_secret: secret })
    .eq('id', userId);

  if (error) {
    console.error(" Error saving 2FA secret:", error.message);
    return res.status(500).json({ message: "Could not save 2FA secret" });
  }

  return res.status(200).json({ secret, qr });
});


router.post("/wallet-auth", async (req, res) => {
  const { walletAddress } = req.body;

  if (!walletAddress) {
    return res.status(400).json({ message: "walletAddress is required" });
  }

  try {

    const { data: existingUser, error: fetchError } = await supabase
      .from("users")
      .select("*")
      .eq("wallet_address", walletAddress)
      .maybeSingle();

    if (fetchError) throw fetchError;

    if (existingUser) {
      return res.status(200).json(existingUser);
    }


    const { data: newUser, error: insertError } = await supabase
      .from("users")
      .insert({
        wallet_address: walletAddress,
        name: "",
        role: "user",
      })
      .select()
      .single();

    if (insertError) throw insertError;

    return res.status(201).json(newUser);
  } catch (err: any) {
    if (err.code === "23505") {
      return res.status(409).json({ message: "Wallet already exists" });
    }

    console.error(" Wallet-auth error:", err);
    return res.status(500).json({ message: "Internal error during wallet auth" });
  }
});

router.get('/wallet-profile/:wallet', async (req, res) => {
  const { wallet } = req.params;

  const { data, error } = await supabase
    .from('users')
    .select('id, name, wallet_address, role, created_at')
    .eq('wallet_address', wallet)
    .single();

  if (error || !data) return res.status(404).json({ message: 'User not found by wallet' });

  return res.status(200).json(data);
});


router.post('/2fa/verify', async (req, res) => {
  const { userId, token } = req.body;
  if (!userId || !token) return res.status(400).json({ message: 'Missing userId or token' });

  const { data: user, error } = await supabase
    .from('users')
    .select('two_fa_secret')
    .eq('id', userId)
    .single();

  if (error || !user?.two_fa_secret) {
    return res.status(404).json({ message: '2FA secret not found' });
  }

  const isValid = authenticator.check(token, user.two_fa_secret);
  if (!isValid) return res.status(401).json({ message: 'Invalid token' });

  await supabase
    .from('users')
    .update({ two_fa_enabled: true })
    .eq('id', userId);

  return res.status(200).json({ message: '2FA enabled successfully' });
});


router.get('/wallet/address/:userId', async (req, res) => {
  const { userId } = req.params;

  const { data: user, error } = await supabase
    .from('users')
    .select('wallet_index')
    .eq('id', userId)
    .single();

  if (error || user?.wallet_index === undefined) {
    return res.status(404).json({ message: 'User not found or wallet_index missing' });
  }

  const wallet_address = generateWalletAddress(user.wallet_index);
  return res.status(200).json({ wallet_address });
});


router.post("/register", async (req, res) => {
  const { name, email, password, wallet_address } = req.body;

  if (!name || !email || !password || !wallet_address) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  try {
    const { data: existingByEmail } = await supabase
      .from("users")
      .select("id")
      .eq("email", email)
      .maybeSingle();
    if (existingByEmail) {
      return res.status(409).json({ message: "User with this email already exists" });
    }

    const { data: existingByWallet } = await supabase
      .from("users")
      .select("id")
      .eq("wallet_address", wallet_address)
      .maybeSingle();
    if (existingByWallet) {
      return res.status(409).json({ message: "Wallet address already in use" });
    }


    const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });
    if (authError) throw authError;


    const { data: maxIndexData } = await supabase
      .from("users")
      .select("wallet_index")
      .order("wallet_index", { ascending: false })
      .limit(1)
      .single();

    const nextIndex = (maxIndexData?.wallet_index ?? -1) + 1;


    const { data: insertedUser, error: insertError } = await supabase
      .from("users")
      .insert({
        id: authUser.user.id,
        email,
        name,
        wallet_address,
        wallet_index: nextIndex,
        role: "user",
      })
      .select()
      .single();

    if (insertError) throw insertError;

    return res.status(201).json(insertedUser);
  } catch (err: any) {
    console.error(" Registration error:", err);
    return res.status(500).json({ message: err.message || "Internal error" });
  }
});


router.put('/profile/:email', async (req, res) => {
  const { email } = req.params;
  const { name } = req.body;

  if (!email || !name) {
    return res.status(400).json({ message: 'Missing email or name' });
  }

  const { data, error } = await supabase
    .from('users')
    .update({ name })
    .eq('email', email)
    .select()
    .single();

  if (error || !data) {
    console.error(" Error updating profile:", error);
    return res.status(500).json({ message: 'Failed to update user profile' });
  }

  return res.status(200).json(data);
});

export default router;
