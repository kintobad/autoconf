import { Router } from "express";
import { supabase } from "../../supabaseClient"; 

const router = Router();

router.get("/", async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("history_log")
      .select(`
        id,
        action,
        action_type,
        entity_type,
        entity_id,
        entity_name,
        details,
        timestamp,
        users (
          id,
          name,
          avatar,
          role
        )
      `)
      .order("timestamp", { ascending: false });

    if (error) {
      console.error(" Supabase error:", error.message);
      return res.status(500).json({ error: error.message });
    }

    const mapped = data.map((entry: any) => ({
      id: entry.id,
      action: entry.action,
      actionType: entry.action_type,
      entityType: entry.entity_type,
      entityId: entry.entity_id,
      entityName: entry.entity_name,
      timestamp: entry.timestamp,
      details: entry.details,
      performedBy: {
        id: entry.users?.id || "system",
        name: entry.users?.name || "System",
        avatar: entry.users?.avatar || "",
        role: entry.users?.role || "system",
      },
    }));

    res.json(mapped);
  } catch (e) {
    console.error(" Server crash:", e);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
