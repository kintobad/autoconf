import { Router } from "express";
import { supabase } from "../../../supabaseClient";

const router = Router();

// GET /api/admin/analytics/overview
router.get("/overview", async (_req, res) => {
    const [{ data: orders }, { data: users }] = await Promise.all([
        supabase.from("orders").select("total"),
        supabase.from("users").select("id"),
    ]);

    const totalRevenue = orders?.reduce((acc, order) => acc + (order.total || 0), 0) || 0;
    const totalOrders = orders?.length || 0;
    const totalCustomers = new Set(users?.map(u => u.id)).size;

    res.json({
        totalRevenue,
        totalOrders,
        totalCustomers,
        conversionRate: users?.length ? (totalOrders / users.length) * 100 : 0,
    });
});

// GET /api/admin/analytics/monthly-sales
router.get("/monthly-sales", async (_req, res) => {
    const { data, error } = await supabase.rpc("monthly_sales");
    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
});

// GET /api/admin/analytics/category-sales
router.get("/category-sales", async (_req, res) => {
    const { data, error } = await supabase.rpc("sales_by_category");
    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
});

export default router;
