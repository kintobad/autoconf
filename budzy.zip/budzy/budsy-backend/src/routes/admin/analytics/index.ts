import { Router } from "express";
import { supabase } from "../../../supabaseClient";
import dailyTrafficRouter from "./daily-traffic";

const router = Router();

router.get("/overview", async (_req, res) => {
    try {
        const [{ data: orders, error: ordersError }, { data: users, error: usersError }] = await Promise.all([
            supabase.from("orders").select("total"),
            supabase.from("users").select("id"),
        ]);

        if (ordersError || usersError) {
            return res.status(500).json({ error: ordersError?.message || usersError?.message });
        }

        const totalRevenue = orders?.reduce((acc, order) => acc + (order.total || 0), 0) || 0;
        const totalOrders = orders?.length || 0;
        const totalCustomers = new Set(users?.map((u) => u.id)).size;
        const conversionRate = users?.length ? (totalOrders / users.length) * 100 : 0;

        res.json({
            totalRevenue,
            totalOrders,
            totalCustomers,
            conversionRate,
        });
    } catch (err: any) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});


router.get("/monthly-sales", async (_req, res) => {
    try {
        const { data, error } = await supabase.rpc("monthly_sales");
        if (error) return res.status(500).json({ error: error.message });
        res.json(data);
    } catch (err: any) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});


router.get("/category-sales", async (_req, res) => {
    try {
        const { data, error } = await supabase.rpc("sales_by_category");
        if (error) return res.status(500).json({ error: error.message });
        res.json(data);
    } catch (err: any) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});


router.get("/product-category-sales", async (_req, res) => {
    try {
        const { data, error } = await supabase.rpc("product_category_sales");
        if (error) return res.status(500).json({ error: error.message });
        res.json(data);
    } catch (err: any) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});


router.use("/daily-traffic", dailyTrafficRouter);

export default router;
