import { Router } from "express";
import { supabase } from "../../../supabaseClient";

const router = Router();

// Получение продаж по месяцам
router.get("/", async (req, res) => {
  const { data, error } = await supabase.rpc("get_monthly_sales"); // Функция ниже

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json(data);
});

export default router;
