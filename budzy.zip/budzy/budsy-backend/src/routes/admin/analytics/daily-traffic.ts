import { Router } from "express";
import { supabase } from "../../../supabaseClient";
import dayjs from "dayjs";

const router = Router();

const getRange = (range: string) => {
  const today = dayjs();
  switch (range) {
    case "today":
      return [today.startOf("day").toISOString(), today.endOf("day").toISOString()];
    case "last7days":
      return [today.subtract(6, "day").startOf("day").toISOString(), today.endOf("day").toISOString()];
    case "last30days":
      return [today.subtract(29, "day").startOf("day").toISOString(), today.endOf("day").toISOString()];
    case "thisMonth":
      return [today.startOf("month").toISOString(), today.endOf("day").toISOString()];
    case "lastMonth":
      const start = today.subtract(1, "month").startOf("month");
      const end = start.endOf("month");
      return [start.toISOString(), end.toISOString()];
    case "thisYear":
      return [today.startOf("year").toISOString(), today.endOf("day").toISOString()];
    default:
      return [today.subtract(29, "day").startOf("day").toISOString(), today.endOf("day").toISOString()];
  }
};

router.get("/", async (req, res) => {
  const range = req.query.range as string;
  const [from, to] = getRange(range || "last30days");

  const { data, error } = await supabase
    .from("traffic_log")
    .select("created_at")
    .gte("created_at", from)
    .lte("created_at", to);

  if (error) return res.status(500).json({ error: error.message });

  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const counts = Array(7).fill(0);

  data.forEach((log) => {
    const day = new Date(log.created_at).getDay();
    counts[day]++;
  });

  const result = days.map((name, index) => ({
    day: name,
    visitors: counts[index],
  }));

  res.json(result);
});

export default router;
