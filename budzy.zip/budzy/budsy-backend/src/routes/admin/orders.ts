import express from 'express';
import { supabase } from '../../supabaseClient';

const router = express.Router();


router.get('/', async (_req, res) => {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) return res.status(500).json({ error: error.message });

  res.json(data);
});


router.get('/recent', async (_req, res) => {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(5);

  if (error) return res.status(500).json({ error: error.message });

  res.json(data);
});


router.get('/:id', async (req, res) => {
  const { id } = req.params;

  const { data: order, error: orderError } = await supabase
    .from('orders')
    .select('*')
    .eq('id', id)
    .single();

  if (orderError || !order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const { data: items, error: itemsError } = await supabase
    .from('order_items')
    .select(`
      *,
      product:products (id, title, price, imageUrl, category)
    `)
    .eq('order_id', id);

  if (itemsError) {
    return res.status(500).json({ error: itemsError.message });
  }

  res.json({ ...order, items });
});


router.delete('/:id', async (req, res) => {
  const { id } = req.params;

  const { error: itemDeleteError } = await supabase
    .from('order_items')
    .delete()
    .eq('order_id', id);

  if (itemDeleteError) {
    return res.status(500).json({ error: itemDeleteError.message });
  }

  const { error: orderDeleteError } = await supabase
    .from('orders')
    .delete()
    .eq('id', id);

  if (orderDeleteError) {
    return res.status(500).json({ error: orderDeleteError.message });
  }

  res.json({ message: 'Order deleted successfully' });
});

export default router;
