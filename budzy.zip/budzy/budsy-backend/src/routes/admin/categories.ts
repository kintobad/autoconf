
import { Router } from "express";
import { supabase } from "../../supabaseClient";

const router = Router();

router.get("/", async (req, res) => {
  const { data, error } = await supabase.from("categories").select("*");
  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json(data);
});

router.post("/", async (req, res) => {
  const { name, slug, description, status } = req.body;

  if (!name || !slug) {
    return res.status(400).json({ error: "Name and slug are required" });
  }

  const { data, error } = await supabase.from("categories").insert([
    {
      name,
      slug,
      description: description || "",
      productCount: 0,
      status: status || "active",
    },
  ]);

  if (error) return res.status(400).json({ error: error.message });
  return res.status(200).json(data);
});

export default router;
