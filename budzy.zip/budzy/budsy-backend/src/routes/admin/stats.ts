import { Router } from 'express';
import { supabase } from '../../supabaseClient';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.split(' ')[1]; // "Bearer <token>"

    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }


    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return res.status(401).json({ error: 'You are not logged in' });
    }

    const [ordersRes, usersRes] = await Promise.all([
      supabase.from('orders').select('*'),
      supabase.from('users').select('*'),
    ]);

    if (ordersRes.error || usersRes.error) {
      return res.status(500).json({
        error: ordersRes.error?.message || usersRes.error?.message,
      });
    }

    const orders = ordersRes.data ?? [];
    const users = usersRes.data ?? [];

    const totalSales = orders.reduce((sum, order) => sum + (order.total ?? 0), 0);
    const orderCount = orders.length;
    const userCount = users.length;
    const completedCount = orders.filter((o) => o.status === 'completed').length;
    const completionRate =
      orderCount > 0 ? Math.round((completedCount / orderCount) * 100) : 0;

    return res.status(200).json({
      totalSales,
      orderCount,
      userCount,
      completionRate,
    });
  } catch (err: any) {
    console.error('[ADMIN][STATS] Unexpected error:', err.message);
    return res.status(500).json({ error: 'Unexpected server error' });
  }
});

export default router;
