import express from "express";
import { supabase } from "../../supabaseClient";

const router = express.Router();

router.get("/", async (_req, res) => {
  const { data, error } = await supabase
    .from("tickets")
    .select(`
      *,
      users (
        id,
        name,
        email,
        avatar
      )
    `)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("[GET] /tickets error:", error.message);
    return res.status(500).json({ error: error.message });
  }


  const formatted = data.map((ticket: any) => ({
    id: ticket.id,
    subject: ticket.subject,
    customer: {
      id: ticket.users?.id,
      name: ticket.users?.name,
      email: ticket.users?.email,
      avatar: ticket.users?.avatar,
    },
    department: ticket.department,
    priority: ticket.priority,
    status: ticket.status,
    createdAt: ticket.created_at,
    updatedAt: ticket.updated_at,
    lastResponse: ticket.last_response,
  }));

  res.status(200).json(formatted);
});


router.patch("/:id", async (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  const { data, error } = await supabase
    .from("tickets")
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select()
    .single();

  if (error) {
    console.error(`[PATCH] /tickets/${id} error:`, error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json(data);
});

router.delete("/:id", async (req, res) => {
  const { id } = req.params;

  const { error } = await supabase.from("tickets").delete().eq("id", id);

  if (error) {
    console.error(`[DELETE] /tickets/${id} error:`, error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json({ message: "Ticket deleted successfully" });
});

export default router;
