import { Router } from "express";
import { supabase } from "../../supabaseClient";

const router = Router();

router.get("/", async (_req, res) => {
    const { data, error } = await supabase
        .from("posts")
        .select("*")
        .order("updatedAt", { ascending: false });

    if (error) return res.status(500).json({ error: error.message });
    res.status(200).json(data);
});


router.post("/", async (req, res) => {
    const post = req.body;


    const prepared = {
        ...post,
        imageurl: post.imageUrl ?? null,
        tags: post.tags ?? [],
    };
    delete prepared.imageUrl;

    const { data, error } = await supabase
        .from("posts")
        .insert([prepared])
        .select()
        .single();

    if (error) return res.status(400).json({ error: error.message });
    res.status(200).json(data);
});


router.put("/:id", async (req, res) => {
    const { id } = req.params;
    const post = req.body;
    delete post.id;
    delete post.createdAt;
    delete post.updatedAt;

    const updated = {
        ...post,
        imageurl: post.imageUrl ?? null,
        tags: post.tags ?? [],
    };
    delete updated.imageUrl;

    console.log("🔧 Cleaned payload:", updated);

    const { data, error } = await supabase
        .from("posts")
        .update(updated)
        .eq("id", id)
        .select()
        .single();

    if (error) return res.status(400).json({ error: error.message });

    res.status(200).json(data);
});

router.delete("/:id", async (req, res) => {
    const { id } = req.params;

    const { error } = await supabase
        .from("posts")
        .delete()
        .eq("id", id);

    if (error) return res.status(400).json({ error: error.message });
    res.status(200).json({ success: true });
});

export default router;