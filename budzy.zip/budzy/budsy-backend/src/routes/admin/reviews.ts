import express from 'express';
import { supabase } from '../../supabaseClient';

const router = express.Router();

router.get('/', async (_req, res) => {
  const { data, error } = await supabase
    .from('reviews')
    .select(`
      id,
      product_id,
      user_id,
      rating,
      comment,
      created_at,
      status,
      users ( id, name, avatar ),
      products ( id, title, image_urls )
    `)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('[ADMIN][GET] Ошибка получения отзывов:', error.message);
    return res.status(500).json({ error: error.message });
  }

  const formatted = data.map((review: any) => ({
    id: review.id,
    productId: review.product_id,
    productName: review.products?.title,
    productImage: review.products?.image_urls?.[0] || "/placeholder.svg",
    customer: {
      id: review.users?.id,
      name: review.users?.name,
      avatar: review.users?.avatar || "",
    },
    rating: review.rating,
    comment: review.comment,
    date: review.created_at,
    status: review.status,
  }));

  res.status(200).json(formatted);
});


router.patch('/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!['published', 'pending', 'rejected'].includes(status)) {
    return res.status(400).json({ error: 'Недопустимый статус' });
  }

  const { error } = await supabase
    .from('reviews')
    .update({ status })
    .eq('id', id);

  if (error) {
    console.error(`[ADMIN][PATCH] Ошибка обновления статуса для ${id}:`, error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json({ message: 'Статус успешно обновлён' });
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;

  const { error } = await supabase
    .from('reviews')
    .delete()
    .eq('id', id);

  if (error) {
    console.error(`[ADMIN][DELETE] Ошибка удаления отзыва ${id}:`, error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json({ message: 'Отзыв успешно удалён' });
});

export default router;
