import express from 'express';
import usersRoutes from './users';
import productsRoutes from './products';
import statsRouter from './stats';
import ordersRouter from './orders';
import categoriesRoutes from './categories';
import postsRoutes from './posts';
import analyticsRouter from './analytics/index'; 
import dailyTrafficRouter from './analytics/daily-traffic';
import reviewsRouter from './reviews';
import ticketsRoute from "./tickets";
import historyRoutes from "./history";



const adminRouter = express.Router();
adminRouter.use('/analytics', analyticsRouter); 
adminRouter.use('/users', usersRoutes);
adminRouter.use('/products', productsRoutes);
adminRouter.use('/stats', statsRouter);
adminRouter.use('/orders', ordersRouter);
adminRouter.use('/categories', categoriesRoutes);
adminRouter.use('/posts', postsRoutes);
adminRouter.use('/analytics/daily-traffic', dailyTrafficRouter);
adminRouter.use('/reviews', reviewsRouter);
adminRouter.use("/tickets", ticketsRoute);
adminRouter.use("/history", historyRoutes);


adminRouter.get('/', (_req, res) => res.json({ message: 'Admin API running' }));

export default adminRouter; 
