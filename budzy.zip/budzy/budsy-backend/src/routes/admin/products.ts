import express from 'express';
import { supabase } from '../../supabaseClient';
import multer from 'multer';

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router.get('/', async (_req, res) => {
  const { data, error } = await supabase.from('products').select('*');

  if (error) {
    console.error('[ADMIN][GET] Error fetching products:', error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json(data);
});

router.post('/', async (req, res) => {
  const {
    title,
    short_description,
    description,
    category_id,
    subcategory,
    price,
    stock,
    thc_percentage,
    cbd_percentage,
    indica_percentage,
    sativa_percentage,
    weight,
    effects,
    flavors,
    image_urls
  } = req.body;

  if (!title || !price || !category_id) {
    return res.status(400).json({
      error: 'Missing required fields: title, price, or category_id',
    });
  }

  const { data, error } = await supabase.from('products').insert([
    {
      title,
      short_description,
      description,
      category_id,
      subcategory,
      price,
      stock,
      thc_percentage,
      cbd_percentage,
      indica_percentage,
      sativa_percentage,
      weight,
      effects,
      flavors,
      image_urls,
    },
  ]).select().single();

  if (error) {
    console.error('[ADMIN][POST] Error adding product:', error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(201).json(data);
});

router.patch('/:id', async (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  const { data, error } = await supabase
    .from('products')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error(`[ADMIN][PATCH] Failed to update product ${id}:`, error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json(data);
});


router.delete('/:id', async (req, res) => {
  const { id } = req.params;

  const { error } = await supabase.from('products').delete().eq('id', id);

  if (error) {
    console.error(`[ADMIN][DELETE] Failed to delete product ${id}:`, error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json({ message: 'Product deleted successfully' });
});


router.post('/upload', upload.single('file'), async (req, res) => {
  const file = req.file;

  if (!file) {
    return res.status(400).json({ error: 'Файл не передан' });
  }

  const timestamp = Date.now();
  const filePath = `products/${timestamp}_${file.originalname}`;

  const { error } = await supabase.storage
    .from('product-images')
    .upload(filePath, file.buffer, {
      contentType: file.mimetype,
      upsert: true,
    });

  if (error) {
    console.error('[UPLOAD] Ошибка загрузки изображения:', error.message);
    return res.status(500).json({ error: error.message });
  }

  const { publicUrl } = supabase
    .storage
    .from('product-images')
    .getPublicUrl(filePath).data;

  return res.status(200).json({ url: publicUrl });
});

export default router;
