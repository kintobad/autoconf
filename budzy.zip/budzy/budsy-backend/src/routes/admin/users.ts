import express from 'express';
import { supabase } from '../../supabaseClient';

const router = express.Router();

// [GET] /api/admin/users — все пользователи
router.get('/', async (req, res) => {
  const { data, error } = await supabase.from('users').select('*');
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// [DELETE] /api/admin/users/:id — удалить пользователя
router.delete('/:id', async (req, res) => {
  const { id } = req.params;

  const { error } = await supabase.from('users').delete().eq('id', id);

  if (error) {
    console.error(`[ADMIN][DELETE] Failed to delete user ${id}:`, error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json({ message: 'User deleted successfully' });
});


// [PATCH] /api/admin/users/:id/role — обновить роль
router.patch('/:id', async (req, res) => {
  const { id } = req.params;
  const { role, status } = req.body;

  const { error } = await supabase
    .from('users')
    .update({ role, status })
    .eq('id', id);

  if (error) {
    console.error(`[ADMIN][PATCH] Failed to update user ${id}:`, error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json({ message: 'User updated successfully' });
});

router.get('/recent', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.split(' ')[1];

    if (!token) return res.status(401).json({ error: 'No token provided' });

    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) return res.status(401).json({ error: 'Not authorized' });

    const { data, error } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);

    if (error) return res.status(500).json({ error: error.message });

    res.json(data);
  } catch (err: any) {
    console.error('Recent users error:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});


export default router;
