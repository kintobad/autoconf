import express from "express";
const router = express.Router();

const mockStatus: Record<string, string> = {
  RM123456789GB: "Delivered",
  RM987654321GB: "In Transit",
  RM000000000GB: "Pending",
};

router.get("/royalmail/:code", async (req, res) => {
  const { code } = req.params;
  const status = mockStatus[code.toUpperCase()] || "Tracking number not found";
  res.json({ code, status });
});

export default router;
