import express from 'express';
import { supabase } from '../supabaseClient';

const router = express.Router();

router.get('/', async (_req, res) => {
  const { data, error } = await supabase.from('products').select('*');

  if (error) {
    console.error('Error fetching products:', error.message);
    return res.status(500).json({ error: error.message });
  }

  return res.status(200).json(data);
});


router.post('/', async (req, res) => {
  const {
    title,
    short_description,
    description,
    category_id,
    subcategory,
    price,
    stock,
    thc_percentage,
    cbd_percentage,
    indica_percentage,
    sativa_percentage,
    weight,
    effects,
    flavors,
    image_urls
  } = req.body;

  if (!title || !price || !category_id) {
    return res.status(400).json({ error: 'Missing required fields: title, price, or category_id' });
  }

  const { error } = await supabase.from('products').insert([
    {
      title,
      short_description,
      description,
      category_id,
      subcategory,
      price,
      stock,
      thc_percentage,
      cbd_percentage,
      indica_percentage,
      sativa_percentage,
      weight,
      effects,
      flavors,
      image_urls
    }
  ]);

  if (error) {
    console.error('Error adding product:', error.message);
    return res.status(500).json({ error: error.message });
  }

  return res.status(201).json({ message: 'Product created' });
});

export default router;
