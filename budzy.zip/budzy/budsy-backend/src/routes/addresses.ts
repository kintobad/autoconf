import express from 'express';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();
const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);
async function getUserId(email: string) {
  const { data, error } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single();

  if (error || !data) throw new Error("User not found");
  return data.id;
}

router.get('/:email', async (req, res) => {
  try {
    const userId = await getUserId(req.params.email);

    const { data, error } = await supabase
      .from('addresses')
      .select('*')
      .eq('user_id', userId);

    if (error) throw error;
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: 'Failed to load addresses' });
  }
});

router.post('/:email', async (req, res) => {
  const { name, street, city, state, zipCode } = req.body;

  try {
    const userId = await getUserId(req.params.email);

    const { data, error } = await supabase
      .from('addresses')
      .insert({
        user_id: userId,
        name,
        street,
        city,
        state,
        zip_code: zipCode,
        is_default: false
      })
      .select()
      .single();

    if (error) throw error;
    res.status(201).json(data);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create address' });
  }
});


router.put('/:id', async (req, res) => {
  const { name, street, city, state, zipCode } = req.body;

  const { data, error } = await supabase
    .from('addresses')
    .update({
      name,
      street,
      city,
      state,
      zip_code: zipCode
    })
    .eq('id', req.params.id)
    .select()
    .single();

  if (error) {
    return res.status(500).json({ message: 'Failed to update address' });
  }

  res.json(data);
});


router.delete('/:id', async (req, res) => {
  const { error } = await supabase
    .from('addresses')
    .delete()
    .eq('id', req.params.id);

  if (error) {
    return res.status(500).json({ message: 'Failed to delete address' });
  }

  res.json({ success: true });
});


router.patch('/:id/default', async (req, res) => {
  const { email } = req.body;

  try {
    const userId = await getUserId(email);


    await supabase
      .from('addresses')
      .update({ is_default: false })
      .eq('user_id', userId);

    await supabase
      .from('addresses')
      .update({ is_default: true })
      .eq('id', req.params.id);

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ message: 'Failed to set default address' });
  }
});

export default router;
