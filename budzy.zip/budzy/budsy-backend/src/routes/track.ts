import { Router } from "express";
import { supabase } from "../supabaseClient";

const router = Router();

router.post("/", async (req, res) => {
  try {
    const ip =
      req.headers["x-forwarded-for"]?.toString().split(",")[0] ||
      req.socket.remoteAddress ||
      "unknown";

    const userAgent = req.headers["user-agent"] || "unknown";
    const path = req.body?.path;

    if (!path) {
      return res.status(400).json({ error: "Missing path in request body" });
    }

    const { error } = await supabase.from("traffic_log").insert([
      {
        ip,
        path,
        user_agent: userAgent,
      },
    ]);

    if (error) {
      console.error("Supabase insert error:", error.message);
      return res.status(500).json({ error: error.message });
    }

    res.status(200).json({ message: "Tracked" });
  } catch (err: any) {
    console.error("Tracking failed:", err.message);
    res.status(500).json({ error: "Tracking failed" });
  }
});

export default router;
