
import express from 'express';
import { supabase } from '../supabaseClient';

const router = express.Router();


router.get('/:user_id', async (req, res) => {
  const { user_id } = req.params;

  const { data, error } = await supabase
    .from('carts')
        .select(`
        id,
        user_id,
        product_id,
        quantity,
        inserted_at,
        product:products(*)
        `)

    .eq('user_id', user_id);

  if (error) {
    console.error('Ошибка при получении корзины:', error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json(data);
});


router.post('/', async (req, res) => {
  const { user_id, product_id, quantity } = req.body;

  if (!user_id || !product_id || typeof quantity !== 'number') {
    return res.status(400).json({ error: 'user_id, product_id и quantity обязательны' });
  }

  const { data, error } = await supabase
    .from('carts')
    .upsert([{ user_id, product_id, quantity }], {
      onConflict: ['user_id', 'product_id'],
    });

  if (error) {
    console.error('Ошибка при добавлении в корзину:', error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json(data);
});


router.delete('/:user_id/:product_id', async (req, res) => {
  const { user_id, product_id } = req.params;

  const { error } = await supabase
    .from('carts')
    .delete()
    .eq('user_id', user_id)
    .eq('product_id', product_id);

  if (error) {
    console.error('Ошибка при удалении товара из корзины:', error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json({ success: true });
});


router.delete('/:user_id', async (req, res) => {
  const { user_id } = req.params;

  const { error } = await supabase
    .from('carts')
    .delete()
    .eq('user_id', user_id);

  if (error) {
    console.error('Ошибка при очистке корзины:', error.message);
    return res.status(500).json({ error: error.message });
  }

  res.status(200).json({ success: true });
});

router.get('/total/:user_id', async (req, res) => {
  const { user_id } = req.params;

  const { data, error } = await supabase
    .from('carts')
    .select(`quantity, product:products(price)`)
    .eq('user_id', user_id);

  if (error) {
    console.error('Ошибка при расчете суммы:', error.message);
    return res.status(500).json({ error: error.message });
  }

  const total = data.reduce((sum, item) => {
    return sum + (item.quantity * item.product.price);
  }, 0);

  res.status(200).json({ total });
});




export default router;
