import axios from 'axios';
import { sampleProducts } from './sampleProducts';

const categoryMap: Record<string, number> = {
  Flowers: 1,
  Extracts: 6,
  Edibles: 3,
  Medical: 4,
  Accessories: 5,
};


async function seedProducts() {
  for (const product of sampleProducts) {
    const category_id = categoryMap[product.category];

    if (!category_id) {
      console.warn(`⚠️  Категория "${product.category}" не найдена в categoryMap, пропускаю "${product.title}"`);
      continue;
    }

    try {
      const response = await axios.post('http://localhost:3001/api/products', {
        title: product.title,
        short_description: product.shortDescription,
        description: product.description,
        category_id,
        subcategory: product.subcategory,
        price: product.price,
        stock: product.stock,
        thc_percentage: product.thcPercentage,
        cbd_percentage: product.cbdPercentage,
        indica_percentage: product.indicaPercentage,
        sativa_percentage: product.sativaPercentage,
        weight: product.weight,
        effects: product.effects,
        flavors: product.flavors,
        image_urls: [product.imageUrl],
      });

      console.log(`✅ Inserted: ${product.title}`);
    } catch (error: any) {
      console.error(`Error inserting ${product.title}:`, error.response?.data || error.message);
    }
  }
}

seedProducts();
