export type Product = {
  id: string;
  title: string;
  price: number;
  description: string;
  shortDescription: string;
  category: string;
  subcategory: string;
  imageUrl: string;
  stock: number;
  thcPercentage?: number;
  cbdPercentage?: number;
  indicaPercentage?: number;
  sativaPercentage?: number;
  weight?: number;
  effects?: string[];
  flavors?: string[];
};

export type UserRole = 'admin' | 'customer' | 'manager';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: UserRole;
  orderCount: number;
  totalSpent: number;
  joinDate: string;
  lastActive: string;
  status: 'active' | 'inactive' | 'suspended';
}

export type OrderStatus = 'processing' | 'completed' | 'cancelled' | 'pending';

export type Order = {
  id: string;
  date: string;
  customer: string;
  status: OrderStatus;
  total: number;
  items: Array<{
    productId: string;
    quantity: number;
    price: number;
  }>;
};

export type Category = {
  id: string;
  name: string;
};

export const sampleProducts: Product[] = [
  {
    id: '1',
    title: 'OG Kush',
    price: 12.99,
    description: 'OG Kush is a legendary strain with a unique terpene profile offering a complex aroma with notes of fuel, skunk, and spice. The cerebral boost is complemented by a heavy, relaxing body sensation making it perfect for stress relief without sedation. Cultivated with care to maintain its authentic genetic profile, this batch has been slow-cured to preserve its rich cannabinoid and terpene content.',
    shortDescription: 'A legendary strain with a relaxing high and distinctive aroma',
    category: 'Flowers',
    subcategory: 'Hybrid',
    imageUrl: 'https://images.unsplash.com/photo-1603909223429-69bb7101f420?q=80&w=1000',
    stock: 50,
    thcPercentage: 22,
    cbdPercentage: 0.1,
    indicaPercentage: 55,
    sativaPercentage: 45,
    weight: 3.5,
    effects: ['Relaxed', 'Happy', 'Euphoric', 'Uplifted', 'Hungry'],
    flavors: ['Earthy', 'Pine', 'Woody'],
  },
  {
    id: '2',
    title: 'Blue Dream',
    price: 10.99,
    description: 'Blue Dream is a sativa-dominant hybrid originating from California, achieving legendary status among West Coast strains. It crosses a Blueberry indica with the sativa Haze, creating a gentle balance of full-body relaxation with gentle cerebral invigoration. Sweet berry flavors blend with notes of pine and sandalwood, making for an enjoyable and beneficial smoke experience regardless of the consumer\'s experience level.',
    shortDescription: 'Balanced hybrid with berry flavors and smooth effects',
    category: 'Flowers',
    subcategory: 'Hybrid',
    imageUrl: 'https://images.unsplash.com/photo-1536057222397-b596dead4510?q=80&w=1000',
    stock: 35,
    thcPercentage: 18,
    cbdPercentage: 0.5,
    indicaPercentage: 40,
    sativaPercentage: 60,
    weight: 3.5,
    effects: ['Happy', 'Relaxed', 'Euphoric', 'Creative', 'Uplifted'],
    flavors: ['Berry', 'Sweet', 'Herbal'],
  },
  {
    id: '3',
    title: 'CBD Oil Tincture',
    price: 59.99,
    description: 'Our full-spectrum CBD oil tincture is crafted from organically grown hemp plants and extracted using CO2 methods to preserve all beneficial cannabinoids, terpenes, and flavonoids. Each bottle contains 1000mg of CBD with less than 0.3% THC, making it non-psychoactive. The oil is blended with organic MCT oil for improved bioavailability and comes with a precise dropper for accurate dosing.',
    shortDescription: 'Full-spectrum CBD oil for daily wellness',
    category: 'Medical',
    subcategory: 'Oil',
    imageUrl: 'https://images.unsplash.com/photo-1611249021021-9a1238072809?q=80&w=1000',
    stock: 25,
    cbdPercentage: 33,
    effects: ['Calm', 'Relief', 'Balance', 'Wellness'],
    flavors: ['Natural', 'Earthy', 'Hemp'],
  },
  {
    id: '4',
    title: 'THC Gummies',
    price: 24.99,
    description: 'These premium THC-infused gummies are crafted for consistent dosing and delicious taste. Each package contains 10 gummies with 10mg THC per piece, perfect for controlled consumption. Made with real fruit flavors and natural ingredients, our gummies offer a discrete and enjoyable way to consume cannabis. Effects typically begin within 30-60 minutes and can last 4-6 hours depending on individual metabolism.',
    shortDescription: 'Delicious fruit-flavored edibles with precise dosing',
    category: 'Edibles',
    subcategory: 'Gummies',
    imageUrl: 'https://images.unsplash.com/photo-1595858322957-c7ef77a3630a?q=80&w=1000',
    stock: 40,
    thcPercentage: 10,
    effects: ['Relaxed', 'Euphoric', 'Happy', 'Sleepy'],
    flavors: ['Berry', 'Citrus', 'Tropical'],
  },
  {
    id: '5',
    title: 'Premium Vape Cartridge',
    price: 45.99,
    description: 'Our premium 1g vape cartridge features pure cannabis distillate with natural terpenes reintroduced for authentic flavor and effect profiles. The ceramic core provides consistent vapor production without burning. Compatible with standard 510-thread batteries, this cartridge delivers approximately 200-300 puffs depending on usage. The clean extraction process ensures no harmful additives, just pure cannabis oil at 85% THC potency.',
    shortDescription: 'High-potency distillate with authentic terpene profiles',
    category: 'Extracts',
    subcategory: 'Vape Cartridges',
    imageUrl: 'https://images.unsplash.com/photo-1600965962155-b2294fb6df25?q=80&w=1000',
    stock: 30,
    thcPercentage: 85,
    effects: ['Focused', 'Creative', 'Energetic', 'Uplifted'],
    flavors: ['Citrus', 'Diesel', 'Skunk'],
  },
  {
    id: '6',
    title: 'Glass Water Pipe',
    price: 89.99,
    description: 'This handcrafted borosilicate glass water pipe stands 12 inches tall and features a honeycomb percolator for smooth, filtered hits. The wide, stable base prevents tipping while the ice catcher allows for cooled smoke. The 14mm female joint is compatible with most standard bowls and accessories. Each piece is individually crafted with attention to detail, resulting in both functionality and artistic appeal for an elevated smoking experience.',
    shortDescription: 'Artisan glass water pipe with honeycomb percolator',
    category: 'Accessories',
    subcategory: 'Water Pipes',
    imageUrl: 'https://images.unsplash.com/photo-1638605434088-7ef8fd0c7681?q=80&w=1000',
    stock: 15,
  },
];

export const sampleCategories: Category[] = [
  {
    id: '1',
    name: 'Flowers',
  },
  {
    id: '2',
    name: 'Extracts',
  },
  {
    id: '3',
    name: 'Edibles',
  },
  {
    id: '4',
    name: 'Medical',
  },
  {
    id: '5',
    name: 'Accessories',
  },
];

export const sampleUsers: User[] = [
  {
    id: "U001",
    name: "Jane Smith",
    email: "jane.smith@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jane",
    role: "admin",
    orderCount: 0,
    totalSpent: 0,
    joinDate: "2023-02-15",
    lastActive: "2023-09-28",
    status: "active"
  },
  {
    id: "U002",
    name: "Mike Johnson",
    email: "mike.johnson@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Mike",
    role: "customer",
    orderCount: 8,
    totalSpent: 1245.99,
    joinDate: "2023-03-10",
    lastActive: "2023-09-25",
    status: "active"
  },
  {
    id: "U003",
    name: "Sarah Williams",
    email: "sarah.williams@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
    role: "customer",
    orderCount: 12,
    totalSpent: 2340.50,
    joinDate: "2023-01-05",
    lastActive: "2023-09-27",
    status: "active"
  },
  {
    id: "U004",
    name: "David Brown",
    email: "david.brown@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=David",
    role: "manager",
    orderCount: 0,
    totalSpent: 0,
    joinDate: "2023-04-22",
    lastActive: "2023-09-26",
    status: "active"
  },
  {
    id: "U005",
    name: "Emily Davis",
    email: "emily.davis@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emily",
    role: "customer",
    orderCount: 3,
    totalSpent: 450.25,
    joinDate: "2023-05-18",
    lastActive: "2023-09-10",
    status: "inactive"
  },
  {
    id: "U006",
    name: "Alex Thompson",
    email: "alex.thompson@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
    role: "customer",
    orderCount: 1,
    totalSpent: 125.99,
    joinDate: "2023-06-30",
    lastActive: "2023-07-05",
    status: "suspended"
  },
  {
    id: "U007",
    name: "Lisa Anderson",
    email: "lisa.anderson@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Lisa",
    role: "customer",
    orderCount: 5,
    totalSpent: 890.75,
    joinDate: "2023-02-28",
    lastActive: "2023-09-20",
    status: "active"
  },
  {
    id: "U008",
    name: "James Wilson",
    email: "james.wilson@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=James",
    role: "customer",
    orderCount: 7,
    totalSpent: 1150.50,
    joinDate: "2023-03-15",
    lastActive: "2023-09-22",
    status: "active"
  },
  {
    id: "U009",
    name: "Rachel Green",
    email: "rachel.green@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Rachel",
    role: "customer",
    orderCount: 2,
    totalSpent: 320.00,
    joinDate: "2023-07-10",
    lastActive: "2023-09-15",
    status: "active"
  },
  {
    id: "U010",
    name: "Tom Harris",
    email: "tom.harris@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Tom",
    role: "customer",
    orderCount: 4,
    totalSpent: 600.25,
    joinDate: "2023-04-05",
    lastActive: "2023-08-30",
    status: "inactive"
  },
  {
    id: "U011",
    name: "Jessica Martin",
    email: "jessica.martin@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jessica",
    role: "customer",
    orderCount: 9,
    totalSpent: 1680.00,
    joinDate: "2023-01-20",
    lastActive: "2023-09-24",
    status: "active"
  },
  {
    id: "U012",
    name: "Chris Taylor",
    email: "chris.taylor@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Chris",
    role: "customer",
    orderCount: 6,
    totalSpent: 950.50,
    joinDate: "2023-05-05",
    lastActive: "2023-09-18",
    status: "active"
  }
];

export const sampleOrders: Order[] = [
  {
    id: 'ORD-1001',
    date: '2023-05-15',
    customer: 'Jane Smith',
    status: 'completed',
    total: 89.97,
    items: [
      {
        productId: '1',
        quantity: 2,
        price: 25.99,
      },
      {
        productId: '4',
        quantity: 1,
        price: 37.99,
      },
    ],
  },
  {
    id: 'ORD-1002',
    date: '2023-05-16',
    customer: 'Robert Johnson',
    status: 'processing',
    total: 61.98,
    items: [
      {
        productId: '3',
        quantity: 1,
        price: 61.98,
      },
    ],
  },
  {
    id: 'ORD-1003',
    date: '2023-05-17',
    customer: 'Sarah Williams',
    status: 'pending',
    total: 124.95,
    items: [
      {
        productId: '2',
        quantity: 3,
        price: 10.99,
      },
      {
        productId: '6',
        quantity: 1,
        price: 91.98,
      },
    ],
  },
  {
    id: 'ORD-1004',
    date: '2023-05-18',
    customer: 'Robert Johnson',
    status: 'cancelled',
    total: 45.99,
    items: [
      {
        productId: '5',
        quantity: 1,
        price: 45.99,
      },
    ],
  },
];
