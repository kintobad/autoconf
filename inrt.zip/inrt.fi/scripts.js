document.addEventListener('DOMContentLoaded', () => {
    const dots = document.querySelectorAll('.market-detail-dots span');
    const details = document.querySelectorAll('.market-detail');
    const menuToggle = document.querySelector('.menu-toggle');
    const menu = document.querySelector('.menu');
    let currentIndex = 0;

    function switchDetail(index) {
        if (window.innerWidth <= 768) {
            details.forEach(detail => detail.style.display = 'none');
            details[index].style.display = 'block';
        }
        dots.forEach(dot => dot.classList.remove('active'));
        dots[index].classList.add('active');
    }

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentIndex = index;
            switchDetail(currentIndex);
        });
    });

    function autoSwitchDetails() {
        if (window.innerWidth <= 768) {
            setInterval(() => {
                currentIndex = (currentIndex + 1) % details.length;
                switchDetail(currentIndex);
            }, 2000);
        }
    }

    if (window.innerWidth <= 768) {
        autoSwitchDetails();
    } else {
        details.forEach(detail => detail.style.display = 'block');
        const dotsContainer = document.querySelector('.market-detail-dots');
        if (dotsContainer) dotsContainer.style.display = 'none';
    }

    switchDetail(currentIndex);

    window.addEventListener('resize', () => {
        if (window.innerWidth <= 768) {
            details.forEach(detail => detail.style.display = 'none');
            details[0].style.display = 'block';
            dots.forEach(dot => dot.classList.remove('active'));
            dots[0].classList.add('active');
            autoSwitchDetails();
        } else {
            details.forEach(detail => detail.style.display = 'block');
            const dotsContainer = document.querySelector('.market-detail-dots');
            if (dotsContainer) dotsContainer.style.display = 'none';
        }
    });

    if (menuToggle) {
        menuToggle.addEventListener('click', (event) => {
            event.stopPropagation();
            menu.classList.toggle('active');
        });
    }

    window.addEventListener('click', (e) => {
        if (menu.classList.contains('active') && !menu.contains(e.target) && !menuToggle.contains(e.target)) {
            menu.classList.remove('active');
        }
    });
});