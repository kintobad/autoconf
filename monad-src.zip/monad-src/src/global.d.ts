declare global {
    function init_co(): void;
}
export { };
