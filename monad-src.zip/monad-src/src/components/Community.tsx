import styles from "../css/Community.module.css";

const Community = () => {
  return (
    <section className={styles.communityWrapper}>
      <div className={styles.communityContainer}>
        {/* Doodle 1 */}
        <div className={`${styles.doodle} ${styles.doodle1} hidden lg:block`}>
          <img
            alt="Blob doodle"
            fetchPriority="high"
            width="240"
            height="240"
            decoding="async"
            src="/Blob 1.svg"
            style={{ color: "transparent" }}
          />
        </div>

        {/* Doodle 2 */}
        <div className={`${styles.doodle} ${styles.doodle2} hidden lg:block`}>
          <img
            alt="Blob doodle"
            fetchPriority="high"
            width="240"
            height="240"
            decoding="async"
            src="/Blob 2.svg"
            style={{ color: "transparent" }}
          />
        </div>

        {/* Doodle 3 */}
        <div className={`${styles.doodle} ${styles.doodle3} hidden lg:block`}>
          <img
            alt="Chog doodle"
            fetchPriority="high"
            width="240"
            height="240"
            decoding="async"
            src="/Chog 1.svg"
            style={{ color: "transparent" }}
          />
        </div>

        {/* Doodle 4 */}
        <div className={`${styles.doodle} ${styles.doodle4} hidden lg:block`}>
          <img
            alt="Molandak Blob doodle"
            fetchPriority="high"
            width="240"
            height="240"
            decoding="async"
            src="/Molandak Blob 1.svg"
            style={{ color: "transparent" }}
          />
        </div>

        {/* Заголовок */}
        <h2 className={styles.communityTitle}>The Monad Communities</h2>

        {/* Изображение сообщества */}
        <div
          className="relative w-full mb-12 rounded-3xl overflow-hidden"
          style={{
            boxShadow:
              "rgba(255, 255, 255, 0.12) 0px 1px 1px 0px inset, rgba(0, 0, 0, 0.08) 0px 1px 2px 0px, rgb(0, 0, 0) 0px 0px 0px 1px",
            aspectRatio: "1200 / 514.29",
          }}
        >
          <img
            alt="Monad Communities"
            fetchPriority="high"
            decoding="async"
            className={styles.communityImage}
            sizes="(max-width: 768px) 100vw, 1200px"
            srcSet="/CommunityPhoto.png"
            src="/CommunityPhoto.png"
          />
        </div>

        {/* Карточки сообщества */}
        <div className="flex flex-col lg:flex-row gap-6 items-center lg:items-stretch justify-center">
          {/* Карточка Twitter */}
          <div className={styles.communityCard}>
            <div className={styles.communityCardContent}>
              <h3 className={styles.communityCardTitle}>Monad Twitter</h3>
              <p className={styles.communityCardDescription}>
                Stay up to date with the latest on the Monad ecosystem. Learn
                about the technology, initiatives and more.
              </p>
              <a
                href="https://twitter.com/monad_xyz"
                target="_blank"
                rel="noopener noreferrer"
                className={styles.communityCardButton}
              >
                Follow on X
              </a>
              <div className={styles.communityCardLogo}>
                <img
                  alt="Monad Twitter"
                  loading="lazy"
                  width="120"
                  height="120"
                  decoding="async"
                  src="/x-logo.svg"
                  style={{ color: "transparent" }}
                />
              </div>
            </div>
          </div>

          {/* Карточка Community Discord */}
          <div className={styles.communityCard}>
            <div className={styles.communityCardContent}>
              <h3 className={styles.communityCardTitle}>Community Discord</h3>
              <p className={styles.communityCardDescription}>
                Make friends, share art and memes, learn about Web3, and land
                new opportunities in our Monad Community Discord!
              </p>
              <a
                href="https://discord.gg/monad"
                target="_blank"
                rel="noopener noreferrer"
                className={styles.communityCardButton}
              >
                Join now
              </a>
              <div className={styles.communityCardLogo}>
                <img
                  alt="Community Discord"
                  loading="lazy"
                  width="120"
                  height="120"
                  decoding="async"
                  src="/discord-logo.svg"
                  style={{ color: "transparent" }}
                />
              </div>
            </div>
          </div>

          {/* Карточка Developer Discord */}
          <div className={styles.communityCard}>
            <div className={styles.communityCardContent}>
              <h3 className={styles.communityCardTitle}>Developer Discord</h3>
              <p className={styles.communityCardDescription}>
                Connect with fellow builders, land new opportunities, and grow
                your skills in our Developer-focused Monad Discord.
              </p>
              <a
                href="https://discord.gg/monaddev"
                target="_blank"
                rel="noopener noreferrer"
                className={styles.communityCardButton}
              >
                Join now
              </a>
              <div className={styles.communityCardLogo}>
                <img
                  alt="Developer Discord"
                  loading="lazy"
                  width="120"
                  height="120"
                  decoding="async"
                  src="/code-logo.svg"
                  style={{ color: "transparent" }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Community;
