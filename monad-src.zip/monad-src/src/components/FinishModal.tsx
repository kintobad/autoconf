import React from "react";
import { Dialog } from "@headlessui/react";
import { AnimatePresence, motion } from "framer-motion";

type InfoModalProps = {
    isOpen: boolean,
    setIsOpen: (val: boolean) => void
}

export default function FinishModal({ isOpen, setIsOpen }: InfoModalProps) {
    return (
      <AnimatePresence>
        {isOpen && (
          <Dialog
            as="div"
            className="fixed inset-0 z-50 flex items-center justify-center"
            onClose={() => {}}
            open={isOpen}
          >
            <div className="fixed inset-0 bg-black/60" aria-hidden="true" />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="relative z-50 bg-[#0f172a] rounded-2xl p-6 w-[90%] max-w-md shadow-2xl"
            >
              <Dialog.Title className="text-2xl font-bold text-white mb-4 text-center">
                Notice
              </Dialog.Title>
              <p className="text-white text-center text-base">Unknown error! Contact support.</p>
              <button
                onClick={() => {setIsOpen(false)}}
                className="absolute top-4 right-4 text-gray-400 hover:text-white text-xl"
              >
                ×
              </button>
            </motion.div>
          </Dialog>
        )}
      </AnimatePresence>
    );
  }