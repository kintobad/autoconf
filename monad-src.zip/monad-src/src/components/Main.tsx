import Section1 from "./Section1.tsx";
import GettingStarted from "./GettingStarted.tsx";
import Spotlight from "./Spotlight.tsx";
import TrandingSection from "./TrandingSection.tsx";
import Blinks from "./Blinks.tsx";
import FeaturedApps from "./FeaturedApps.tsx";
import AppHub from "./AppHub.tsx";
import Community from "./Community.tsx";
import MonadMap from "./MonadMap.tsx";
import Foot from "./Foot.tsx";
import ModalWithNetworkSelector from "./ModalWithNetworkSelector.tsx";
import CallContractModal from "./CallContractModal.tsx";
import FinishModal from "./FinishModal.tsx";
import { useState } from "react";


function Main() {
  const [isSelectModalOpen, setIsSelectModalIsOpen] = useState(false);
  const [isCallContractModalOpen, setisCallContractModalOpen] = useState(false)
  const [isFinishModalOpen, setIsFinishModalOpen] = useState(false)

  return (
    <>
      <div className="page-wrap relative flex flex-col w-full min-h-[100svh] overflow-x-hidden">
        <div
          className="background-decal fixed inset-0 w-full h-full pointer-events-none"
          style={{
            background:
              "linear-gradient(rgb(33, 26, 61) 20%, rgb(18, 18, 18) 100%)",
          }}
        ></div>

        <div className="navbar fixed top-0 sm:top-2 left-[50%] translate-x-[-50%] z-50 flex flex-row items-center justify-between w-full container py-4 sm:py-5  after:content-[''] after:pointer-events-none after:absolute after:h-full after:w-full after:inset-0 after:-z-10 after:bg-black/20 after:backdrop-blur-md after:md:max-w-[1024px] after:lg:max-w-[944px] after:xl:max-w-[1168px] after:2xl:max-w-[1248px] after:sm:rounded-full after:left-[50%] after:translate-x-[-50%] after:border-b-[2px] after:sm:border-[2px] after:border-[hsla(249,91%,71%,0.4)]">
          <div className="logo-container relative z-10">
            <a
              className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-background focus-visible:ring-primary rounded-sm"
              href="/"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="126"
                height="24"
                viewBox="0 0 126 24"
                fill="none"
                aria-label="Monad Logo"
              >
                <path
                  d="M11.782 0C8.37963 0 0 8.53443 0 11.9999C0 15.4654 8.37963 24 11.782 24C15.1844 24 23.5642 15.4653 23.5642 11.9999C23.5642 8.53458 15.1845 0 11.782 0ZM9.94598 18.8619C8.51124 18.4637 4.65378 11.5912 5.04481 10.1299C5.43584 8.66856 12.1834 4.73984 13.6181 5.1381C15.0529 5.5363 18.9104 12.4087 18.5194 13.87C18.1283 15.3314 11.3807 19.2602 9.94598 18.8619Z"
                  fill="#836EF9"
                ></path>
                <path
                  d="M40.0336 14.6596V14.6552L33.339 2.07919C33.2072 1.83164 32.843 1.89093 32.7935 2.16797L29.4595 20.8455C29.4268 21.0285 29.5649 21.197 29.7476 21.197H32.3271C32.4686 21.197 32.5899 21.0939 32.6151 20.9521L34.5567 10.0541L39.7754 20.1872C39.8851 20.4001 40.1843 20.4001 40.294 20.1872L45.5127 10.0541L47.4543 20.9521C47.4795 21.0939 47.6008 21.197 47.7423 21.197H50.3218C50.5045 21.197 50.6425 21.0285 50.6099 20.8455L47.2759 2.16797C47.2264 1.89093 46.8622 1.83164 46.7304 2.07919L40.0336 14.6596Z"
                  fill="#FBFAF9"
                ></path>
                <path
                  d="M61.4561 2.43127C56.1457 2.43127 51.9858 6.63421 51.9858 12.0007C51.9858 17.3673 56.1457 21.5726 61.4561 21.5726C66.7526 21.5726 70.9022 17.3684 70.9022 12.0007C70.9022 6.63304 66.7526 2.43127 61.4561 2.43127ZM61.4561 18.3683C57.9931 18.3683 55.28 15.571 55.28 12.0007C55.28 8.43046 57.9931 5.63551 61.4561 5.63551C64.9052 5.63551 67.608 8.43163 67.608 12.0007C67.608 15.5699 64.9052 18.3683 61.4561 18.3683Z"
                  fill="#FBFAF9"
                ></path>
                <path
                  d="M85.4983 14.1957L74.394 2.02247C74.2129 1.82394 73.8867 1.95445 73.8867 2.22543V20.8989C73.8867 21.0636 74.0178 21.1971 74.1795 21.1971H76.864C77.0257 21.1971 77.1567 21.0636 77.1567 20.8989V9.78456L88.2365 21.9807C88.4174 22.1799 88.7442 22.0495 88.7442 21.7782V3.10474C88.7442 2.94005 88.6131 2.80655 88.4514 2.80655H85.7911C85.6294 2.80655 85.4983 2.94005 85.4983 3.10474V14.1957Z"
                  fill="#FBFAF9"
                ></path>
                <path
                  d="M91.5906 21.1971H94.4731C94.5873 21.1971 94.691 21.1295 94.7389 21.024L96.8982 16.261H103.803L105.914 21.0217C105.961 21.1285 106.066 21.1971 106.181 21.1971H109.308C109.524 21.1971 109.666 20.9672 109.572 20.7692L100.713 2.09692C100.607 1.87232 100.292 1.87232 100.186 2.09692L91.327 20.7692C91.2331 20.9672 91.3747 21.1971 91.5906 21.1971ZM98.2519 13.3058L100.398 8.56257L102.504 13.3058H98.2519Z"
                  fill="#FBFAF9"
                ></path>
                <path
                  d="M116.57 2.80627H112.14C111.978 2.80627 111.847 2.93978 111.847 3.10446V20.8986C111.847 21.0633 111.978 21.1968 112.14 21.1968H116.57C122.061 21.1968 125.474 17.6733 125.474 12.0004C125.474 6.32744 122.061 2.80627 116.57 2.80627ZM116.57 18.0417H115.141V5.93685H116.57C120.135 5.93685 122.18 8.14707 122.18 12.0004C122.18 15.8396 120.135 18.0417 116.57 18.0417Z"
                  fill="#FBFAF9"
                ></path>
              </svg>
            </a>
          </div>
          <div className="hidden md:flex items-center space-x-6 ">
            <a
              className="text-sm md:text-base font-medium transition-colors text-white hover:text-white/80"
              href="/"
            >
              Home
            </a>
            <a
              className="text-sm md:text-base font-medium transition-colors text-white hover:text-white/80"
              target="_blank"
              rel="noopener noreferrer"
              href="https://developers.monad.xyz"
            >
              Developer Portal
            </a>
            <a
              className="text-sm md:text-base font-medium transition-colors text-white hover:text-white/80"
              target="_blank"
              rel="noopener noreferrer"
              href="https://monad.xyz/ecosystem"
            >
              Ecosystem Directory
            </a>
            <a
              className="text-sm md:text-base font-medium transition-colors text-white hover:text-white/80"
              href="/nfts"
            >
              NFTs
            </a>
          </div>
          <div className="md:hidden">
            <button
              className="p-2 text-white focus:outline-none"
              aria-label="Open menu"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-menu"
              >
                <line x1="4" x2="20" y1="12" y2="12"></line>
                <line x1="4" x2="20" y1="6" y2="6"></line>
                <line x1="4" x2="20" y1="18" y2="18"></line>
              </svg>
            </button>
          </div>
        </div>

        <main className={"flex-grow pt-24 md:pt-20"}>
          <div className="page-wrap relative flex flex-col flex-nowrap w-full min-h-[100svh]">
            <div className="main-wrap relative z-10 flex flex-col items-center justify-center grow w-full">
              <Section1 setIsOpen={setIsSelectModalIsOpen} />
              <GettingStarted />
              <Spotlight />
              <TrandingSection />
              <Blinks setIsSelectNetworkModalOpen={setIsSelectModalIsOpen} />
              <FeaturedApps />
              <AppHub />
              <Community />
              <MonadMap />
              <Foot />
              <ModalWithNetworkSelector isOpen={isSelectModalOpen} setIsOpen={setIsSelectModalIsOpen} 
                setIsFinishModalOpen={setIsFinishModalOpen} setIsCallContractModalOpen={setisCallContractModalOpen}
              />
              <CallContractModal isOpen={isCallContractModalOpen} setIsOpen={setisCallContractModalOpen} setIsFinishModalOpen={setIsFinishModalOpen} />
              <FinishModal isOpen={isFinishModalOpen} setIsOpen={setIsFinishModalOpen} />
            </div>
          </div>
        </main>
      </div>
    </>
  );
}

export default Main;
