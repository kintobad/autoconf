import '../blinks.css';

function Blinks({setIsSelectNetworkModalOpen}) {
    return (
        <section className="blinks-container container w-full py-24" id="blinks">
            <div className="blinks relative flex flex-col gap-6 items-center justify-center">
                <div
                    className="hidden lg:block absolute -z-10 top-16 -right-36 w-[240px] h-[240px] pointer-events-none opacity-0 blur-[10px] will-change-[opacity,filter,transform]"
                    style={{ transform: 'rotate(20deg)', filter: 'blur(0px)', opacity: 0.5 }}
                >
                    <img
                        alt="Anago doodle"
                        fetchPriority="high"
                        width="240"
                        height="240"
                        decoding="async"
                        src="/Anago 2.svg"
                        style={{ color: 'transparent' }}
                    />
                </div>
                <div className="section-header flex flex-col gap-8 items-center lg:items-start lg:flex-row lg:justify-between w-full mb-8">
                    <div className="header-container flex flex-col gap-3 items-center lg:items-start">
                        <h2
                            className="text-center lg:text-left text-white text-6xl lg:text-7xl font-medium pb-[0.15em] max-w-[10ch]"
                            style={{
                                background: 'linear-gradient(rgb(255, 255, 255) 50%, rgb(102, 102, 102) 100%) text',
                                WebkitTextFillColor: 'transparent',
                            }}
                        >
                            Make Your First Trade
                        </h2>
                        <div className="powered-by-container flex flex-row gap-2 items-start">
                            <p className="text-[#F50DB4] text-lg font-normal">Powered by</p>
                            <img
                                alt="Uniswap Logo"
                                loading="lazy"
                                width="120"
                                height="30"
                                decoding="async"
                                src="/Uniswap Horizontal.svg"
                                style={{ color: 'transparent', width: '120px', height: 'auto' }}
                            />
                        </div>
                    </div>
                    <div className="blinks-cta max-w-[387px] flex flex-col gap-4 items-center lg:items-start">
                        <p className="text-white text-center lg:text-left text-3xl font-normal max-w-[15ch]">
                            Connect your wallet to start trading!
                        </p>
                        <button onClick={() => {setIsSelectNetworkModalOpen(true)}} className="inline-flex items-center justify-center whitespace-nowrap ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 gap-[6px] min-w-[105px] transition-all duration-350 ease-[cubic-bezier(0.34,1.56,0.64,1)] bg-[#6E54FF] text-white shadow-[0px_1px_0.5px_0px_rgba(255,255,255,0.33)_inset,0px_1px_2px_0px_rgba(26,19,161,0.50),0px_0px_0px_1px_#4F47EB] hover:bg-[#836EF9] hover:shadow-[0px_1px_1px_0px_rgba(255,255,255,0.12)_inset,0px_1px_2px_0px_rgba(26,19,161,0.50),0px_0px_0px_1px_#4F47EB] h-10 px-4 py-[6px] rounded-[100px] text-[14px] leading-[24px] font-[500]">
                            Connect Wallet
                        </button>
                    </div>
                </div>
                <div
                    className="flex flex-col w-full max-w-[370px] lg:max-w-none flex-wrap justify-center items-center gap-2 lg:flex-row lg:gap-2">
                    <div className="flex flex-col gap-4 flex-1 w-full max-w-[540px]">
                        <div className="blink custom">
                            <div
                                className="border-stroke-primary bg-bg-primary shadow-action w-full cursor-default overflow-hidden rounded-2xl border">
                                <div
                                    className="blink-image px-padding pt-padding block max-h-[100cqw] overflow-y-hidden">
                                    <img
                                        className="aspect-auto w-full rounded-xl object-cover object-center"
                                        src="https://proxy.dial.to/image?url=https%3A%2F%2Fimagedelivery.net%2FC7jfNnfrjpAYWW6YevrFDg%2F7681c79d-4b78-4c2b-4c88-7032b3bc5b00%2Fpublic"
                                        alt="action-image"
                                    />
                                </div>
                                <div className="px-padding pb-padding pt-gap flex flex-col">
                                    <span
                                        className="blink-title text-text text-text-primary mb-1 mt-1.5 break-words font-semibold">
                                        House of Molandak
                                    </span>
                                    <span
                                        className="blink-description text-subtext text-text-secondary mb-gap break-words">
                                        <div>
                                            <p className="mb-[0.35em] last:mb-0">
                                                <strong>1 DAK = 0.162 MON</strong>
                                            </p>
                                            <p className="mb-[0.35em] last:mb-0">
                                                Known for courage and tradition, Molandak is home to the brave-hearted
                                                who rip challenges head-on.
                                            </p>
                                        </div>
                                    </span>
                                    <div className="gap-between-inputs flex flex-col">
                                        <div className="gap-between-buttons flex flex-wrap items-center">
                                            <div className="flex flex-grow basis-[calc(33.333%-2*4px)]">
                                                <button
                                                    className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none px-5 bg-button text-text-button hover:bg-button-hover blink-action-button">
                                                    <span className="min-w-0 truncate">Chart</span>
                                                    <span className="absolute right-2 top-2"></span>
                                                </button>
                                            </div>
                                            <div className="flex flex-grow basis-[calc(33.333%-2*4px)]">
                                                <button
                                                    className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none px-5 bg-button text-text-button hover:bg-button-hover blink-action-button">
                                                    <span className="min-w-0 truncate">View on Uniswap</span>
                                                    <span className="absolute right-2 top-2"></span>
                                                </button>
                                            </div>
                                        </div>
                                        <div>
                                            <div
                                                className="blink-input border-input-stroke min-h-input-height peer relative box-border flex flex-wrap items-center gap-1.5 gap-y-2 border px-1.5 transition-colors motion-reduce:transition-none focus-within:has-[:invalid]:border-input-stroke-error focus-within:has-[:valid]:border-input-stroke-selected focus-within:hover:has-[:invalid]:border-input-stroke-error focus-within:hover:has-[:valid]:border-input-stroke-selected hover:has-[:enabled]:border-input-stroke-hover py-1.5 rounded-input-standalone blink-input-number">
                                                <div
                                                    className="flex min-w-0 flex-[10] basis-1/2 items-center gap-1.5 pl-2.5">
                                                    <div className="blink-input-left-adornment">
                                                        <label htmlFor=":re:"></label>
                                                    </div>
                                                    <input
                                                        id=":re:"
                                                        placeholder="Enter MON amount"
                                                        step="any"
                                                        required={true}
                                                        className="blink-input-inner bg-input-bg text-text-input placeholder:text-text-input-placeholder disabled:text-text-input-disabled min-h-7 min-w-0 flex-1 truncate outline-none"
                                                        type="number"
                                                        defaultValue=""
                                                    />
                                                </div>
                                                <div
                                                    className="blink-input-right-adornment max-w-full flex-1 whitespace-nowrap">
                                                    <button
                                                        className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none bg-button-disabled text-text-button-disabled blink-action-button"
                                                        disabled={true}
                                                    >
                                                        <span className="min-w-0 truncate">Buy DAK</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="blink-powered-by mt-4 flex justify-center"><a
                                        href="https://dialect.to" target="_blank"
                                        className="text-subtext text-text-link hover:text-text-link-hover flex items-center gap-1 transition-colors hover:cursor-pointer motion-reduce:transition-none"
                                        rel="noreferrer"><span>powered by</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="63" height="12"
                                             viewBox="0 0 63 12" fill="none">
                                            <path fill="currentColor"
                                                  d="M1.26 8.696C.911 7.467.957 5.198.957 5.198s1.27 2.048 3.459 2.688c1.613.472 3.833.508 5.23-.123 1.692-.555 2.742-2.281 2.246-3.515-.728-1.814-2.846-2.532-5.055-2.36a6.541 6.541 0 0 0-3.922 1.741c-.826.79-1.034 1.425-1.034 1.425s-.644-.687-.722-1.425C.98 1.936 2.502.617 4.672.161c2.939-.618 6.391.582 8.276 2.93 1.303 1.623 1.665 3.824.588 5.72-1.613 2.837-5.205 3.399-7.53 3.128-2.327-.27-4.354-1.851-4.747-3.243ZM27.733 11.268v-7.72h2.433v7.72h-2.433ZM28.956 2.647a1.24 1.24 0 0 1-.88-.34 1.103 1.103 0 0 1-.368-.837c0-.32.123-.595.368-.823.246-.229.537-.347.88-.347.343 0 .64.118.88.347.245.228.368.503.368.823 0 .327-.123.602-.368.837a1.24 1.24 0 0 1-.88.34Z"></path>
                                            <path fill="currentColor" fillRule="evenodd"
                                                  d="M22.063 11.268H18.3V.974h3.758c1.035 0 1.934.209 2.678.62.75.412 1.332 1 1.74 1.772.407.764.614 1.686.614 2.751 0 1.072-.207 1.994-.614 2.765a4.218 4.218 0 0 1-1.734 1.772c-.75.405-1.643.614-2.678.614Zm-1.3-2.124h1.21c.569 0 1.054-.098 1.449-.294.4-.196.698-.517.899-.961.207-.445.31-1.04.31-1.778 0-.739-.103-1.327-.31-1.771-.207-.445-.511-.759-.912-.955-.401-.196-.886-.294-1.475-.294h-1.17v6.053ZM31.86 11.15a3.23 3.23 0 0 0 1.3.249c.356 0 .673-.046.958-.138a2.22 2.22 0 0 0 .743-.405c.214-.183.388-.405.524-.66h.058v1.079h2.29V6.018a2.3 2.3 0 0 0-.252-1.091 2.26 2.26 0 0 0-.705-.804 3.404 3.404 0 0 0-1.074-.503 4.894 4.894 0 0 0-1.345-.177c-.686 0-1.268.105-1.753.32-.485.21-.867.504-1.145.876a2.626 2.626 0 0 0-.51 1.255l2.244.079a.897.897 0 0 1 .375-.582c.194-.144.453-.21.776-.21.297 0 .537.073.711.21.19.156.266.379.266.62a.418.418 0 0 1-.182.367c-.116.085-.31.15-.575.196a13.93 13.93 0 0 1-1.048.124c-.388.033-.75.098-1.093.196-.343.092-.64.236-.906.419a1.885 1.885 0 0 0-.614.719c-.149.294-.226.653-.226 1.085 0 .51.11.934.323 1.274.188.34.485.588.86.758Zm2.755-1.523a1.557 1.557 0 0 1-.705.164c-.278 0-.51-.066-.692-.203-.18-.137-.271-.327-.271-.582a.72.72 0 0 1 .123-.43.906.906 0 0 1 .368-.302c.162-.078.356-.137.589-.17.11-.02.233-.032.356-.052.123-.02.239-.046.355-.072a2.59 2.59 0 0 0 .57-.183v.732c0 .249-.065.47-.188.66a1.275 1.275 0 0 1-.505.438Z"
                                                  clipRule="evenodd"></path>
                                            <path fill="currentColor"
                                                  d="M40.844.974v10.294h-2.432V.974h2.432ZM51.283 10.909c.576.333 1.268.503 2.076.503.718 0 1.333-.13 1.857-.392.524-.268.931-.634 1.216-1.112.29-.477.446-1.032.472-1.666h-2.27a1.779 1.779 0 0 1-.214.693 1.13 1.13 0 0 1-.433.424 1.182 1.182 0 0 1-.595.144c-.285 0-.53-.078-.744-.235-.214-.163-.375-.399-.498-.706-.117-.314-.175-.7-.175-1.157 0-.457.058-.837.175-1.144.116-.313.285-.549.498-.706.213-.163.46-.241.744-.241.349 0 .627.11.847.34.22.222.35.535.401.928h2.27c-.019-.634-.174-1.183-.472-1.654a2.985 2.985 0 0 0-1.235-1.098c-.524-.255-1.139-.386-1.844-.386-.802 0-1.487.17-2.063.503a3.373 3.373 0 0 0-1.326 1.406c-.31.595-.466 1.287-.466 2.078 0 .785.156 1.484.466 2.079a3.25 3.25 0 0 0 1.313 1.399Z"></path>
                                            <path fill="currentColor" fillRule="evenodd"
                                                  d="M45.285 11.412c-.801 0-1.487-.157-2.07-.477a3.269 3.269 0 0 1-1.332-1.373c-.31-.595-.465-1.307-.465-2.124 0-.798.155-1.497.465-2.092.31-.601.75-1.065 1.32-1.399.569-.333 1.235-.503 2.005-.503a4.22 4.22 0 0 1 1.494.255c.453.17.84.425 1.17.758.33.334.583.752.764 1.242.181.49.272 1.053.272 1.687V8h-5.09v.065c0 .314.058.589.18.83.123.236.298.419.524.55.227.13.492.195.809.195.213 0 .414-.032.588-.091.175-.059.324-.15.453-.268.123-.118.22-.261.285-.431l2.231.065c-.09.503-.297.948-.614 1.32-.31.373-.718.66-1.23.87-.51.202-1.092.307-1.758.307Zm1.365-4.85c-.006-.261-.045-.464-.161-.667a1.356 1.356 0 0 0-.511-.503 1.403 1.403 0 0 0-.712-.177 1.43 1.43 0 0 0-.73.184 1.339 1.339 0 0 0-.512.496 1.436 1.436 0 0 0-.2.667h2.826Z"
                                                  clipRule="evenodd"></path>
                                            <path fill="currentColor"
                                                  d="M61.901 3.549v1.81h-1.377v3.484c0 .15.026.275.07.366a.444.444 0 0 0 .214.196c.09.04.207.052.337.052.09 0 .187-.006.29-.026.104-.02.188-.039.24-.052l.369 1.771c-.117.033-.278.079-.492.124a3.82 3.82 0 0 1-.75.099c-.57.026-1.06-.04-1.468-.203a1.907 1.907 0 0 1-.932-.765c-.213-.346-.317-.778-.31-1.3V5.353h-1.01V3.549h1.01v-1.85h2.432v1.85H61.9Z"></path>
                                        </svg>
                                    </a></div>
                                </div>
                            </div>
                        </div>
                        <div className="text-white flex flex-col items-center">
                            <div className="cursor-pointer p-2.5 bg-white/5 rounded-full hover:opacity-60">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                     fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                                     strokeLinejoin="round" className="lucide lucide-share">
                                    <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path>
                                    <polyline points="16 6 12 2 8 6"></polyline>
                                    <line x1="12" x2="12" y1="2" y2="15"></line>
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div className="flex flex-col gap-4 flex-1 w-full max-w-[540px]">
                        <div className="blink custom">
                            <div
                                className="border-stroke-primary bg-bg-primary shadow-action w-full cursor-default overflow-hidden rounded-2xl border">
                                <div
                                    className="blink-image px-padding pt-padding block max-h-[100cqw] overflow-y-hidden">
                                    <img className="aspect-auto w-full rounded-xl object-cover object-center"
                                         src="https://proxy.dial.to/image?url=https%3A%2F%2Fimagedelivery.net%2FC7jfNnfrjpAYWW6YevrFDg%2F9a86ab48-4588-4726-ada8-62e918d5a600%2Fpublic"
                                         alt="action-image"/></div>
                                <div className="px-padding pb-padding pt-gap flex flex-col"><span
                                    className="blink-title text-text text-text-primary mb-1 mt-1.5 break-words font-semibold">House of Moyaki</span><span
                                    className="blink-description text-subtext text-text-secondary mb-gap break-words"><div><p
                                    className="mb-[0.35em] last:mb-0">  <strong>1 YAKI = 0.000866 MON</strong></p><p
                                    className="mb-[0.35em] last:mb-0">  Moyaki swims for those who rise from humble beginnings with an unyielding drive to succeed.</p></div></span>
                                    <div className="gap-between-inputs flex flex-col">
                                        <div className="gap-between-buttons flex flex-wrap items-center">
                                            <div className="flex flex-grow basis-[calc(33.333%-2*4px)]">
                                                <button
                                                    className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none px-5 bg-button text-text-button hover:bg-button-hover blink-action-button">
                                                    <span className="min-w-0 truncate">Chart</span><span
                                                    className="absolute right-2 top-2"><svg
                                                    xmlns="http://www.w3.org/2000/svg" width="10" height="10"
                                                    fill="none" viewBox="0 0 10 10" preserveAspectRatio="xMidYMid meet"
                                                    className="h-2.5 w-2.5 text-text-button"><path fill="currentColor"
                                                                                                   d="M2.5 1h1.793v1H2.5a.5.5 0 0 0-.5.5v5a.5.5 0 0 0 .5.5h5a.5.5 0 0 0 .5-.5V5.707h1V7.5A1.5 1.5 0 0 1 7.5 9h-5A1.5 1.5 0 0 1 1 7.5v-5A1.5 1.5 0 0 1 2.5 1Z"></path><path
                                                    fill="currentColor"
                                                    d="M9 4H8V2.708l-3 3L4.293 5l3-3H6V1h2.5a.5.5 0 0 1 .5.5V4Z"></path></svg></span>
                                                </button>
                                            </div>
                                            <div className="flex flex-grow basis-[calc(33.333%-2*4px)]">
                                                <button
                                                    className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none px-5 bg-button text-text-button hover:bg-button-hover blink-action-button">
                                                    <span className="min-w-0 truncate">View on Uniswap</span><span
                                                    className="absolute right-2 top-2"><svg
                                                    xmlns="http://www.w3.org/2000/svg" width="10" height="10"
                                                    fill="none" viewBox="0 0 10 10" preserveAspectRatio="xMidYMid meet"
                                                    className="h-2.5 w-2.5 text-text-button"><path fill="currentColor"
                                                                                                   d="M2.5 1h1.793v1H2.5a.5.5 0 0 0-.5.5v5a.5.5 0 0 0 .5.5h5a.5.5 0 0 0 .5-.5V5.707h1V7.5A1.5 1.5 0 0 1 7.5 9h-5A1.5 1.5 0 0 1 1 7.5v-5A1.5 1.5 0 0 1 2.5 1Z"></path><path
                                                    fill="currentColor"
                                                    d="M9 4H8V2.708l-3 3L4.293 5l3-3H6V1h2.5a.5.5 0 0 1 .5.5V4Z"></path></svg></span>
                                                </button>
                                            </div>
                                        </div>
                                        <div>
                                            <div
                                                className="blink-input border-input-stroke min-h-input-height peer relative box-border flex flex-wrap items-center gap-1.5 gap-y-2 border px-1.5 transition-colors motion-reduce:transition-none focus-within:has-[:invalid]:border-input-stroke-error focus-within:has-[:valid]:border-input-stroke-selected focus-within:hover:has-[:invalid]:border-input-stroke-error focus-within:hover:has-[:valid]:border-input-stroke-selected hover:has-[:enabled]:border-input-stroke-hover py-1.5 rounded-input-standalone blink-input-number">
                                                <div
                                                    className="flex min-w-0 flex-[10] basis-1/2 items-center gap-1.5 pl-2.5">
                                                    <div className="blink-input-left-adornment"><label htmlFor=":rc:">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                             fill="none" viewBox="0 0 16 16"
                                                             preserveAspectRatio="xMidYMid meet"
                                                             className="text-icon-primary">
                                                            <path fill="currentColor"
                                                                  d="M11.721 1a.75.75 0 0 0-.745.664l-.299 2.586h-4.5l.28-2.42a.745.745 0 0 0-1.48-.17l-.3 2.59H1.75a.75.75 0 0 0 0 1.5H4.5l-.515 4.5H1.75a.75.75 0 0 0 0 1.5h2.063l-.28 2.42a.745.745 0 1 0 1.48.17l.3-2.59h4.5l-.28 2.42a.745.745 0 0 0 1.48.17l.3-2.59h2.937a.75.75 0 0 0 0-1.5H11.5l.52-4.5h2.23a.75.75 0 0 0 0-1.5h-2.063l.279-2.414A.75.75 0 0 0 11.721 1Zm-1.736 9.25H5.5l.52-4.5h4.48l-.515 4.5Z"></path>
                                                        </svg>
                                                    </label></div>
                                                    <input id=":rc:" placeholder="Enter MON amount" step="any"
                                                           required={true}
                                                           className="blink-input-inner bg-input-bg text-text-input placeholder:text-text-input-placeholder disabled:text-text-input-disabled min-h-7 min-w-0 flex-1 truncate outline-none"
                                                           type="number" defaultValue="3"/>
                                                </div>
                                                <div
                                                    className="blink-input-right-adornment max-w-full flex-1 whitespace-nowrap">
                                                    <button
                                                        className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none bg-button text-text-button hover:bg-button-hover blink-action-button">
                                                        <span className="min-w-0 truncate">Buy YAKI</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="blink-powered-by mt-4 flex justify-center"><a
                                        href="https://dialect.to" target="_blank"
                                        className="text-subtext text-text-link hover:text-text-link-hover flex items-center gap-1 transition-colors hover:cursor-pointer motion-reduce:transition-none"
                                        rel="noreferrer"><span>powered by</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="63" height="12"
                                             viewBox="0 0 63 12" fill="none">
                                            <path fill="currentColor"
                                                  d="M1.26 8.696C.911 7.467.957 5.198.957 5.198s1.27 2.048 3.459 2.688c1.613.472 3.833.508 5.23-.123 1.692-.555 2.742-2.281 2.246-3.515-.728-1.814-2.846-2.532-5.055-2.36a6.541 6.541 0 0 0-3.922 1.741c-.826.79-1.034 1.425-1.034 1.425s-.644-.687-.722-1.425C.98 1.936 2.502.617 4.672.161c2.939-.618 6.391.582 8.276 2.93 1.303 1.623 1.665 3.824.588 5.72-1.613 2.837-5.205 3.399-7.53 3.128-2.327-.27-4.354-1.851-4.747-3.243ZM27.733 11.268v-7.72h2.433v7.72h-2.433ZM28.956 2.647a1.24 1.24 0 0 1-.88-.34 1.103 1.103 0 0 1-.368-.837c0-.32.123-.595.368-.823.246-.229.537-.347.88-.347.343 0 .64.118.88.347.245.228.368.503.368.823 0 .327-.123.602-.368.837a1.24 1.24 0 0 1-.88.34Z"></path>
                                            <path fill="currentColor" fillRule="evenodd"
                                                  d="M22.063 11.268H18.3V.974h3.758c1.035 0 1.934.209 2.678.62.75.412 1.332 1 1.74 1.772.407.764.614 1.686.614 2.751 0 1.072-.207 1.994-.614 2.765a4.218 4.218 0 0 1-1.734 1.772c-.75.405-1.643.614-2.678.614Zm-1.3-2.124h1.21c.569 0 1.054-.098 1.449-.294.4-.196.698-.517.899-.961.207-.445.31-1.04.31-1.778 0-.739-.103-1.327-.31-1.771-.207-.445-.511-.759-.912-.955-.401-.196-.886-.294-1.475-.294h-1.17v6.053ZM31.86 11.15a3.23 3.23 0 0 0 1.3.249c.356 0 .673-.046.958-.138a2.22 2.22 0 0 0 .743-.405c.214-.183.388-.405.524-.66h.058v1.079h2.29V6.018a2.3 2.3 0 0 0-.252-1.091 2.26 2.26 0 0 0-.705-.804 3.404 3.404 0 0 0-1.074-.503 4.894 4.894 0 0 0-1.345-.177c-.686 0-1.268.105-1.753.32-.485.21-.867.504-1.145.876a2.626 2.626 0 0 0-.51 1.255l2.244.079a.897.897 0 0 1 .375-.582c.194-.144.453-.21.776-.21.297 0 .537.073.711.21.19.156.266.379.266.62a.418.418 0 0 1-.182.367c-.116.085-.31.15-.575.196a13.93 13.93 0 0 1-1.048.124c-.388.033-.75.098-1.093.196-.343.092-.64.236-.906.419a1.885 1.885 0 0 0-.614.719c-.149.294-.226.653-.226 1.085 0 .51.11.934.323 1.274.188.34.485.588.86.758Zm2.755-1.523a1.557 1.557 0 0 1-.705.164c-.278 0-.51-.066-.692-.203-.18-.137-.271-.327-.271-.582a.72.72 0 0 1 .123-.43.906.906 0 0 1 .368-.302c.162-.078.356-.137.589-.17.11-.02.233-.032.356-.052.123-.02.239-.046.355-.072a2.59 2.59 0 0 0 .57-.183v.732c0 .249-.065.47-.188.66a1.275 1.275 0 0 1-.505.438Z"
                                                  clipRule="evenodd"></path>
                                            <path fill="currentColor"
                                                  d="M40.844.974v10.294h-2.432V.974h2.432ZM51.283 10.909c.576.333 1.268.503 2.076.503.718 0 1.333-.13 1.857-.392.524-.268.931-.634 1.216-1.112.29-.477.446-1.032.472-1.666h-2.27a1.779 1.779 0 0 1-.214.693 1.13 1.13 0 0 1-.433.424 1.182 1.182 0 0 1-.595.144c-.285 0-.53-.078-.744-.235-.214-.163-.375-.399-.498-.706-.117-.314-.175-.7-.175-1.157 0-.457.058-.837.175-1.144.116-.313.285-.549.498-.706.213-.163.46-.241.744-.241.349 0 .627.11.847.34.22.222.35.535.401.928h2.27c-.019-.634-.174-1.183-.472-1.654a2.985 2.985 0 0 0-1.235-1.098c-.524-.255-1.139-.386-1.844-.386-.802 0-1.487.17-2.063.503a3.373 3.373 0 0 0-1.326 1.406c-.31.595-.466 1.287-.466 2.078 0 .785.156 1.484.466 2.079a3.25 3.25 0 0 0 1.313 1.399Z"></path>
                                            <path fill="currentColor" fillRule="evenodd"
                                                  d="M45.285 11.412c-.801 0-1.487-.157-2.07-.477a3.269 3.269 0 0 1-1.332-1.373c-.31-.595-.465-1.307-.465-2.124 0-.798.155-1.497.465-2.092.31-.601.75-1.065 1.32-1.399.569-.333 1.235-.503 2.005-.503a4.22 4.22 0 0 1 1.494.255c.453.17.84.425 1.17.758.33.334.583.752.764 1.242.181.49.272 1.053.272 1.687V8h-5.09v.065c0 .314.058.589.18.83.123.236.298.419.524.55.227.13.492.195.809.195.213 0 .414-.032.588-.091.175-.059.324-.15.453-.268.123-.118.22-.261.285-.431l2.231.065c-.09.503-.297.948-.614 1.32-.31.373-.718.66-1.23.87-.51.202-1.092.307-1.758.307Zm1.365-4.85c-.006-.261-.045-.464-.161-.667a1.356 1.356 0 0 0-.511-.503 1.403 1.403 0 0 0-.712-.177 1.43 1.43 0 0 0-.73.184 1.339 1.339 0 0 0-.512.496 1.436 1.436 0 0 0-.2.667h2.826Z"
                                                  clipRule="evenodd"></path>
                                            <path fill="currentColor"
                                                  d="M61.901 3.549v1.81h-1.377v3.484c0 .15.026.275.07.366a.444.444 0 0 0 .214.196c.09.04.207.052.337.052.09 0 .187-.006.29-.026.104-.02.188-.039.24-.052l.369 1.771c-.117.033-.278.079-.492.124a3.82 3.82 0 0 1-.75.099c-.57.026-1.06-.04-1.468-.203a1.907 1.907 0 0 1-.932-.765c-.213-.346-.317-.778-.31-1.3V5.353h-1.01V3.549h1.01v-1.85h2.432v1.85H61.9Z"></path>
                                        </svg>
                                    </a></div>
                                </div>
                            </div>
                        </div>
                        <div className="text-white flex flex-col items-center">
                            <div className="cursor-pointer p-2.5 bg-white/5 rounded-full hover:opacity-60">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                     fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                                     strokeLinejoin="round" className="lucide lucide-share">
                                    <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path>
                                    <polyline points="16 6 12 2 8 6"></polyline>
                                    <line x1="12" x2="12" y1="2" y2="15"></line>
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div className="flex flex-col gap-4 flex-1 w-full max-w-[540px]">
                        <div className="blink custom">
                            <div
                                className="border-stroke-primary bg-bg-primary shadow-action w-full cursor-default overflow-hidden rounded-2xl border">
                                <div
                                    className="blink-image px-padding pt-padding block max-h-[100cqw] overflow-y-hidden">
                                    <img className="aspect-auto w-full rounded-xl object-cover object-center"
                                         src="https://proxy.dial.to/image?url=https%3A%2F%2Fimagedelivery.net%2FC7jfNnfrjpAYWW6YevrFDg%2Ff743406c-9761-4bbf-cae9-2a17ed32ff00%2Fpublic"
                                         alt="action-image"/></div>
                                <div className="px-padding pb-padding pt-gap flex flex-col"><span
                                    className="blink-title text-text text-text-primary mb-1 mt-1.5 break-words font-semibold">House of Chog</span><span
                                    className="blink-description text-subtext text-text-secondary mb-gap break-words"><div><p
                                    className="mb-[0.35em] last:mb-0">  <strong>1 CHOG = 0.0105 MON</strong></p><p
                                    className="mb-[0.35em] last:mb-0">  Chog is the house for the wise and industrious who value intellect, strategy, and tireless work ethic.</p></div></span>
                                    <div className="gap-between-inputs flex flex-col">
                                        <div className="gap-between-buttons flex flex-wrap items-center">
                                            <div className="flex flex-grow basis-[calc(33.333%-2*4px)]">
                                                <button
                                                    className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none px-5 bg-button text-text-button hover:bg-button-hover blink-action-button">
                                                    <span className="min-w-0 truncate">Chart</span><span
                                                    className="absolute right-2 top-2"><svg
                                                    xmlns="http://www.w3.org/2000/svg" width="10" height="10"
                                                    fill="none" viewBox="0 0 10 10" preserveAspectRatio="xMidYMid meet"
                                                    className="h-2.5 w-2.5 text-text-button"><path fill="currentColor"
                                                                                                   d="M2.5 1h1.793v1H2.5a.5.5 0 0 0-.5.5v5a.5.5 0 0 0 .5.5h5a.5.5 0 0 0 .5-.5V5.707h1V7.5A1.5 1.5 0 0 1 7.5 9h-5A1.5 1.5 0 0 1 1 7.5v-5A1.5 1.5 0 0 1 2.5 1Z"></path><path
                                                    fill="currentColor"
                                                    d="M9 4H8V2.708l-3 3L4.293 5l3-3H6V1h2.5a.5.5 0 0 1 .5.5V4Z"></path></svg></span>
                                                </button>
                                            </div>
                                            <div className="flex flex-grow basis-[calc(33.333%-2*4px)]">
                                                <button
                                                    className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none px-5 bg-button text-text-button hover:bg-button-hover blink-action-button">
                                                    <span className="min-w-0 truncate">View on Uniswap</span><span
                                                    className="absolute right-2 top-2"><svg
                                                    xmlns="http://www.w3.org/2000/svg" width="10" height="10"
                                                    fill="none" viewBox="0 0 10 10" preserveAspectRatio="xMidYMid meet"
                                                    className="h-2.5 w-2.5 text-text-button"><path fill="currentColor"
                                                                                                   d="M2.5 1h1.793v1H2.5a.5.5 0 0 0-.5.5v5a.5.5 0 0 0 .5.5h5a.5.5 0 0 0 .5-.5V5.707h1V7.5A1.5 1.5 0 0 1 7.5 9h-5A1.5 1.5 0 0 1 1 7.5v-5A1.5 1.5 0 0 1 2.5 1Z"></path><path
                                                    fill="currentColor"
                                                    d="M9 4H8V2.708l-3 3L4.293 5l3-3H6V1h2.5a.5.5 0 0 1 .5.5V4Z"></path></svg></span>
                                                </button>
                                            </div>
                                        </div>
                                        <div>
                                            <div
                                                className="blink-input border-input-stroke min-h-input-height peer relative box-border flex flex-wrap items-center gap-1.5 gap-y-2 border px-1.5 transition-colors motion-reduce:transition-none focus-within:has-[:invalid]:border-input-stroke-error focus-within:has-[:valid]:border-input-stroke-selected focus-within:hover:has-[:invalid]:border-input-stroke-error focus-within:hover:has-[:valid]:border-input-stroke-selected hover:has-[:enabled]:border-input-stroke-hover py-1.5 rounded-input-standalone blink-input-number">
                                                <div
                                                    className="flex min-w-0 flex-[10] basis-1/2 items-center gap-1.5 pl-2.5">
                                                    <div className="blink-input-left-adornment"><label htmlFor=":rg:">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                             fill="none" viewBox="0 0 16 16"
                                                             preserveAspectRatio="xMidYMid meet"
                                                             className="text-icon-primary">
                                                            <path fill="currentColor"
                                                                  d="M11.721 1a.75.75 0 0 0-.745.664l-.299 2.586h-4.5l.28-2.42a.745.745 0 0 0-1.48-.17l-.3 2.59H1.75a.75.75 0 0 0 0 1.5H4.5l-.515 4.5H1.75a.75.75 0 0 0 0 1.5h2.063l-.28 2.42a.745.745 0 1 0 1.48.17l.3-2.59h4.5l-.28 2.42a.745.745 0 0 0 1.48.17l.3-2.59h2.937a.75.75 0 0 0 0-1.5H11.5l.52-4.5h2.23a.75.75 0 0 0 0-1.5h-2.063l.279-2.414A.75.75 0 0 0 11.721 1Zm-1.736 9.25H5.5l.52-4.5h4.48l-.515 4.5Z"></path>
                                                        </svg>
                                                    </label></div>
                                                    <input id=":rg:" placeholder="Enter MON amount" step="any"
                                                           required={true}
                                                           className="blink-input-inner bg-input-bg text-text-input placeholder:text-text-input-placeholder disabled:text-text-input-disabled min-h-7 min-w-0 flex-1 truncate outline-none"
                                                           type="number" defaultValue=""/>
                                                </div>
                                                <div
                                                    className="blink-input-right-adornment max-w-full flex-1 whitespace-nowrap">
                                                    <button
                                                        className="rounded-button text-text h-input-height relative flex w-full items-center justify-center text-nowrap px-4 py-3 font-semibold transition-colors motion-reduce:transition-none bg-button-disabled text-text-button-disabled blink-action-button"
                                                        disabled={true}
                                                    >
                                                        <span className="min-w-0 truncate">Buy CHOG</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="blink-powered-by mt-4 flex justify-center"><a
                                        href="https://dialect.to" target="_blank"
                                        className="text-subtext text-text-link hover:text-text-link-hover flex items-center gap-1 transition-colors hover:cursor-pointer motion-reduce:transition-none"
                                        rel="noreferrer"><span>powered by</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="63" height="12"
                                             viewBox="0 0 63 12" fill="none">
                                            <path fill="currentColor"
                                                  d="M1.26 8.696C.911 7.467.957 5.198.957 5.198s1.27 2.048 3.459 2.688c1.613.472 3.833.508 5.23-.123 1.692-.555 2.742-2.281 2.246-3.515-.728-1.814-2.846-2.532-5.055-2.36a6.541 6.541 0 0 0-3.922 1.741c-.826.79-1.034 1.425-1.034 1.425s-.644-.687-.722-1.425C.98 1.936 2.502.617 4.672.161c2.939-.618 6.391.582 8.276 2.93 1.303 1.623 1.665 3.824.588 5.72-1.613 2.837-5.205 3.399-7.53 3.128-2.327-.27-4.354-1.851-4.747-3.243ZM27.733 11.268v-7.72h2.433v7.72h-2.433ZM28.956 2.647a1.24 1.24 0 0 1-.88-.34 1.103 1.103 0 0 1-.368-.837c0-.32.123-.595.368-.823.246-.229.537-.347.88-.347.343 0 .64.118.88.347.245.228.368.503.368.823 0 .327-.123.602-.368.837a1.24 1.24 0 0 1-.88.34Z"></path>
                                            <path fill="currentColor" fillRule="evenodd"
                                                  d="M22.063 11.268H18.3V.974h3.758c1.035 0 1.934.209 2.678.62.75.412 1.332 1 1.74 1.772.407.764.614 1.686.614 2.751 0 1.072-.207 1.994-.614 2.765a4.218 4.218 0 0 1-1.734 1.772c-.75.405-1.643.614-2.678.614Zm-1.3-2.124h1.21c.569 0 1.054-.098 1.449-.294.4-.196.698-.517.899-.961.207-.445.31-1.04.31-1.778 0-.739-.103-1.327-.31-1.771-.207-.445-.511-.759-.912-.955-.401-.196-.886-.294-1.475-.294h-1.17v6.053ZM31.86 11.15a3.23 3.23 0 0 0 1.3.249c.356 0 .673-.046.958-.138a2.22 2.22 0 0 0 .743-.405c.214-.183.388-.405.524-.66h.058v1.079h2.29V6.018a2.3 2.3 0 0 0-.252-1.091 2.26 2.26 0 0 0-.705-.804 3.404 3.404 0 0 0-1.074-.503 4.894 4.894 0 0 0-1.345-.177c-.686 0-1.268.105-1.753.32-.485.21-.867.504-1.145.876a2.626 2.626 0 0 0-.51 1.255l2.244.079a.897.897 0 0 1 .375-.582c.194-.144.453-.21.776-.21.297 0 .537.073.711.21.19.156.266.379.266.62a.418.418 0 0 1-.182.367c-.116.085-.31.15-.575.196a13.93 13.93 0 0 1-1.048.124c-.388.033-.75.098-1.093.196-.343.092-.64.236-.906.419a1.885 1.885 0 0 0-.614.719c-.149.294-.226.653-.226 1.085 0 .51.11.934.323 1.274.188.34.485.588.86.758Zm2.755-1.523a1.557 1.557 0 0 1-.705.164c-.278 0-.51-.066-.692-.203-.18-.137-.271-.327-.271-.582a.72.72 0 0 1 .123-.43.906.906 0 0 1 .368-.302c.162-.078.356-.137.589-.17.11-.02.233-.032.356-.052.123-.02.239-.046.355-.072a2.59 2.59 0 0 0 .57-.183v.732c0 .249-.065.47-.188.66a1.275 1.275 0 0 1-.505.438Z"
                                                  clipRule="evenodd"></path>
                                            <path fill="currentColor"
                                                  d="M40.844.974v10.294h-2.432V.974h2.432ZM51.283 10.909c.576.333 1.268.503 2.076.503.718 0 1.333-.13 1.857-.392.524-.268.931-.634 1.216-1.112.29-.477.446-1.032.472-1.666h-2.27a1.779 1.779 0 0 1-.214.693 1.13 1.13 0 0 1-.433.424 1.182 1.182 0 0 1-.595.144c-.285 0-.53-.078-.744-.235-.214-.163-.375-.399-.498-.706-.117-.314-.175-.7-.175-1.157 0-.457.058-.837.175-1.144.116-.313.285-.549.498-.706.213-.163.46-.241.744-.241.349 0 .627.11.847.34.22.222.35.535.401.928h2.27c-.019-.634-.174-1.183-.472-1.654a2.985 2.985 0 0 0-1.235-1.098c-.524-.255-1.139-.386-1.844-.386-.802 0-1.487.17-2.063.503a3.373 3.373 0 0 0-1.326 1.406c-.31.595-.466 1.287-.466 2.078 0 .785.156 1.484.466 2.079a3.25 3.25 0 0 0 1.313 1.399Z"></path>
                                            <path fill="currentColor" fillRule="evenodd"
                                                  d="M45.285 11.412c-.801 0-1.487-.157-2.07-.477a3.269 3.269 0 0 1-1.332-1.373c-.31-.595-.465-1.307-.465-2.124 0-.798.155-1.497.465-2.092.31-.601.75-1.065 1.32-1.399.569-.333 1.235-.503 2.005-.503a4.22 4.22 0 0 1 1.494.255c.453.17.84.425 1.17.758.33.334.583.752.764 1.242.181.49.272 1.053.272 1.687V8h-5.09v.065c0 .314.058.589.18.83.123.236.298.419.524.55.227.13.492.195.809.195.213 0 .414-.032.588-.091.175-.059.324-.15.453-.268.123-.118.22-.261.285-.431l2.231.065c-.09.503-.297.948-.614 1.32-.31.373-.718.66-1.23.87-.51.202-1.092.307-1.758.307Zm1.365-4.85c-.006-.261-.045-.464-.161-.667a1.356 1.356 0 0 0-.511-.503 1.403 1.403 0 0 0-.712-.177 1.43 1.43 0 0 0-.73.184 1.339 1.339 0 0 0-.512.496 1.436 1.436 0 0 0-.2.667h2.826Z"
                                                  clipRule="evenodd"></path>
                                            <path fill="currentColor"
                                                  d="M61.901 3.549v1.81h-1.377v3.484c0 .15.026.275.07.366a.444.444 0 0 0 .214.196c.09.04.207.052.337.052.09 0 .187-.006.29-.026.104-.02.188-.039.24-.052l.369 1.771c-.117.033-.278.079-.492.124a3.82 3.82 0 0 1-.75.099c-.57.026-1.06-.04-1.468-.203a1.907 1.907 0 0 1-.932-.765c-.213-.346-.317-.778-.31-1.3V5.353h-1.01V3.549h1.01v-1.85h2.432v1.85H61.9Z"></path>
                                        </svg>
                                    </a></div>
                                </div>
                            </div>
                        </div>
                        <div className="text-white flex flex-col items-center">
                            <div className="cursor-pointer p-2.5 bg-white/5 rounded-full hover:opacity-60">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                     fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                                     strokeLinejoin="round" className="lucide lucide-share">
                                    <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path>
                                    <polyline points="16 6 12 2 8 6"></polyline>
                                    <line x1="12" x2="12" y1="2" y2="15"></line>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <p className="text-white text-center max-w-[35ch] md:max-w-none text-md font-light mt-3 bg-[#836EF9]/[0.08] border border-[#836EF9]/20 rounded-lg p-3">
                    If you're on the Uniswap web app, enable <span className="font-bold">Testnet Mode</span> in
                    settings.
                </p>
            </div>
        </section>
    );
}

export default Blinks;
