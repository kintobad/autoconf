const TrendingSection = () => {
  return (
    <section className="relative py-24 lg:pb-40 flex flex-col items-center justify-start">
      <div className="mb-8 lg:mb-12">
        <h2
          className="text-white text-5xl lg:text-7xl lg:mt-6 xl:mt-12 font-medium pb-[0.15em]"
          style={{
            background:
              "linear-gradient(rgb(255, 255, 255) 50%, rgb(102, 102, 102) 100%) text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Trending
        </h2>
      </div>

      <div
        className="hidden lg:block absolute -z-10 top-20 left-0 w-[240px] h-[240px] pointer-events-none opacity-0 blur-[10px] will-change-[opacity,filter,transform]"
        style={{
          transform: "rotate(-12deg)",
          filter: "blur(0px)",
          opacity: 0.5,
        }}
      >
        <img alt="Anago doodle" width="240" height="240" src="/Anago 1.svg" />
      </div>

      <div
        className="hidden md:block absolute z-10 bottom-12 right-[-48px] w-[240px] h-[240px] pointer-events-none opacity-0 blur-[10px] will-change-[opacity,filter,transform]"
        style={{
          transform: "rotate(12deg)",
          filter: "blur(0px)",
          opacity: 0.5,
        }}
      >
        <img
          alt="Creature doodle"
          width="240"
          height="240"
          src="/Creature.svg"
        />
      </div>

      <div className="container relative mx-auto w-full">
        <div
          className="absolute w-[440px] h-[440px] left-1/2 -translate-x-1/2 -top-[240px] rounded-[440px] opacity-50 pointer-events-none"
          style={{
            background:
              "radial-gradient(50% 50% at 50% 50%, rgba(88, 74, 168, 0.5) 0%, rgba(0, 0, 0, 0.38) 100%)",
            filter: "blur(180px)",
          }}
        ></div>

        <div
          className="relative rounded-3xl w-full p-6 shadow-[0px_1px_1px_0px_rgba(255,255,255,0.12)_inset,0px_1px_2px_0px_rgba(0,0,0,0.08),0px_0px_0px_1px_#000]"
          style={{
            background:
              "linear-gradient(rgba(44, 49, 58, 0.15) 0%, rgba(13, 13, 13, 0.5) 100%), rgb(25, 27, 31)",
          }}
        >
          <div className="bg-[#0E100F] relative rounded-xl p-8 shadow-[0px_4px_4px_0px_rgba(0,0,0,0.50)_inset]">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
              <div className="flex flex-col justify-center lg:order-2">
                <div className="flex flex-col gap-6">
                  <div className="flex justify-start">
                    <div
                      className="countdown-timer-container bg-black/40 backdrop-blur-sm px-4 py-2 rounded-full inline-flex"
                      style={{
                        boxShadow: "rgba(0, 0, 0, 0.25) 0px 4px 2px inset",
                      }}
                    >
                      <div className="flex items-center gap-2">
                        <div className="min-w-3 min-h-3 w-3 h-3 rounded-full animate-pulse bg-emerald-500"></div>
                        <span className="font-medium text-white text-base">
                          Live!
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 overflow-hidden rounded-xl flex items-center justify-center">
                      <img
                        alt="Fantasy Top Logo"
                        width="100"
                        height="100"
                        className="object-contain rounded-xl"
                        src="/FantasyTopLogo.png"
                      />
                    </div>
                    <h3 className="text-white text-3xl lg:text-4xl font-medium">
                      Fantasy Top
                    </h3>
                  </div>

                  <p className="text-gray-200 text-xl leading-relaxed">
                    Claim your free cards and build your deck now to compete in
                    weekly tournaments.
                  </p>

                  <div className="flex items-center gap-4 mt-4">
                    <a
                      href="https://monad.fantasy.top"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center whitespace-nowrap ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 gap-[6px] min-w-[105px] transition-all duration-350 ease-[cubic-bezier(0.34,1.56,0.64,1)] bg-[#6E54FF] text-white shadow-[0px_1px_0.5px_0px_rgba(255,255,255,0.33)_inset,0px_1px_2px_0px_rgba(26,19,161,0.50),0px_0px_0px_1px_#4F47EB] hover:bg-[#836EF9] hover:shadow-[0px_1px_1px_0px_rgba(255,255,255,0.12)_inset,0px_1px_2px_0px_rgba(26,19,161,0.50),0px_0px_0px_1px_#4F47EB] h-10 px-4 py-[6px] rounded-[100px] text-[14px] leading-[24px] font-[500]"
                    >
                      Play Now
                    </a>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center lg:order-1">
                <div className="w-full h-full flex items-center justify-center rounded-lg lg:rounded-lg overflow-hidden">
                  <img
                    alt="Fantasy Top Prizes"
                    width={600}
                    height={600}
                    className="w-full h-full object-contain"
                    src="/First%20Week%20Graphic4.jpg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrendingSection;
