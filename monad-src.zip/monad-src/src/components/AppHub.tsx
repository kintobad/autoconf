import styles from "../css/AppHub.module.css";

const apps = [
  {
    name: "Accountable",
    logo: "/apphub/163ab5017b038c996fee58d98d7734a8a59dda32-400x400.webp",
  },
  {
    name: "aiCraft.fun",
    logo: "/apphub/c40bb20cdc0b51afdfb1774f8f8328143d5aa2d7-400x400.webp",
  },
  {
    name: "Ammalgam",
    logo: "/apphub/6b9da35c2055a19c5b79d2925285b7e11eb62916-272x272.webp",
  },
  {
    name: "aPriori",
    logo: "/apphub/6769b3adb450ed465abb8c145bd6615b9a5c5383-400x400.webp",
  },
  {
    name: "Azaar",
    logo: "/apphub/115776fbfcedf32b23ff5b4ae972fbf4a5bb2163-400x400.webp",
  },
  {
    name: "Bean Exchange",
    logo: "/apphub/3e41411897d317702c6db0230bdc1b3919105b45-400x400.webp",
  },
  {
    name: "Bebop",
    logo: "/apphub/abc3ed931080d1880d59db2635034e4258f00796-400x400.webp",
  },
  {
    name: "Castora",
    logo: "/apphub/e22730fe8dd3437f8e0ae928d7ece1360f12955b-400x400.webp",
  },
  {
    name: "Chaquen",
    logo: "/apphub/3b7955ebfa9d606c5272b6093e5b40e3c67c3d1e-500x500.webp",
  },
  {
    name: "Clober",
    logo: "/apphub/51c2e282bff6d69285ebff36f6f0b0c637cb33e7-400x400.webp",
  },
  {
    name: "Covenant",
    logo: "/apphub/66a817c685c359d3c27c69d6a5630f485e57e975-400x400.webp",
  },
  {
    name: "Crystal",
    logo: "/apphub/116ec616d6dde182dbd3039c9d4bdce17158e5f8-3000x3000.webp",
  },
  {
    name: "Curvance",
    logo: "/apphub/99f1ab890cb46639d383709d8a501c1165868fe7-400x400.webp",
  },
  {
    name: "DAU Cards",
    logo: "/apphub/51e94c532c99e012e15b7b3a7af889200fbe5ab8-400x400.webp",
  },
  {
    name: "Dialect",
    logo: "/apphub/771a90689be7ae6bae6f86e7db24724377c194a0-900x900.webp",
  },
  {
    name: "Dirol Protocol",
    logo: "/apphub/8ae9092c5c00ef59a75727420d753a625f170765-400x400.webp",
  },
  {
    name: "Dusted",
    logo: "/apphub/4f3f79082520049e2bc973a1ebed30acced7a756-400x400.webp",
  },
  {
    name: "Encifher",
    logo: "/apphub/2380a64fbb6f0c1ff6c3e5cf95fc2f78c951cd9c-400x400.webp",
  },
  {
    name: "Fantasy Top",
    logo: "/apphub/9da7fe90e9595800ebfa9294074cd212f249a39c-850x850.webp",
  },
  {
    name: "Fastlane",
    logo: "/apphub/b1426406a3991da3c723f0210835ae637cffc7fe-400x400.webp",
  },
  {
    name: "Flap",
    logo: "/apphub/a6199cd6d13185716268e5b130c54384162f07ba-5417x5417.webp",
  },
  {
    name: "Folks Finance",
    logo: "/apphub/0d610e29a02209670264388d0631fd61234a97db-354x354.webp",
  },
  {
    name: "Fortytwo",
    logo: "/apphub/a54bc66dc589da6ab93216bf33cebbfcbcd4419a-375x375.webp",
  },
  {
    name: "FUKU",
    logo: "/apphub/c124bb07e5e6f6e4782a1bc700cd9e0f0c0810d9-512x512.webp",
  },
  {
    name: "Griffy",
    logo: "/apphub/1881f88e221e6fc70c2340f9845e6b8d1eaae49e-400x400.webp",
  },
  {
    name: "Hashflow",
    logo: "/apphub/c31bc349007c73d143a2d89c1e392bdd3f0e11bb-400x400.webp",
  },
  {
    name: "iZUMi",
    logo: "/apphub/09fa3744d3466d00a822b871e76b423ac9c96b5f-400x400.webp",
  },
  {
    name: "Kintsu",
    logo: "/apphub/80c10e88b03ca4ff1552f585fabee7eb88e12d4c-400x400.webp",
  },
  {
    name: "Kizzy",
    logo: "/apphub/384e3a77e0c908410aa4a7e511e20b882c6f62f1-1280x1280.webp",
  },
  {
    name: "Kinza",
    logo: "/apphub/fd6ff740160d056b8067ccfcae9830c2ddfd3b37-1366x1370.webp",
  },
  {
    name: "Kuru",
    logo: "/apphub/f757d446ac7b2d76a15c9d2e706a6168b0498221-400x400.webp",
  },
  {
    name: "LEVR.bet",
    logo: "/apphub/51a5e7d1537ac28dc62ad6b4adcb4cef2ee51697-400x400.webp",
  },
  {
    name: "LFJ",
    logo: "/apphub/ca729e8acb7d2d43c7704e4c1af93148c8bc41eb-400x400.webp",
  },
  {
    name: "LootGO",
    logo: "/apphub/a9ecb21e7593beba02184fc2d8e752e0cd665997-1920x1920.webp",
  },
  {
    name: "Magic Eden",
    logo: "/apphub/75e1d87b7837d8aef19b2f89c25074738cb35f8a-800x800.webp",
  },
  {
    name: "Magma",
    logo: "/apphub/37f62485dc1af50d8f9ee546286ead12cc06e8db-2124x2136.webp",
  },
  {
    name: "Mahjong123",
    logo: "/apphub/e5dceb049fe9e2ca11cc888c4d5ba43f0bb4cc44-400x400.webp",
  },
  {
    name: "Meta Leap",
    logo: "/apphub/6937e44bfbc53cc761edd00d782ea4c53d8968a3-443x397.webp",
  },
  {
    name: "Monorail",
    logo: "/apphub/b9fed18b70e694cda2046ce697ffd0f88cc9f4f7-400x400.jpg",
  },
  {
    name: "Moseiki",
    logo: "/apphub/837ffb3da01aaed28186af8ca732ce6baab4c2cb-500x500.webp",
  },
  {
    name: "Mozi",
    logo: "/apphub/140be91f1af545ee16253fa4c6c2347f09884f51-400x400.webp",
  },
  {
    name: "Mu Digital",
    logo: "/apphub/2c52324016052ead72169085e9d1cf6fb594fe1e-400x400.webp",
  },
  {
    name: "Multipli.fi",
    logo: "/apphub/a8c72b4f72bd148d1f6efcabdb058a84f059ea37-500x500.webp",
  },
  {
    name: "Nad.fun",
    logo: "/apphub/f18ecabab8c92bfa6e1d098daf643b66582df22e-400x400.webp",
  },
  {
    name: "Narwhal",
    logo: "/apphub/be81ff9486aa7199c54c0418abfbb40e49185ac0-500x500.webp",
  },
  {
    name: "Nextmate.AI",
    logo: "/apphub/7a55edba8c1e27e504345a252ba8113171797ded-400x400.webp",
  },
  {
    name: "NFTs2me",
    logo: "/apphub/526fe5c286f959770d2fb5af4702b1af1c49ce43-400x400.webp",
  },
  {
    name: "NitroFinance",
    logo: "/apphub/04e04cf74173bc6e15bcc78a2245af901f5ef630-500x500.webp",
  },
  {
    name: "Nostra",
    logo: "/apphub/3b5b153ef9dfc39fb67c2747444694bb3d94143a-400x400.webp",
  },
  {
    name: "Octoswap",
    logo: "/apphub/778fdff5b84f02611c2ebb45685f8edd89af52d3-400x400.webp",
  },
  {
    name: "Odyssey",
    logo: "/apphub/7a81b93fff87e1a135359de7e8623a60166e765c-400x400.webp",
  },
  {
    name: "Opals",
    logo: "/apphub/b5519ca1fcf5f2828e59e01ca932ca8fe72b78f5-400x400.webp",
  },
  {
    name: "Own.fun",
    logo: "/apphub/41d42cbd5ece955f8dec44e2679c853c5f9afa20-1280x1280.webp",
  },
  {
    name: "PancakeSwap",
    logo: "/apphub/35640fb69a74ebf9e673b280952172b34a212096-512x512.webp",
  },
  {
    name: "Plato",
    logo: "/apphub/1a864bc6fb0b1035179179d172b77bac9ddc213b-652x652.webp",
  },
  {
    name: "PLAY Network",
    logo: "/apphub/252a68a20f8f86cd111a161f37656a8286bb0395-1000x1000.webp",
  },
  {
    name: "Rabble",
    logo: "/apphub/5f533dd836330e94b907529e9136b29b29b6c1c8-640x640.webp",
  },
  {
    name: "RareBetSports",
    logo: "/apphub/9568f85e4ffbca669ee240103af7891e8aabba73-400x400.webp",
  },
  {
    name: "Redbrick",
    logo: "/apphub/b3f71276ec5ffaa7a1d1d3944b0b80ea88150ee3-400x400.webp",
  },
  {
    name: "Rubic",
    logo: "/apphub/c1630af8d6ca8290c2fd5176abd78ac791b1f3a6-400x400.webp",
  },
  {
    name: "Rug Rumble",
    logo: "/apphub/f7f93dec822728af555e22038f72a27b5bf6d474-800x800.webp",
  },
  {
    name: "Showdown",
    logo: "/apphub/19164b0fb22687f373bd191faa351e3dfe01ec76-1024x1024.webp",
  },
  {
    name: "SkyTrade",
    logo: "/apphub/708ebf0266fe5b8181ef36abf3f2b05b72a787dd-400x400.webp",
  },
  {
    name: "Slogain",
    logo: "/apphub/4fa156bce3d99029fb4f912dc898932a3642f756-400x400.webp",
  },
  {
    name: "Spine",
    logo: "/apphub/83dc70413b117d59af0a99e3cd606095f8f2aafa-400x400.webp",
  },
  {
    name: "Sumer",
    logo: "/apphub/7f893b09a806a6da3a3c9520cc2aec81d601ffe6-401x401.webp",
  },
  {
    name: "Tadle",
    logo: "/apphub/b069c8c6ed5b61bfb12b717ea09807100de13135-300x300.webp",
  },
  {
    name: "Talentum",
    logo: "/apphub/3140319cd9c09dd0db1d3cdb65abb5fab5958df6-400x400.webp",
  },
  {
    name: "The Vape Labs",
    logo: "/apphub/ca196ac35e5ca6524ad8883b97930dcaeb254bed-400x400.webp",
  },
  {
    name: "Timeswap",
    logo: "/apphub/72597016e6ccad3cf42739278e466ebc51b93aa9-500x500.webp",
  },
  {
    name: "Townesquare",
    logo: "/apphub/ccbd6d0266ac3e313f2f66121c6e73523943f207-1553x1553.webp",
  },
  {
    name: "XL",
    logo: "/apphub/ec8b8244bf94387aa2c03d1613d869d1bd064b01-400x400.webp",
  },
  {
    name: "Zaros",
    logo: "/apphub/9421256b0d090d5762929ce2332d636a164580fa-500x500.webp",
  },
  {
    name: "Zona",
    logo: "/apphub/2aeb1216ec9dc59218f5243e549b42584decd206-400x400.png",
  },
];

const AppHub = () => {
  return (
    <section className={styles.appListWrap}>
      <div className="container relative flex flex-col items-center">
        {/* Doodle 1 */}
        <div className={`${styles.doodle} ${styles.doodle1} hidden lg:block`}>
          <img
            alt="Lightning doodle"
            fetchPriority="high"
            width="240"
            height="240"
            decoding="async"
            src="/Lightning 1.svg"
            style={{ color: "transparent" }}
          />
        </div>

        {/* Doodle 2 */}
        <div className={`${styles.doodle} ${styles.doodle2} hidden lg:block`}>
          <img
            alt="Smiley doodle"
            fetchPriority="high"
            width="240"
            height="240"
            decoding="async"
            src="/Smiley 1.svg"
            style={{ color: "transparent" }}
          />
        </div>

        {/* App List Header */}
        <div className={styles.appListHeader}>
          <h2 className={styles.title}>App Hub</h2>
        </div>

        {/* App List Layout */}
        <div className={styles.appListLayout}>
          <div className={styles.appListInset}>
            {/* Dot Pattern Background */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="relative w-[1920px] h-[1440px]">
                <img
                  alt=""
                  fetchPriority="high"
                  decoding="async"
                  className="object-contain opacity-30"
                  sizes="100vw"
                  srcSet="/DotPattern.png"
                  style={{
                    position: "absolute",
                    height: "100%",
                    width: "100%",
                    inset: "0px",
                    color: "transparent",
                  }}
                />
              </div>
            </div>

            {/* Radial Gradient */}
            <div
              className="pointer-events-none absolute w-[360px] h-[360px] rounded-full -translate-x-1/2 -translate-y-1/2 mix-blend-soft-light will-change-transform"
              style={{
                background:
                  "radial-gradient(circle, rgba(179, 168, 240, 0.75) 100%, rgba(59, 51, 102, 0.25) 100%, transparent 70%)",
                filter: "blur(100px)",
                left: "638px",
                top: "13px",
              }}
            ></div>

            {/* App Grid */}
            <div className={styles.appListGrid}>
              {/*/!* App Grid Item - Zaros *!/*/}
              {/*<a target="_blank" rel="noopener noreferrer" data-id="Zaros" className={styles.appGridItem} href="https://testnet.app.zaros.fi">*/}
              {/*    <div className="relative">*/}
              {/*        <div className={styles.appGridItemLogo}>*/}
              {/*            <img alt="Zaros" loading="lazy" width="80" height="80" decoding="async" className="w-20 h-20 shadow-special" srcSet="/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fg5wr62lr%2Fproduction%2F9421256b0d090d5762929ce2332d636a164580fa-500x500.webp%3Fw%3D480%26h%3D480&amp;w=96&amp;q=75 1x, /_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fg5wr62lr%2Fproduction%2F9421256b0d090d5762929ce2332d636a164580fa-500x500.webp%3Fw%3D480%26h%3D480&amp;w=256&amp;q=75 2x" src="/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fg5wr62lr%2Fproduction%2F9421256b0d090d5762929ce2332d636a164580fa-500x500.webp%3Fw%3D480%26h%3D480&amp;w=256&amp;q=75" style={{ color: 'transparent' }} />*/}
              {/*        </div>*/}
              {/*    </div>*/}
              {/*    <div className={styles.appGridItemName}>Zaros</div>*/}
              {/*    <div className="absolute inset-0 bg-purple-500/20 blur-xl rounded-[24px] opacity-0"></div>*/}
              {/*</a>*/}

              {/* App Grid Item - Zona */}
              {apps.map((app) => {
                return (
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    data-id="Zona"
                    className={styles.appGridItem}
                    href="https://app.zona.finance/trade"
                    key={app.name}
                  >
                    <div className="relative">
                      <div className={styles.appGridItemLogo}>
                        <img
                          alt="Zona"
                          loading="lazy"
                          width="80"
                          height="80"
                          decoding="async"
                          className="w-20 h-20 shadow-special"
                          srcSet={app.logo}
                          src={app.logo}
                          style={{ color: "transparent" }}
                        />
                      </div>
                    </div>

                    <div className={styles.appGridItemName}>{app.name}</div>
                    <div className="absolute inset-0 bg-purple-500/20 blur-xl rounded-[24px] opacity-0"></div>
                  </a>
                );
              })}
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className={styles.ctaSection}>
          <p className={styles.ctaText}>
            Explore hundreds more apps and infrastructure protocols deployed on
            Monad testnet.
          </p>
          <a
            href="https://monad.xyz/ecosystem"
            target="_blank"
            rel="noopener noreferrer"
            className={styles.ctaButton}
          >
            Explore the full Monad Ecosystem
          </a>
        </div>
      </div>
    </section>
  );
};

export default AppHub;
