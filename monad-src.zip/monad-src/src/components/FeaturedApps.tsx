import { useEffect, useRef, useState } from "react";
import styles from "../css/FeaturedApps.module.css"; // Предположим, что у вас есть CSS-модуль для стилей

const cards = [
  {
    name: "LFJ",
    description:
      "Find and trade any token on Monad or head to the Token Mill and create your own meme.",

    logo: "/apps/42face315664c16e1b3056cd8e088d43f8405b9b-400x400.jpg",
    banner: "/apps/109f4bddbef7cfe3d2820c80ea5555bc8b07a80c-1500x500.jpg",
    url: "",
  },
  {
    name: "Dusted",
    description:
      "Connect with community members in chat rooms built around tokens you own, earn Dusted points, and win prizes from other Monad projects.",

    logo: "/apps/daa2291e56371c8c5f53b50050ae36dc6bd426d3-401x401.png",
    banner: "/apps/9e5229e1b6157a97013a1d4f2581f4a768b5145e-1500x500.jpg",
    url: "",
  },
  {
    name: "RareBetSports",
    description: "Play daily fantasy sports to win prizes.",

    logo: "/apps/9568f85e4ffbca669ee240103af7891e8aabba73-400x400.jpg",
    banner: "/apps/6485157c1f85735000748b85776fdb74f3ac92e6-1200x675.jpg",
    url: "",
  },
  {
    name: "Kuru",
    description:
      "Find and trade all your favorite Monad tokens on an onchain CLOB.",

    logo: "/apps/f757d446ac7b2d76a15c9d2e706a6168b0498221-400x400.jpg",
    banner: "/apps/650d263112c275af8ca26a7b5d4a5668ba592aee-1432x675.jpg",
    url: "",
  },
  {
    name: "Kizzy",
    description:
      "Predict performance on your top Youtube and X influencers. Rank up, climb the leaderboard, and collect Purple K. Use code: GMONAD",

    logo: "/apps/384e3a77e0c908410aa4a7e511e20b882c6f62f1-1280x1280.jpg",
    banner: "/apps/3c037023d6f1221730b8d8cc52a10e23fbdacaf2-1200x675.jpg",
    url: "",
  },
  {
    name: "Curvance",
    description: "Click your way to greatness and level up with Curvance DeFi.",

    logo: "/apps/99f1ab890cb46639d383709d8a501c1165868fe7-400x400.png",
    banner: "/apps/f8d343b100e4300b286de96c68de47fc3734f8eb-1256x675.jpg",
    url: "",
  },
  {
    name: "Plato",
    description:
      "Eat at your favorite restaurants, share your experience and earn points for you and your favorite Monad project's community!",

    logo: "/apps/2cba089fbe4b8f0883bef0fc3b102cc33c8974a4-652x652.png",
    banner: "/apps/6faa33b75a9a06e86b1ee3b6d01639bb430b1d73-1500x500.jpg",
    url: "",
  },
  {
    name: "Nad.fun",
    description:
      "Your one stop social meme platform - jump on Nad.fun and create your own meme now.",

    logo: "/apps/ba032b7bfb820041a5dfb67c112d4e1ef2189931-400x400.jpg",
    banner: "/apps/7c8a23950f4eaa5cb79e610d45d46b274027769d-1500x500.jpg",
    url: "",
  },
];

const AppCard = ({
  card,
}: {
  card: {
    banner: string;
    logo: string;
    name: string;
    description: string;
    url: string;
  };
}) => {
  return (
    <div className={styles.appCard}>
      <div className={styles.cardBackground}>
        <div className={styles.gradientOverlay}></div>
        {/*<div className={styles.appLinks}>*/}
        {/*    <a target="_blank" rel="noopener noreferrer" className={styles.link}*/}
        {/*       href={card.url}>*/}
        {/*        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current" aria-hidden="true">*/}
        {/*            <path*/}
        {/*                d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path>*/}
        {/*        </svg>*/}
        {/*    </a>*/}
        {/*</div>*/}
        <img
          alt="LFJ banner"
          className={styles.bannerImage}
          src={card.banner}
        />
        <div className={styles.logoContainer}>
          <img alt="LFJ logo" className={styles.logoImage} src={card.logo} />
        </div>
        <div className={styles.cardContent}>
          <h3 className={styles.appTitle}>{card.name}</h3>
          <p className={styles.appDescription}>{card.description}</p>
          <a
            target="_blank"
            rel="noopener noreferrer"
            className={styles.launchButton}
            href={card.url}
          >
            Launch App
          </a>
        </div>
      </div>
    </div>
  );
};
const FeaturedApps = () => {
  const [isScrolled, setIsScrolled] = useState("");
  // const [scroll, setScroll] = useState(0);
  const wrapperRef = useRef(null);
  const wrapperInnerRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      // Определяем, на каком уровне прокрутки добавлять стили
      const scrollY = window.scrollY || window.pageYOffset;
      const minY = 4720;
      const step = 86.2056;
      const maxY = 7100;

      if (scrollY > minY && scrollY < maxY) {
        // Например, добавляем стили после прокрутки на 200px
        setIsScrolled("fixed");

        console.log(scrollY);

        if (wrapperInnerRef.current) {
          const translateX = step * ((minY - scrollY) / 100); // Динамическое значение translateX, зависящее от scrollY
          const perspective = 17.774; // Фиксированное значение perspective

          // Применяем transform к элементу
          (
            wrapperInnerRef.current as HTMLElement
          ).style.transform = `perspective(${perspective}px) translate3d(${translateX}px, 0px, 0px)`;
        }
      } else if (scrollY < minY) {
        setIsScrolled("");
      } else {
        setIsScrolled("after");
      }
    };

    // Добавляем слушатель события scroll
    window.addEventListener("scroll", handleScroll);

    // Убираем слушатель при размонтировании компонента
    // return () => {
    //   window.removeEventListener("scroll", handleScroll);
    // };
  }, []);

  return (
    <section
      className={`${styles.featuredApps} container mx-auto relative pb-16`}
    >
      <div className="apps flex items-center">
        <div className="w-full max-w-none px-4 md:px-0">
          <div className={styles.pinSpacer}>
            <div
              ref={wrapperRef}
              className={`${styles.appListWrapper} ${
                isScrolled === "fixed"
                  ? "fixed"
                  : isScrolled === "after"
                  ? styles.after
                  : ""
              }`}
            >
              <h2
                className={`${styles.title} text-white text-4xl md:text-6xl font-medium mb-8 tracking-tighter pb-[0.15em]`}
              >
                Featured Apps
              </h2>
              <div className="relative">
                <div
                  ref={wrapperInnerRef}
                  className={`${styles.appListWrapperInner} gap-4`}
                >
                  {cards.map((card) => (
                    <AppCard key={card.name} card={card} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default FeaturedApps;
