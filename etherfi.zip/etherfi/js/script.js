document.addEventListener('DOMContentLoaded', function(){
        // бургер
        document.addEventListener('click', function(e) {
                const burger = document.querySelector('.js-burger');
                const navList = document.querySelector('.nav__list');
                if (e.target.closest('.js-burger')) {
                    burger.classList.toggle('clicked');
                    navList.classList.toggle('show');
                } else {
                    burger.classList.remove('clicked');
                    navList.classList.remove('show');
                }
            });
            
})
